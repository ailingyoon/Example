﻿/*
 * 如果编译报：错误	4	无法将类型“string”隐式转换为“System.Windows.Forms.DataGridViewTextBoxColumn”
 * 请删除：Form1.Designer.cs 文件中 this.Name = "Form1"; 这一行即可
 */
using System;
using System.Data;
using System.Diagnostics;
using System.Windows.Forms;
using WinFormExportExcel;

namespace check
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Bind();//多选
            Bind2();//单选
            dataGridView1.ClearSelection();//清除默认选择
            dataGridView2.ClearSelection();//清除默认选择
        }
        #region 多选
        /// <summary>
        /// 这里应该是从数据库中取出来的数据(Select的过程略)
        /// 将获得的DataTable添加到dataGridView的数据源中
        /// </summary>
        private void Bind()
        {
            //模拟数据：
            DataTable dt1 = new DataTable();//假如是从数据库取出来的数据
            dt1.Columns.Add("编号", typeof(string));
            dt1.Columns.Add("姓名", typeof(string));
            dt1.Columns.Add("性别", typeof(string));
            dt1.Columns.Add("年龄", typeof(string));

            dt1.Rows.Add("1", "天一", "女", "21");
            dt1.Rows.Add("2", "牛二", "男", "22");
            dt1.Rows.Add("3", "张三", "男", "20");
            dt1.Rows.Add("4", "李四", "女", "19");
            dt1.Rows.Add("5", "王五", "男", "25");
            dt1.Rows.Add("6", "赵六", "男", "24");
            dt1.Rows.Add("7", "田七", "男", "22");
            dt1.Rows.Add("8", "王八", "男", "21");
            dt1.Rows.Add("9", "白九", "男", "20");
            dt1.Rows.Add("10", "老十", "男", "24");
            dt1.Rows.Add("11", "石依", "女", "22");

            dataGridView1.DataSource = dt1;//添加到dataGridView的数据源中
        }
        private void btnALL_Click(object sender, EventArgs e)
        {
            CheckCtrl(true);//全选
        }
        private void button2_Click(object sender, EventArgs e)
        {
            CheckCtrl(false);  //全不选(清空选中)
        }
        private void button1_Click(object sender, EventArgs e)
        {
            CheckCtrl();//反选
        }
        private void CheckCtrl(bool? check = null)
        {
            if (dataGridView1.DataSource != null && dataGridView1.Rows.Count > 0)
            {
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (check != null)//全选or全不选
                        dataGridView1.Rows[i].Cells["check"].Value = check;
                    else//反选
                        dataGridView1.Rows[i].Cells["check"].Value = !Convert.ToBoolean(dataGridView1.Rows[i].Cells["check"].Value);
                }
            }
        }
        //取值
        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.DataSource != null && dataGridView1.Rows.Count > 0)
            {
                string temp = "";
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (Convert.ToBoolean(dataGridView1.Rows[i].Cells["check"].Value))//获取选中的
                    {
                        temp += dataGridView1.Rows[i].Cells["编号"].Value.ToString() + ",";
                        temp += dataGridView1.Rows[i].Cells["姓名"].Value.ToString() + ",";
                        temp += dataGridView1.Rows[i].Cells["性别"].Value.ToString() + ",";
                        temp += dataGridView1.Rows[i].Cells["年龄"].Value.ToString() + "\r";
                    }
                }
                if (temp != "") MessageBox.Show(temp);
            }
        }
        //导出全部
        private void button4_Click(object sender, EventArgs e)
        {
            string fileName = "全体人员_" + DateTime.Now.ToString("yyyyMMddHHmmss"); //Excel文件名
            string sheetName = "全体人员";//sheet页的名称
            ExportToExcel(dataGridView1, fileName, sheetName);
        }
        //导出选中
        private void button5_Click(object sender, EventArgs e)
        {
            if (dataGridView1.DataSource != null && dataGridView1.Rows.Count > 0)
            {
                DataTable dt1 = new DataTable();
                dt1.Columns.Add("编号", typeof(string));
                dt1.Columns.Add("姓名", typeof(string));
                dt1.Columns.Add("性别", typeof(string));
                dt1.Columns.Add("年龄", typeof(string));

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (Convert.ToBoolean(dataGridView1.Rows[i].Cells["check"].Value))//获取选中的
                    {
                        dt1.Rows.Add(dataGridView1.Rows[i].Cells["编号"].Value.ToString(),
                                    dataGridView1.Rows[i].Cells["姓名"].Value.ToString(),
                                    dataGridView1.Rows[i].Cells["性别"].Value.ToString(),
                                    dataGridView1.Rows[i].Cells["年龄"].Value.ToString());
                    }
                }
                if (dt1 != null && dt1.Rows.Count > 0)
                {
                    dataGridView3.DataSource = dt1;
                    string fileName = "选中人员_" + DateTime.Now.ToString("yyyyMMddHHmmss"); //Excel文件名
                    string sheetName = "选中人员";//sheet页的名称
                    ExportToExcel(dataGridView3, fileName, sheetName);
                }
            }
        }
        private void ExportToExcel(DataGridView dataGridView, string fileName, string sheetName)
        {
            ClsExcel cExcel = null;
            cExcel = new ClsExcel();

            cExcel.ExportToExcel(ref dataGridView, fileName, sheetName);
            cExcel.Close(false);
        }
        #endregion
        #region 单选
        private void Bind2()
        {
            DataTable dt1 = new DataTable();//假如是从数据库取出来的数据
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Name", typeof(string));
            dt1.Columns.Add("Sex", typeof(string));
            dt1.Columns.Add("Age", typeof(string));

            dt1.Rows.Add("1", "Tom", "male", "21");
            dt1.Rows.Add("2", "Tim", "male", "22");
            dt1.Rows.Add("3", "Marry", "female", "20");
            dt1.Rows.Add("4", "Mike", "male", "19");
            dt1.Rows.Add("5", "Ada", "female", "25");
            dt1.Rows.Add("6", "Apple", "female", "24");
            dt1.Rows.Add("7", "May", "female", "22");
            dt1.Rows.Add("8", "Kimi", "male", "21");
            dt1.Rows.Add("9", "Jerry", "male", "20");
            dt1.Rows.Add("10", "Bill", "male", "24");
            dt1.Rows.Add("11", "Jams", "male", "22");

            dataGridView2.DataSource = dt1;//添加到dataGridView的数据源中
        }
        //选中一个
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ClearCheck();//清空之前选择
            label1.Text = "";
            dataGridView2.EndEdit(); //重要！提交当前选择状态(不加这个会找不到当前的选择)            
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                if (Convert.ToBoolean(dataGridView2.Rows[i].Cells["check2"].Value))//获取选中的
                {
                    label1.Text += dataGridView2.Rows[e.RowIndex].Cells["ID"].Value.ToString() + ",";
                    label1.Text += dataGridView2.Rows[e.RowIndex].Cells["Name"].Value.ToString() + ",";
                    label1.Text += dataGridView2.Rows[e.RowIndex].Cells["Sex"].Value.ToString() + ",";
                    label1.Text += dataGridView2.Rows[e.RowIndex].Cells["Age"].Value.ToString() + "";
                }
            }
        }
        private void ClearCheck()
        {
            if (dataGridView2.DataSource != null && dataGridView1.Rows.Count > 0)
            {
                for (int i = 0; i < dataGridView2.Rows.Count; i++)
                {
                    dataGridView2.Rows[i].Cells["check2"].Value = false;
                }
            }
        }
        #endregion
        //我的腾讯微博
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://t.qq.com/djk8888");
        }
    }
}
