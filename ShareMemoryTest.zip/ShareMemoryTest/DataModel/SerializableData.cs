﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace DataModel
{

    /// <summary>
    /// 要共享的数据结构，如果使用Image等引用，必须将其序列化
    /// </summary>
    [Serializable]
    public class SerializableData
    {
        public string description;  //图片信息说明
        public Image picture;       //图片       
    }
}
