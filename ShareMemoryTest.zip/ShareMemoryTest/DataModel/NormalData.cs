﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataModel
{
    /// <summary>
    /// 要共享的数据结构，注意，其成员不能是引用类型
    /// </summary>
    public struct NormalData
    {
        public int IntValue
        {
            get;
            set;
        }
        public float FloatValue
        {
            get;
            set;
        }
    }
}
