﻿namespace ShareMemoryTest2
{
    partial class FormRead
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonRead = new System.Windows.Forms.Button();
            this.DV = new System.Windows.Forms.DataGridView();
            this.tx1 = new System.Windows.Forms.TextBox();
            this.DV2 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.DV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DV2)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonRead
            // 
            this.buttonRead.Location = new System.Drawing.Point(30, 12);
            this.buttonRead.Name = "buttonRead";
            this.buttonRead.Size = new System.Drawing.Size(138, 49);
            this.buttonRead.TabIndex = 0;
            this.buttonRead.Text = "Read";
            this.buttonRead.UseVisualStyleBackColor = true;
            this.buttonRead.Click += new System.EventHandler(this.buttonRead_Click);
            // 
            // DV
            // 
            this.DV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DV.Location = new System.Drawing.Point(0, 105);
            this.DV.Name = "DV";
            this.DV.Size = new System.Drawing.Size(582, 435);
            this.DV.TabIndex = 1;
            // 
            // tx1
            // 
            this.tx1.Location = new System.Drawing.Point(193, 19);
            this.tx1.Multiline = true;
            this.tx1.Name = "tx1";
            this.tx1.Size = new System.Drawing.Size(679, 53);
            this.tx1.TabIndex = 2;
            // 
            // DV2
            // 
            this.DV2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DV2.Location = new System.Drawing.Point(606, 105);
            this.DV2.Name = "DV2";
            this.DV2.Size = new System.Drawing.Size(582, 435);
            this.DV2.TabIndex = 3;
            // 
            // FormRead
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1233, 541);
            this.Controls.Add(this.DV2);
            this.Controls.Add(this.tx1);
            this.Controls.Add(this.DV);
            this.Controls.Add(this.buttonRead);
            this.Name = "FormRead";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.DV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DV2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonRead;
        private System.Windows.Forms.DataGridView DV;
        private System.Windows.Forms.TextBox tx1;
        private System.Windows.Forms.DataGridView DV2;
    }
}

