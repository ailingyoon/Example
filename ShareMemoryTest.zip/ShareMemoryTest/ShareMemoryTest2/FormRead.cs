﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using DataModel;

namespace ShareMemoryTest2
{
    public partial class FormRead : Form
    {
        public FormRead()
        {
            InitializeComponent();
        }

        private const int FileSize = 1024 * 1024;
         private const string MapNameForAccessor = "{B3454A11-2A13-40CA-A720-4B87DAF04AD6}";
        private const string MapNameForStream = "{3EA135E4-EDF0-46EE-ADDF-DD352C33FE1F}";
        
        private DataModel.NormalData data;

        private void buttonRead_Click(object sender, EventArgs e)
        {
            DV.DataSource = null;
            DV.Refresh();

            try
            {
                MemoryMappedFile mapFileAccessor =
                  MemoryMappedFile.OpenExisting(MapNameForAccessor, MemoryMappedFileRights.ReadWrite);
                MemoryMappedFile mapFileStream =
                   MemoryMappedFile.OpenExisting(MapNameForStream, MemoryMappedFileRights.ReadWrite);

                MemoryMappedViewAccessor mapAccessor = mapFileAccessor.CreateViewAccessor();
                MemoryMappedViewStream mapViewStream = mapFileStream.CreateViewStream();
                //MessageBox.Show("创建或连接内存文件成功");

                extractData(mapAccessor, mapViewStream);
              
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

     

        private void extractData(MemoryMappedViewAccessor mapAccessor, MemoryMappedViewStream mapViewStream)
        {
    
            mapAccessor.Read<NormalData>(0, out data);
            string info = data.IntValue.ToString() + "\r\n";
            info += data.FloatValue.ToString();
            //MessageBox.Show("成功从内存文件中提取了数据!\r\n" + info);

            tx1.Text = "成功从内存文件中提取了数据!\r\n" + info;

            IFormatter formatter = new BinaryFormatter();
            mapViewStream.Seek(0, SeekOrigin.Begin);
            //DataTable table = formatter.Deserialize(mapViewStream) as DataTable;
            DataSet ds = formatter.Deserialize(mapViewStream) as DataSet;



            if (ds != null)
            {
                
                DV.DataSource = ds.Tables[0];
                DV.Refresh();
                DV.AutoResizeColumns();

                DV2.DataSource = ds.Tables[1];
                DV2.Refresh();
                DV2.AutoResizeColumns();

            }
            else
            {
                MessageBox.Show("反序列化共享内存数据失败!");
            }

        }

      
    }
}
