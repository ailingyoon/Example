﻿using System;
//using System.Collections.Generic;
//using System.ComponentModel;
using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
using System.Windows.Forms;
using System.IO.MemoryMappedFiles;
//using System.Runtime.InteropServices;
using System.IO;
//using System.Diagnostics;
//using System.Security.AccessControl;
//using System.Security.Principal;
//using System.Threading;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using DataModel;

namespace ShareMemoryTest
{
    public partial class FormWrite : Form
    {
        public FormWrite()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 内存映射文件的容量
        /// </summary>
        //private const int FileSize = 1024 * 1024;
        //private const string MapNameForAccessor = "{B3454A11-2A13-40CA-A720-4B87DAF04AD6}";
        //private const string MapNameForStream = "{3EA135E4-EDF0-46EE-ADDF-DD352C33FE1F}";
        //private MemoryMappedFile mapFileForAccessor = null;
        //private MemoryMappedFile mapFileForStream = null;
        //private MemoryMappedViewAccessor memoryMapAccessor = null;
        //private MemoryMappedViewStream memoryMapViewStream = null;

        /// <summary>
        /// 要共享的数据对象
        /// </summary>
        private NormalData data;

        private void buttonWrite_Click(object sender, EventArgs e)
        {
            try
            {
                
               //InitMemoryMappedFile();
                       
                

               // writeNormalData();

                writeSerializableData();
 
                //MessageBox.Show("数据已经保存到内存文件中");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private DataTable GenTable()
        {
            DataTable table = new DataTable();
            table.Columns.Add("Dosage", typeof(int));
            table.Columns.Add("Drug", typeof(string));
            table.Columns.Add("Patient", typeof(string));

            // Here we add five DataRows.
            table.Rows.Add(20, "Indocin", "David");
            table.Rows.Add(30, "Enebrel", "Sam");
            table.Rows.Add(40, "Hydralazine", "Christoff");
            return table;

        }

        private DataTable GenTable2()
        {
            DataTable table = new DataTable();
            table.Columns.Add("Dosage", typeof(string));
            table.Columns.Add("Drug", typeof(string));
       

            // Here we add five DataRows.
            table.Rows.Add("ooIndocin", "David");
            table.Rows.Add( "ccEnebrel", "Sam");
            table.Rows.Add( "rrHydralazine", "Christoff");
            return table;

        }


        private void writeSerializableData()
        {

            const int FileSize = 1024 * 1024;
            const string MapNameForAccessor = "{B3454A11-2A13-40CA-A720-4B87DAF04AD6}"; 
            const string MapNameForStream = "{3EA135E4-EDF0-46EE-ADDF-DD352C33FE1F}";
            MemoryMappedFile mapFileForAccessor = null;
            MemoryMappedFile mapFileForStream = null;
            MemoryMappedViewAccessor memoryMapAccessor = null;
            MemoryMappedViewStream memoryMapViewStream = null;

            mapFileForAccessor = MemoryMappedFile.CreateOrOpen(MapNameForAccessor, FileSize);
            mapFileForStream = MemoryMappedFile.CreateOrOpen(MapNameForStream, FileSize);
            memoryMapAccessor = mapFileForAccessor.CreateViewAccessor();
            memoryMapViewStream = mapFileForStream.CreateViewStream();

            IFormatter formatter = new BinaryFormatter();
            memoryMapViewStream.Seek(0, SeekOrigin.Begin);
            
            DataSet ds = new DataSet();
            ds.Tables.Add(GenTable()); 
            ds.Tables.Add(GenTable2()); 
            formatter.Serialize(memoryMapViewStream, ds);


        }

        //private void writeNormalData()
        //{
        //    data.IntValue = DateTime.Now.Second;
        //    data.FloatValue = DateTime.Now.Millisecond;
        //    memoryMapAccessor.Write<NormalData>(0, ref data);
        //}

        /// <summary>
        /// 初始化内存映射文件
        /// </summary>
        //private void InitMemoryMappedFile()
        //{

       
        //   mapFileForAccessor = MemoryMappedFile.CreateOrOpen(MapNameForAccessor, FileSize);
        //    mapFileForStream = MemoryMappedFile.CreateOrOpen(MapNameForStream, FileSize);
        //    memoryMapAccessor = mapFileForAccessor.CreateViewAccessor();
        //    memoryMapViewStream = mapFileForStream.CreateViewStream();
        //    //MessageBox.Show("直接在系统分页中创建或连接内存文件");
        //}

       

        /// <summary>
        /// 关闭并释放资源
        /// </summary>
        //private void DisposeMemoryMapFile()
        //{
        //    if (memoryMapAccessor != null)
        //    {
        //        memoryMapAccessor.Dispose();
        //    }
        //    if (memoryMapViewStream != null)
        //    {
        //        memoryMapViewStream.Dispose();
        //    }
        //    if (mapFileForAccessor != null)
        //    {
        //        mapFileForAccessor.Dispose();
        //    }
        //}

        //private void buttonRead_Click(object sender, EventArgs e)
        //{
        //    MemoryMappedFile mapFileAccessor = MemoryMappedFile.OpenExisting(MapNameForAccessor, MemoryMappedFileRights.ReadWrite);
        //    MemoryMappedFile mapFileStream = MemoryMappedFile.OpenExisting(MapNameForStream, MemoryMappedFileRights.ReadWrite);
        //    MemoryMappedViewAccessor mapAccessor = mapFileAccessor.CreateViewAccessor();
        //    MemoryMappedViewStream mapViewStream = mapFileStream.CreateViewStream();


        //    extractData(mapAccessor, mapViewStream);
        //}

        private void extractData(MemoryMappedViewAccessor mapAccessor, MemoryMappedViewStream mapViewStream)
        {
            mapAccessor.Read<NormalData>(0, out data);
            string info = data.IntValue.ToString() + "\r\n";
            info += data.FloatValue.ToString();
            MessageBox.Show("成功从内存文件中提取了数据!\r\n" + info);

            IFormatter formatter = new BinaryFormatter();
            mapViewStream.Seek(0, SeekOrigin.Begin);
            DataTable table = formatter.Deserialize(mapViewStream) as DataTable;

            if (table != null)
            {

                //DV.DataSource = table;
                //DV.Refresh();
                //DV.AutoResizeColumns();

            }
            else
            {
                MessageBox.Show("反序列化共享内存数据失败!");
            }

        }

        private void FormWrite_Load(object sender, EventArgs e)
        {
            //InitMemoryMappedFile();
            //InitMemoryMappedFile("MyMap");
        }

        //private void FormWrite_FormClosing(object sender, FormClosingEventArgs e)
        //{
        //    DisposeMemoryMapFile();
        //}
    }

   
}
