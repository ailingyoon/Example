﻿namespace ShareMemoryTest
{
    partial class FormWrite
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonWrite = new System.Windows.Forms.Button();
            this.buttonRead = new System.Windows.Forms.Button();
            this.radioButtonDiskFileMap = new System.Windows.Forms.RadioButton();
            this.radioButtonMemoryMap = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // buttonWrite
            // 
            this.buttonWrite.Location = new System.Drawing.Point(174, 42);
            this.buttonWrite.Name = "buttonWrite";
            this.buttonWrite.Size = new System.Drawing.Size(191, 106);
            this.buttonWrite.TabIndex = 0;
            this.buttonWrite.Text = "Write";
            this.buttonWrite.UseVisualStyleBackColor = true;
            this.buttonWrite.Click += new System.EventHandler(this.buttonWrite_Click);
            // 
            // buttonRead
            // 
            this.buttonRead.Location = new System.Drawing.Point(162, 233);
            this.buttonRead.Name = "buttonRead";
            this.buttonRead.Size = new System.Drawing.Size(214, 89);
            this.buttonRead.TabIndex = 1;
            this.buttonRead.Text = "Read";
            this.buttonRead.UseVisualStyleBackColor = true;
            //this.buttonRead.Click += new System.EventHandler(this.buttonRead_Click);
            // 
            // radioButtonDiskFileMap
            // 
            this.radioButtonDiskFileMap.AutoSize = true;
            this.radioButtonDiskFileMap.Checked = true;
            this.radioButtonDiskFileMap.Location = new System.Drawing.Point(12, 93);
            this.radioButtonDiskFileMap.Name = "radioButtonDiskFileMap";
            this.radioButtonDiskFileMap.Size = new System.Drawing.Size(83, 17);
            this.radioButtonDiskFileMap.TabIndex = 2;
            this.radioButtonDiskFileMap.TabStop = true;
            this.radioButtonDiskFileMap.Text = "DiskFileMap";
            this.radioButtonDiskFileMap.UseVisualStyleBackColor = true;
            // 
            // radioButtonMemoryMap
            // 
            this.radioButtonMemoryMap.AutoSize = true;
            this.radioButtonMemoryMap.Location = new System.Drawing.Point(12, 131);
            this.radioButtonMemoryMap.Name = "radioButtonMemoryMap";
            this.radioButtonMemoryMap.Size = new System.Drawing.Size(83, 17);
            this.radioButtonMemoryMap.TabIndex = 2;
            this.radioButtonMemoryMap.Text = "MemoryMap";
            this.radioButtonMemoryMap.UseVisualStyleBackColor = true;
            // 
            // FormWrite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 450);
            this.Controls.Add(this.radioButtonMemoryMap);
            this.Controls.Add(this.radioButtonDiskFileMap);
            this.Controls.Add(this.buttonRead);
            this.Controls.Add(this.buttonWrite);
            this.Name = "FormWrite";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            //this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormWrite_FormClosing);
            this.Load += new System.EventHandler(this.FormWrite_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonWrite;
        private System.Windows.Forms.Button buttonRead;
        private System.Windows.Forms.RadioButton radioButtonDiskFileMap;
        private System.Windows.Forms.RadioButton radioButtonMemoryMap;
    }
}

