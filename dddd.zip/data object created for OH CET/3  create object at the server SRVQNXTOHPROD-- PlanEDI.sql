USE [PlanEDI]
GO

/****** Object:  Table [dbo].[tbl_CVS_Accum_Stg]    Script Date: 12/6/2018 4:57:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tbl_CVS_Accum_Stg](
	[Memid] [varchar](25) NULL,
	[carriermemid] [varchar](30) NULL,
	[AccumAmt] [numeric](10, 2) NULL,
	[updstatus] [char](1) NULL,
	[MBU_Filename] [varchar](100) NULL,
	[MBU_Fileloaddate] [smalldatetime] NULL,
	[MBU_FileloadID] [varchar](25) NULL,
	[EffDate] [date] NULL
) ON [Data]

GO


USE [PlanEDI]
GO
/****** Object:  StoredProcedure [dbo].[CVS_AccumValue_Calc]    Script Date: 12/24/2018 2:01:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[CVS_AccumValue_Calc]                     
AS                  
BEGIN            
        
 --DECLARE @AetnaID varchar(40) =CURRENT_USER;                   
 DECLARE  @varAccumid VARCHAR(20)='DV00015724';                  
 DECLARE @InsertAffected INTEGER;                  
 DECLARE @UpdateAffected INTEGER;                  
                             
 SET NOCOUNT ON;                   
                  
        
-- vairable table (@tbl_memaccumulator_copy)  use to store exist records coming from memaccumulator                  
DECLARE @tbl_memaccumulator_copy TABLE                   
 ( memid  VARCHAR(30), accumvalue NUMERIC(10, 2), effdate    DATE,        
 PRIMARY KEY (memid,effdate) );                   
                  
INSERT INTO @tbl_memaccumulator_copy                   
            (memid,                   
             accumvalue,                   
             effdate)                   
SELECT memid,                   
       accumvalue,                   
       Cast(effdate AS DATE)               
FROM   [plandata_QNXT_OHIO].[dbo].[memaccumulator]                 
WHERE  accumid = @varAccumid;                   
                   
                  
                  
      
UPDATE t                   
SET    [updstatus] = 'I'      -----'Ready to be Inserted'                  
FROM   dbo.[tbl_CVS_Accum_Stg] t                    
       LEFT JOIN @tbl_memaccumulator_copy  q                   
              ON t.memid = q.memid                   
     and t.EffDate= q.effdate                
WHERE    q.memid IS NULL ;                   
 SELECT @InsertAffected = @@ROWCOUNT ;                  
       
      
UPDATE t                   
SET    t.[updstatus] = 'U' -----Ready to be Updated                   
FROM   dbo.[tbl_cvs_accum_stg] t                   
      LEFT JOIN @tbl_memaccumulator_copy  q                  
              ON t.memid = q.memid                   
                 AND t.effdate =q.effdate               
WHERE    t.accumamt <> q.accumvalue                   
       AND t.[updstatus] IS NULL;         
              
 SELECT @UpdateAffected = @@ROWCOUNT;               
              
              
----- nothing to do  for the rest of records                   
update dbo.[tbl_CVS_Accum_Stg]  set [updstatus]='' where [updstatus] is null;        
        
        
        
--- insert records to  memaccumulator                   
IF ( @InsertAffected > 0 )                   
  BEGIN                   
      INSERT INTO  [plandata_QNXT_OHIO].[dbo].[memaccumulator]              
                  (memid,                   
                   accumid,                   
                   effdate,                   
                   accumvalue,                   
                   createid,                   
                   createdate,                   
                   updateid,                   
                   lastupdate)                   
      SELECT t.memid,                   
             @varAccumid,                   
             t.effdate,                   
             t.accumamt,                   
             MBU_FileloadID,                   
             Getdate(),                   
             MBU_FileloadID,                   
             Getdate()                   
      FROM  dbo.tbl_cvs_accum_stg t                   
      WHERE  t.[updstatus] = 'I';                   
  END            
         
		 
END     
 