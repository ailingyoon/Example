 
USE [PlanAudit_OH]

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE  PROCEDURE [EDI].[CVS_RX_CET_Claims_CreateTempTables]
	
AS

	SET NOCOUNT ON;
	
	-- Delete temp table if it exists --

 IF OBJECT_ID('EDI.CVS_CET_CLAIMS_RAW','U') IS NOT NULL
  BEGIN
   DROP TABLE EDI.CVS_CET_CLAIMS_RAW
 END

 
 --- Create temp table
 
 CREATE TABLE [EDI].[CVS_CET_CLAIMS_RAW] (
[RECORD_IDENTIFIER] NVARCHAR(1),
[CARRIER_ID] NVARCHAR(20),
[ACCOUNT_ID] NVARCHAR(15),
[GROUP_ID] NVARCHAR(15),
[CARDHOLDER_ID] NVARCHAR(20),
[ALT_CARDHOLDER_ID] NVARCHAR(20),
[CARE_FACILITY_ID] NVARCHAR(10),
[PERSON_CODE] NVARCHAR(3),
[CARDHOLDER_LAST_NAME] NVARCHAR(25),
[CARDHOLDER_FIRST_NAME] NVARCHAR(15),
[CARDHOLDER_MIDDLE_INITIAL] NVARCHAR(1),
[PATIENT_LAST_NAME] NVARCHAR(25),
[PATIENT_FIRST_NAME] NVARCHAR(15),
[PATIENT_BIRTHDATE] NVARCHAR(8),
[PATIENT_SEX] NVARCHAR(1),
[RELATIONSHIP_CODE] NVARCHAR(1),
[CHECK_DATE] NVARCHAR(8),
[FILLER_1] NVARCHAR(12),
[PROVIDER_ID] NVARCHAR(15),
[PROVIDER_ID_QUALIFIER] NVARCHAR(2),
[PROVIDER_NAME] NVARCHAR(20),
[NETWORK_ID] NVARCHAR(6),
[FILLER_2] NVARCHAR(10),
[DATE_FILLED] NVARCHAR(8),
[DATE_RX_WRITTEN] NVARCHAR(8),
[RX_CLAIM_DATE_PROCESSED] NVARCHAR(8),
[TRANSACTION_ID] NVARCHAR(18),
[CLAIM_STATUS_FLAG] NVARCHAR(1),
[CLAIM_ORIGINATION_FLAG] NVARCHAR(1),
[REIMBURSEMENT_TYPE] NVARCHAR(1),
[NEW_REFILL_NUMBER] NVARCHAR(2),
[NUM_REFILLS_AUTHORIZED] NVARCHAR(2),
[PRICE_SOURCE_INDICATOR] NVARCHAR(10),
[PRODUCT_ID] NVARCHAR(20),
[PRODUCT_ID_QUALIFIER] NVARCHAR(2),
[DRUG_LABEL_NAME] NVARCHAR(30),
[DRUG_ADMIN_ROUTE_CODE] NVARCHAR(2),
[GPI_CODE] NVARCHAR(14),
[MED_B_MED_D_INDICATOR] NVARCHAR(1),
[FILLER_3] NVARCHAR(4),
[GENERIC_CLASS] NVARCHAR(5),
[GPI_NAME] NVARCHAR(60),
[GENERIC_BRAND_INDICATOR] NVARCHAR(1),
[THERAPEUTIC_CLASS] NVARCHAR(6),
[MULTI_SOURCE_INDICATOR] NVARCHAR(1),
[DRUG_DOSAGE_FORM] NVARCHAR(4),
[UNIT_OF_MEASURE] NVARCHAR(10),
[DEA_CLASS] NVARCHAR(2),
[COMPOUND_INDICATOR] NVARCHAR(1),
[PRODUCT_SELECTION_CODE] NVARCHAR(1),
[OTHER_COVERAGE] NVARCHAR(1),
[PAYABLE_QUANTITY] NVARCHAR(11),
[PHARMACY_AMOUNT_SUBMITTED] NVARCHAR(9),
[DAYS_SUPPLY] NVARCHAR(3),
[SUBMITTED_INGREDIENT_COST] NVARCHAR(9),
[INGREDIENT_COST_PAYABLE] NVARCHAR(9),
[SUBMITTED_DISPENSING_FEE] NVARCHAR(9),
[DISPENSING_FEE_PAYABLE] NVARCHAR(9),
[SUBMITTED_SALES_TAX] NVARCHAR(9),
[SALES_TAX_PAYABLE] NVARCHAR(9),
[SUBMITTED_GROSS_AMT_DUE] NVARCHAR(9),
[AMOUNT_BILLED] NVARCHAR(9),
[SUBMITTED_PATIENT_PAY_AMT] NVARCHAR(9),
[PATIENT_PAY_AMT] NVARCHAR(9),
[FLAT_COPAY_AMT_PAID] NVARCHAR(9),
[PERCENT_COPAY_AMT_PAID] NVARCHAR(9),
[ADMIN_FEE] NVARCHAR(5),
[MAINTENANCE_DRUG_IND] NVARCHAR(1),
[FINAL_PLAN_CODE] NVARCHAR(10),
[PLAN_CODE_EXTENSION] NVARCHAR(8),
[FILLER_4] NVARCHAR(1),
[CARDHOLDER_COPAY_DIFFERENTIAL] NVARCHAR(9),
[FRONT_END_DEDUCTABLE_AMT] NVARCHAR(9),
[AFTER_MAX_AMT] NVARCHAR(9),
[TOTAL_COPAY_AMT] NVARCHAR(9),
[PATIENT_ACCUM_DEDUCT_AMT] NVARCHAR(9),
[DISPENSER_TYPE] NVARCHAR(3),
[AWP] NVARCHAR(10),
[AWP_TYPE_IND] NVARCHAR(1),
[BILLING_REPORTING_CODE] NVARCHAR(3),
[FORMULARY_IND_STATUS] NVARCHAR(1),
[REJECT_CODE_1] NVARCHAR(3),
[PRIOR_AUTH_NUMBER] NVARCHAR(11),
[PRIOR_AUTH_REASON_CODES] NVARCHAR(2),
[PA_MC_SC_CODE] NVARCHAR(12),
[BASIS_OF_COST_DETERM] NVARCHAR(2),
[PRESCRIBER_NUMBER] NVARCHAR(15),
[PRESCRIBER_ID_QUALIFIER] NVARCHAR(2),
[PERF_RX_PHARMACY_FEE_PAID] NVARCHAR(5),
[PERF_RX_FEE_PAID] NVARCHAR(5),
[HIPAA_RX_NUMBER] NVARCHAR(15),
[RX_NUMBER_QUALIFIER] NVARCHAR(1),
[ADJUSTMENT_REASON_CODE] NVARCHAR(3),
[ADJUSTMENT_ISSUE_ID] NVARCHAR(10),
[REBILL_INCENTIVE] NVARCHAR(9),
[VACCINE_CLAIM_IND] NVARCHAR(1),
[CARE_NETWORK] NVARCHAR(10),
[CARE_QUALIFIER] NVARCHAR(10),
[COB_PRIMARY_PAYER_AMT_PAID] NVARCHAR(8),
[APPLIED_HRA_AMT] NVARCHAR(11),
[BILLING_CYCLE_END_DATE] NVARCHAR(8),
[MAINTENANCE_CHOICE_IND] NVARCHAR(1),
[OPAR_AMT] NVARCHAR(8),
[DRUG_STRENGTH] NVARCHAR(11),
[DRUG_NAME] NVARCHAR(70),
[FILLER_5] NVARCHAR(6),
[RX_ORIGIN_CODE] NVARCHAR(1)

)
GO 



EXEC [EDI].[CVS_RX_CET_Claims_CreateTempTables];
GO

 IF OBJECT_ID('[EDI].[CVS_Rx_CET_Claim]','U') IS NOT NULL
  BEGIN
   DROP TABLE [EDI].[CVS_Rx_CET_Claim]
 END


 
CREATE TABLE [EDI].[CVS_Rx_CET_Claim](
	[RECORD_IDENTIFIER] [varchar](1) NULL,
	[CARRIER_ID] [varchar](20) NULL,
	[ACCOUNT_ID] [varchar](15) NULL,
	[GROUP_ID] [varchar](15) NULL,
	[CARDHOLDER_ID] [varchar](20) NULL,
	[ALT_CARDHOLDER_ID] [varchar](20) NULL,
	[CARE_FACILITY_ID] [varchar](10) NULL,
	[PERSON_CODE] [varchar](3) NULL,
	[CARDHOLDER_LAST_NAME] [varchar](25) NULL,
	[CARDHOLDER_FIRST_NAME] [varchar](15) NULL,
	[CARDHOLDER_MIDDLE_INITIAL] [varchar](1) NULL,
	[PATIENT_LAST_NAME] [varchar](25) NULL,
	[PATIENT_FIRST_NAME] [varchar](15) NULL,
	[PATIENT_BIRTHDATE] [datetime] NULL,
	[PATIENT_SEX] [varchar](1) NULL,
	[RELATIONSHIP_CODE] [varchar](1) NULL,
	[CHECK_DATE] [datetime] NULL,
	[PROVIDER_ID] [varchar](15) NULL,
	[PROVIDER_ID_QUALIFIER] [varchar](2) NULL,
	[PROVIDER_NAME] [varchar](20) NULL,
	[NETWORK_ID] [varchar](6) NULL,
	[DATE_FILLED] [datetime] NULL,
	[DATE_RX_WRITTEN] [datetime] NULL,
	[RX_CLAIM_DATE_PROCESSED] [datetime] NULL,
	[TRANSACTION_ID] [varchar](18) NULL,
	[CLAIM_STATUS_FLAG] [varchar](1) NULL,
	[CLAIM_ORIGINATION_FLAG] [varchar](1) NULL,
	[REIMBURSEMENT_TYPE] [varchar](1) NULL,
	[NEW_REFILL_NUMBER] [varchar](2) NULL,
	[NUM_REFILLS_AUTHORIZED] [int] NULL,
	[PRICE_SOURCE_INDICATOR] [varchar](10) NULL,
	[PRODUCT_ID] [varchar](20) NULL,
	[PRODUCT_ID_QUALIFIER] [varchar](2) NULL,
	[DRUG_LABEL_NAME] [varchar](30) NULL,
	[DRUG_ADMIN_ROUTE_CODE] [varchar](2) NULL,
	[GPI_CODE] [varchar](14) NULL,
	[MED_B_MED_D_INDICATOR] [varchar](1) NULL,
	[GENERIC_CLASS] [varchar](5) NULL,
	[GPI_NAME] [varchar](60) NULL,
	[GENERIC_BRAND_INDICATOR] [varchar](1) NULL,
	[THERAPEUTIC_CLASS] [varchar](6) NULL,
	[MULTI_SOURCE_INDICATOR] [varchar](1) NULL,
	[DRUG_DOSAGE_FORM] [varchar](4) NULL,
	[UNIT_OF_MEASURE] [varchar](10) NULL,
	[DEA_CLASS] [varchar](2) NULL,
	[COMPOUND_INDICATOR] [varchar](1) NULL,
	[PRODUCT_SELECTION_CODE] [varchar](1) NULL,
	[OTHER_COVERAGE] [varchar](1) NULL,
	[PAYABLE_QUANTITY] [decimal](12, 3) NULL,
	[PHARMACY_AMOUNT_SUBMITTED] [decimal](10, 2) NULL,
	[DAYS_SUPPLY] [int] NULL,
	[SUBMITTED_INGREDIENT_COST] [decimal](10, 2) NULL,
	[INGREDIENT_COST_PAYABLE] [decimal](10, 2) NULL,
	[SUBMITTED_DISPENSING_FEE] [decimal](10, 2) NULL,
	[DISPENSING_FEE_PAYABLE] [decimal](10, 2) NULL,
	[SUBMITTED_SALES_TAX] [decimal](10, 2) NULL,
	[SALES_TAX_PAYABLE] [decimal](10, 2) NULL,
	[SUBMITTED_GROSS_AMT_DUE] [decimal](10, 2) NULL,
	[AMOUNT_BILLED] [decimal](10, 2) NULL,
	[SUBMITTED_PATIENT_PAY_AMT] [decimal](10, 2) NULL,
	[PATIENT_PAY_AMT] [decimal](10, 2) NULL,
	[FLAT_COPAY_AMT_PAID] [decimal](10, 2) NULL,
	[PERCENT_COPAY_AMT_PAID] [decimal](10, 2) NULL,
	[ADMIN_FEE] [decimal](10, 2) NULL,
	[MAINTENANCE_DRUG_IND] [varchar](1) NULL,
	[FINAL_PLAN_CODE] [varchar](10) NULL,
	[PLAN_CODE_EXTENSION] [varchar](8) NULL,
	[CARDHOLDER_COPAY_DIFFERENTIAL] [decimal](10, 2) NULL,
	[FRONT_END_DEDUCTABLE_AMT] [decimal](10, 2) NULL,
	[AFTER_MAX_AMT] [decimal](10, 2) NULL,
	[TOTAL_COPAY_AMT] [decimal](10, 2) NULL,
	[PATIENT_ACCUM_DEDUCT_AMT] [decimal](10, 2) NULL,
	[DISPENSER_TYPE] [varchar](3) NULL,
	[AWP] [decimal](15, 5) NULL,
	[AWP_TYPE_IND] [varchar](1) NULL,
	[BILLING_REPORTING_CODE] [varchar](3) NULL,
	[FORMULARY_IND_STATUS] [varchar](1) NULL,
	[REJECT_CODE_1] [varchar](3) NULL,
	[PRIOR_AUTH_NUMBER] [varchar](11) NULL,
	[PRIOR_AUTH_REASON_CODES] [varchar](2) NULL,
	[PA_MC_SC_CODE] [varchar](12) NULL,
	[BASIS_OF_COST_DETERM] [varchar](2) NULL,
	[PRESCRIBER_NUMBER] [varchar](15) NULL,
	[PRESCRIBER_ID_QUALIFIER] [varchar](2) NULL,
	[PERF_RX_PHARMACY_FEE_PAID] [decimal](10, 2) NULL,
	[PERF_RX_FEE_PAID] [decimal](10, 2) NULL,
	[HIPAA_RX_NUMBER] [varchar](15) NULL,
	[RX_NUMBER_QUALIFIER] [varchar](1) NULL,
	[ADJUSTMENT_REASON_CODE] [varchar](3) NULL,
	[ADJUSTMENT_ISSUE_ID] [varchar](10) NULL,
	[REBILL_INCENTIVE] [decimal](10, 2) NULL,
	[VACCINE_CLAIM_IND] [varchar](1) NULL,
	[CARE_NETWORK] [varchar](10) NULL,
	[CARE_QUALIFIER] [varchar](10) NULL,
	[COB_PRIMARY_PAYER_AMT_PAID] [decimal](10, 2) NULL,
	[APPLIED_HRA_AMT] [decimal](10, 2) NULL,
	[BILLING_CYCLE_END_DATE] [datetime] NULL,
	[MAINTENANCE_CHOICE_IND] [varchar](1) NULL,
	[OPAR_AMT] [decimal](10, 2) NULL,
	[DRUG_STRENGTH] [decimal](15, 3) NULL,
	[DRUG_NAME] [varchar](70) NULL,
	[MBU_FileName] [varchar](60) NULL,
	[MBU_FileLoadDate] [datetime] NULL,
	[MBU_FileLoadID] [varchar](20) NULL,
	[RX_ORIGIN_CODE] [varchar](1) NULL,
	[SUBMISSION_CLARIFICATION_CODE1] [varchar](2) NULL,
	[SUBMISSION_CLARIFICATION_CODE2] [varchar](2) NULL,
	[SUBMISSION_CLARIFICATION_CODE3] [varchar](2) NULL
) ON [DATA]

GO

ALTER TABLE [EDI].[CVS_Rx_CET_Claim] ADD  DEFAULT (' ') FOR [RX_ORIGIN_CODE]
GO
 


 IF OBJECT_ID('[EDI].[CVS_Rx_CET_Claim_Batch_Control]','U') IS NOT NULL
  BEGIN
   DROP TABLE [EDI].[CVS_Rx_CET_Claim_Batch_Control]
 END

GO


CREATE TABLE [EDI].[CVS_Rx_CET_Claim_Batch_Control](
	[RECORD_IDENTIFIER] [varchar](1) NULL,
	[TOTAL_NUM_OF_CLAIMS] [bigint] NULL,
	[TOTAL_AMOUNT_PAYABLE] [decimal](15, 2) NULL,
	[TOTAL_ADMIN_FEE_AMT] [decimal](10, 2) NULL,
	[MBU_FileName] [varchar](60) NULL,
	[MBU_FileLoadDate] [datetime] NULL,
	[MBU_FileLoadID] [varchar](20) NULL
) ON [DATA]

GO


 

 IF OBJECT_ID('[EDI].[CVS_Rx_CET_Claim_Processor]','U') IS NOT NULL
  BEGIN
   DROP TABLE [EDI].[CVS_Rx_CET_Claim_Processor]
 END

GO


CREATE TABLE [EDI].[CVS_Rx_CET_Claim_Processor](
	[RECORD_IDENTIFIER] [varchar](1) NULL,
	[RUN_DATE] [datetime] NULL,
	[SENDING_COMPANY_NAME] [varchar](20) NULL,
	[CYCLE_START_DATE] [datetime] NULL,
	[CYCLE_END_DATE] [datetime] NULL,
	[MBU_FileName] [varchar](60) NULL,
	[MBU_FileLoadDate] [datetime] NULL,
	[MBU_FileLoadID] [varchar](20) NULL
) ON [DATA]

GO



create   PROCEDURE [EDI].[CVS_RX_CET_Claims_Insert]      
      
@FileName varchar (60) = null      
        
AS      
BEGIN      
       
 SET NOCOUNT ON;      
       
--------------------------------------------------------------------------------------------------------       
--     Processor Data - Header Record      
--------------------------------------------------------------------------------------------------------       
BEGIN      
      
Truncate table  EDI.CVS_Rx_CET_Claim_Batch_Control  ;    
Truncate table  EDI.CVS_Rx_CET_Claim  ;    
Truncate table EDI.CVS_Rx_CET_Claim_Processor  ;    
    
      
INSERT INTO EDI.CVS_Rx_CET_Claim_Processor      
(      
      RECORD_IDENTIFIER,      
      RUN_DATE,      
      SENDING_COMPANY_NAME,      
      CYCLE_START_DATE,      
      CYCLE_END_DATE,      
      MBU_FileName      
            
      )      
      
SELECT Record_Identifier,      
       EDI.CVSDateFormat(Carrier_ID),      
       SUBSTRING(CARRIER_ID,9,20),       
       EDI.CVSDateFormat(LTRIM(ACCOUNT_ID + GROUP_ID)),      
       EDI.CVSHeaderCycleEndDate(GROUP_ID),      
       @FileName       
            
           
FROM EDI.CVS_CET_CLAIMS_RAW      
WHERE RECORD_IDENTIFIER = 0      
END      
-------------------------------------------------------------------------------------------------------      
--Claims (Detail) Data      
--Convert data to correct data types      
--------------------------------------------------------------      
INSERT INTO EDI.CVS_Rx_CET_Claim      
      
SELECT        
   RECORD_IDENTIFIER      
      ,CARRIER_ID      
      ,ACCOUNT_ID      
      ,GROUP_ID      
      ,CARDHOLDER_ID      
      ,ALT_CARDHOLDER_ID      
      ,CARE_FACILITY_ID      
      ,PERSON_CODE      
      ,CARDHOLDER_LAST_NAME      
      ,CARDHOLDER_FIRST_NAME      
      ,CARDHOLDER_MIDDLE_INITIAL      
      ,PATIENT_LAST_NAME      
      ,PATIENT_FIRST_NAME      
      ,EDI.CVSDateFormat(PATIENT_BIRTHDATE)         
      ,PATIENT_SEX      
      ,RELATIONSHIP_CODE      
      ,EDI.CVSDateFormat(CHECK_DATE)         
      ,PROVIDER_ID      
      ,PROVIDER_ID_QUALIFIER      
      ,PROVIDER_NAME      
      ,NETWORK_ID      
      ,EDI.CVSDateFormat(DATE_FILLED)           
      ,EDI.CVSDateFormat(DATE_RX_WRITTEN)         
      ,EDI.CVSDateFormat(RX_CLAIM_DATE_PROCESSED)       
      ,TRANSACTION_ID      
      ,CLAIM_STATUS_FLAG      
      ,CLAIM_ORIGINATION_FLAG      
      ,REIMBURSEMENT_TYPE      
      ,NEW_REFILL_NUMBER      
      ,NUM_REFILLS_AUTHORIZED   = CAST(EDI.CVSTranslateOverpunch(NUM_REFILLS_AUTHORIZED) AS INT)      
      ,PRICE_SOURCE_INDICATOR      
      ,PRODUCT_ID      
      ,PRODUCT_ID_QUALIFIER      
      ,DRUG_LABEL_NAME --DRUG_NAME      
      ,DRUG_ADMIN_ROUTE_CODE      
      ,GPI_CODE      
      ,MED_B_MED_D_INDICATOR      
      ,GENERIC_CLASS      
      ,GPI_NAME --GENERIC_NAME      
      ,GENERIC_BRAND_INDICATOR      
      ,THERAPEUTIC_CLASS      
      ,MULTI_SOURCE_INDICATOR      
      ,DRUG_DOSAGE_FORM      
      ,UNIT_OF_MEASURE --DRUG_STRENGTH      
      ,DEA_CLASS      
      ,COMPOUND_INDICATOR      
      ,PRODUCT_SELECTION_CODE      
      ,OTHER_COVERAGE      
      ,PAYABLE_QUANTITY    = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(PAYABLE_QUANTITY))/1000 AS Decimal( 10, 3))      
      ,PHARMACY_AMOUNT_SUBMITTED  = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(PHARMACY_AMOUNT_SUBMITTED))/100 AS Decimal( 10, 2))      
      ,DAYS_SUPPLY     = CAST(EDI.CVSTranslateOverpunch(DAYS_SUPPLY) AS INT)      
      ,SUBMITTED_INGREDIENT_COST  = CAST(CONVERT(FLOAT,EDI.CVSTranslateOverpunch(SUBMITTED_INGREDIENT_COST))/100 AS Decimal( 10, 2))      
      ,INGREDIENT_COST_PAYABLE  = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(INGREDIENT_COST_PAYABLE))/100 AS Decimal( 10, 2))      
  ,SUBMITTED_DISPENSING_FEE  = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(SUBMITTED_DISPENSING_FEE))/100 AS Decimal( 10, 2))      
      ,DISPENSING_FEE_PAYABLE   = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(DISPENSING_FEE_PAYABLE))/100 AS Decimal( 10, 2))      
      ,SUBMITTED_SALES_TAX   = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(SUBMITTED_SALES_TAX))/100 AS Decimal( 10, 2))      
      ,SALES_TAX_PAYABLE    = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(SALES_TAX_PAYABLE))/100 AS Decimal( 10, 2))      
      ,SUBMITTED_GROSS_AMT_DUE  = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(SUBMITTED_GROSS_AMT_DUE))/100 AS Decimal( 10, 2))      
      ,AMOUNT_BILLED    = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(AMOUNT_BILLED))/100 AS Decimal( 10, 2))      
      ,SUBMITTED_PATIENT_PAY_AMT  = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(SUBMITTED_PATIENT_PAY_AMT))/100 AS Decimal( 10, 2))      
      ,PATIENT_PAY_AMT    = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(PATIENT_PAY_AMT))/100 AS Decimal( 10, 2))      
      ,FLAT_COPAY_AMT_PAID   = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(FLAT_COPAY_AMT_PAID))/100 AS Decimal( 10, 2))      
      ,PERCENT_COPAY_AMT_PAID   = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(PERCENT_COPAY_AMT_PAID))/100 AS Decimal( 10, 2))      
      ,ADMIN_FEE     = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(ADMIN_FEE))/100 AS Decimal( 10, 2))      
      ,MAINTENANCE_DRUG_IND      
      ,FINAL_PLAN_CODE      
      ,PLAN_CODE_EXTENSION      
      ,CARDHOLDER_COPAY_DIFFERENTIAL = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(CARDHOLDER_COPAY_DIFFERENTIAL))/100 AS Decimal( 10, 2))      
      ,FRONT_END_DEDUCTABLE_AMT  = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(FRONT_END_DEDUCTABLE_AMT))/100 AS Decimal( 10, 2))      
      ,AFTER_MAX_AMT    = CAST(CONVERT(FLOAT,EDI.CVSTranslateOverpunch(AFTER_MAX_AMT))/100 AS Decimal( 10, 2))      
      ,TOTAL_COPAY_AMT    = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(TOTAL_COPAY_AMT))/100 AS Decimal( 10, 2))      
      ,PATIENT_ACCUM_DEDUCT_AMT  = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(PATIENT_ACCUM_DEDUCT_AMT))/100 AS Decimal( 10, 2))      
      ,DISPENSER_TYPE      
      ,AWP      = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(AWP))/100000 AS Decimal( 15, 5))      
      ,AWP_TYPE_IND      
      ,BILLING_REPORTING_CODE      
      ,FORMULARY_IND_STATUS      
      ,REJECT_CODE_1      
      ,PRIOR_AUTH_NUMBER      
      ,PRIOR_AUTH_REASON_CODES      
      ,PA_MC_SC_CODE      
      ,BASIS_OF_COST_DETERM      
      ,PRESCRIBER_NUMBER      
      ,PRESCRIBER_ID_QUALIFIER      
      ,PERF_RX_PHARMACY_FEE_PAID  = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(PERF_RX_PHARMACY_FEE_PAID))/100 AS Decimal( 10, 2))      
      ,PERF_RX_FEE_PAID    = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(PERF_RX_FEE_PAID))/100 AS Decimal( 10, 2))      
      ,HIPAA_RX_NUMBER      
      ,RX_NUMBER_QUALIFIER      
      ,ADJUSTMENT_REASON_CODE      
      ,ADJUSTMENT_ISSUE_ID      
      ,REBILL_INCENTIVE    = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(REBILL_INCENTIVE))/100 AS Decimal( 10, 2))      
      ,VACCINE_CLAIM_IND      
      ,CARE_NETWORK      
      ,CARE_QUALIFIER      
      ,COB_PRIMARY_PAYER_AMT_PAID  = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(COB_PRIMARY_PAYER_AMT_PAID))/100 AS Decimal( 10, 2))      
      ,APPLIED_HRA_AMT    = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(APPLIED_HRA_AMT))/100 AS Decimal( 10, 2))      
      ,EDI.CVSDateFormat(BILLING_CYCLE_END_DATE)        
      ,MAINTENANCE_CHOICE_IND      
      ,OPAR_AMT     = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(OPAR_AMT))/100 AS Decimal( 10, 2))      
      ,DRUG_STRENGTH = CAST(CONVERT(FLOAT, EDI.CVSTranslateOverpunch(DRUG_STRENGTH))/1000 AS Decimal( 11, 3))      
      ,DRUG_NAME      
   ,MBU_FileName     = @FileName      
      ,MBU_FileLoadDate    = getdate()      
      ,MBU_FileLoadID     = suser_sname()      
     ,RX_ORIGIN_CODE      
  ,SUBSTRING([FILLER_1],1,2) AS SUBMISSION_CLARIFICATION_CODE1       
  ,SUBSTRING([FILLER_1],3,2) AS SUBMISSION_CLARIFICATION_CODE2       
  ,SUBSTRING([FILLER_1],5,2) AS SUBMISSION_CLARIFICATION_CODE3      
      
  FROM EDI.CVS_CET_CLAIMS_RAW      
WHERE RECORD_IDENTIFIER = 4      
       
END      
      
---------------------------------------------------------------------------------------      
---          Batch Control - Insert Trailer Data      
---------------------------------------------------------------------------------------      
Begin      
 INSERT INTO EDI.CVS_Rx_CET_Claim_Batch_Control      
  ( RECORD_IDENTIFIER,      
    TOTAL_NUM_OF_CLAIMS,      
    TOTAL_AMOUNT_PAYABLE,      
    TOTAL_ADMIN_FEE_AMT,      
    MBU_FileName      
          
  )      
  SELECT RECORD_IDENTIFIER,      
CAST(EDI.CVSTranslateOverpunch(left(CARRIER_ID,9))as BigInt),      
         CAST(CONVERT(FLOAT,EDI.CVSTranslateOverpunch(SUBSTRING(Carrier_ID + Account_ID,10,14)))/100 AS DECIMAL(10,2)),      
         CAST(CONVERT(FLOAT,EDI.CVSTranslateOverpunch(SUBSTRING(Carrier_ID + Account_ID,24,9)))/100 AS DECIMAL(10,2)),      
         @FileName       
      
FROM EDI.CVS_CET_CLAIMS_RAW      
WHERE RECORD_IDENTIFIER = 8      
      
      
END  



USE [PlanAudit_OH]
GO

/****** Object:  Table [EDI].[tbl_CVS_Accum_Stg]    Script Date: 12/6/2018 4:48:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [EDI].[tbl_CVS_Accum_Stg](
	[Memid] [varchar](25) NULL,
	[carriermemid] [varchar](30) NULL,
	[AccumAmt] [numeric](10, 2) NULL,
	[updstatus] [char](1) NULL,
	[MBU_Filename] [varchar](100) NULL,
	[MBU_Fileloaddate] [smalldatetime] NULL,
	[MBU_FileloadID] [varchar](25) NULL,
	[EffDate] [date] NULL
) ON [DATA]

GO


CREATE TABLE [EDI].[tbl_CVS_Accum_Stg_History](
	[Memid] [varchar](25) NULL,
	[carriermemid] [varchar](30) NULL,
	[AccumAmt] [numeric](10, 2) NULL,
	[updstatus] [char](1) NULL,
	[MBU_Filename] [varchar](100) NULL,
	[MBU_Fileloaddate] [smalldatetime] NULL,
	[MBU_FileloadID] [varchar](25) NULL,
	[EffDate] [date] NULL,
	[CreateDate] [smalldatetime] NULL
) ON [DATA]

GO

CREATE TABLE [EDI].[tbl_Accum_Logger](
	[Memid] [varchar](25) NULL,
	[carriermemid] [varchar](30) NULL,
	[AccumAmt] [numeric](10, 2) NULL,
	[updstatus] [char](1) NULL,
	[MBU_Filename] [varchar](100) NULL,
	[MBU_Fileloaddate] [smalldatetime] NULL,
	[MBU_FileloadID] [varchar](25) NULL,
	[EffDate] [date] NULL,
	[ErrReason] [varchar](200) NULL
) ON [DATA]

GO



CREATE  PROCEDURE [EDI].usp_GetMemid_Accum              
AS            
BEGIN            
              
 truncate table [PlanAudit_OH].[EDI].[tbl_CVS_Accum_Stg] ;            
            
 --DECLARE @AetnaID varchar(40) =CURRENT_USER;             
 --DECLARE  @varAccumid VARCHAR(20)='DV00015724';            
 declare @mbu_filename varchar(100),@MBU_Fileloaddate smalldatetime ,@MBU_FileloadID varchar(20);            
 SET NOCOUNT ON;             
            
             
select  top 1 @mbu_filename=MBU_Filename ,@MBU_Fileloaddate=MBU_Fileloaddate,@MBU_FileloadID=MBU_FileloadID             
from [PlanAudit_OH].[EDI].[cvs_rx_cet_claim] c  ;            
             
INSERT INTO [EDI].[tbl_cvs_accum_stg]             
            ([carriermemid],            
             [accumamt],             
             [effdate],             
             [mbu_filename],             
             [mbu_fileloaddate],             
             [mbu_fileloadid])             
SELECT Rtrim(c.cardholder_id),             
       Sum (c.front_end_deductable_amt),             
       Cast (rx_claim_date_processed AS DATE) AS PaidDate,             
       @mbu_filename,             
       @MBU_Fileloaddate,             
       @MBU_FileloadID             
FROM   [PlanAudit_OH].[EDI].[cvs_rx_cet_claim] c             
WHERE  c.[med_b_med_d_indicator] = 'B'             
       AND c.claim_status_flag IN ( 'P', 'X' )             
GROUP  BY Rtrim(c.cardholder_id),             
          Cast (rx_claim_date_processed AS DATE);            
            
UPDATE T1            
SET    Memid = T2.memid              
FROM   [EDI].[tbl_cvs_accum_stg]  T1            
        LEFT JOIN planreport_qnxt_ohio.dbo.enrollkeys T2            
         ON T1.carriermemid = T2.carriermemid            
   where T2.programid = 'DVZHPQ000000048'             
  and (getdate() between T2.effdate and T2.termdate);  -- active member            
            
             
            
 --- IF memid cannot be find among active member then search for term member            
if exists(select 1 from [EDI].[tbl_cvs_accum_stg]  where Memid is null)             
BEGIN             
    UPDATE T1             
    SET    Memid = T2.memid             
    FROM   [EDI].[tbl_cvs_accum_stg] T1             
            LEFT JOIN planreport_qnxt_ohio.dbo.enrollkeys T2             
                ON T1.carriermemid = T2.carriermemid             
    WHERE  T1.memid IS NULL             
            AND T2.programid = 'DVZHPQ000000048'             
            AND T2.termdate < Getdate();             
END             
              
 ---- logging  error   
 insert into [EDI].[tbl_Accum_Logger]   
           ([Memid]  
           ,[carriermemid]  
           ,[AccumAmt]  
           ,[updstatus]  
           ,[MBU_Filename]  
           ,[MBU_Fileloaddate]  
           ,[MBU_FileloadID]  
           ,[EffDate]  
     ,ErrReason)       
select     [Memid]  
           ,[carriermemid]  
           ,[AccumAmt]  
           ,[updstatus]  
           ,[MBU_Filename]  
           ,[MBU_Fileloaddate]  
           ,[MBU_FileloadID]  
           ,[EffDate],'cannot find memid'  
from [EDI].[tbl_cvs_accum_stg] t where t.memid is null;     
            
END; 


    
      
      