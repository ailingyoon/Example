USE [Pharmacy]
GO



 
/****** Object:  Table [dbo].[AD.PLANFILE_Accum]    Script Date: 12/14/2018 9:38:33 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AD.PLANFILE_Accum](
	[PLANFILEID] [int] NOT NULL,
	[PLANID] [int] NOT NULL,
	[INPUTFOLDERPATH] [varchar](100) NULL,
	[PROCESSFOLDERPATH] [varchar](100) NULL,
	[FILENAMEPATTERN] [varchar](50) NULL,
	[CREATEID] [varchar](25) NULL,
	[CREATEDATE] [datetime] NULL,
	[UPDATEID] [varchar](25) NULL,
	[UPDATEDATE] [datetime] NULL,
	[MBU_SERVER] [varchar](25) NULL,
	[MBU_DATABASE] [varchar](25) NULL,
	[EDI_SERVER] [varchar](25) NULL,
	[EDI_DATABASE] [varchar](25) NULL,
	[NOTIFICATION] [varchar](200) NULL
) ON [DATA]

GO
 

INSERT INTO [dbo].[AD.PLANFILE_Accum]
           ([PLANFILEID]
           ,[PLANID]
           ,[INPUTFOLDERPATH]
           ,[PROCESSFOLDERPATH]
           ,[FILENAMEPATTERN]
           ,[CREATEID]
           ,[CREATEDATE]        
           ,[MBU_SERVER]
           ,[MBU_DATABASE]
           ,[EDI_SERVER]
           ,[EDI_DATABASE]
           ,[NOTIFICATION]
		    ,[UPDATEID]
		    ,[UPDATEDATE] )
     VALUES
           (1
           ,13 
           ,'\\midptmediap01\MBUEDIWork\ELIG\[yyyy]\OH\CVS\PAIDCLAIMS\'
           ,'\\midptmediap01\MBUEDIArchive\ELIG\[yyyy]\OH\CVS\PAIDCLAIMS\'
           ,'AET_CVS_OHDSNP_CET_DAILY_*'
           ,'MBUMWPSQLPROD'
           ,getdate() 
           ,'SRVQNXTRPTOHPROD'
           ,'PlanAudit_OH'
           ,'SRVQNXTOHPROD'
           ,'PlanEDI'
           ,'HonigmanM@AETNA.com;NguyenV@MercyCarePlan.com;DL06875@AETNA.com',
		   'N314740',
		   getdate());


SELECT * FROM [dbo].[AD.PLANFILE_Accum];
 
		    
 
 