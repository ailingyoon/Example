# WeihanLi.Npoi

NpoiExtensions for target framework net45 and netstandard2.0.

There' a lot of userful extensions for you, core fetures are as follows:

- mapping a excel file data to a `DataTable` or `List<TEntity>`
- export a `IEnumerable<TEntity>` or `DataTable` to Excel file or Excel file bytes or even write excel file stream to your stream
- export a `IEnumerable<TEntity>` or `DataTable` to csv file or bytes.
