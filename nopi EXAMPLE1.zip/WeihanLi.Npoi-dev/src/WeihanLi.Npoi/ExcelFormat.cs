﻿namespace WeihanLi.Npoi
{
    /// <summary>
    /// ExcelFormat
    /// </summary>
    public enum ExcelFormat : byte
    {
        Xlsx = 0,
        Xls = 1
    }
}
