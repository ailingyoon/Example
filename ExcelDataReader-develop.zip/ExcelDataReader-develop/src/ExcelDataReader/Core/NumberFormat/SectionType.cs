﻿namespace ExcelDataReader.Core.NumberFormat
{
    internal enum SectionType
    {
        General,
        Number,
        Fraction,
        Exponential,
        Date,
        Duration,
        Text,
    }
}