﻿namespace ExcelDataReader.Core.OpenXmlFormat
{
    internal enum XlsxElementType
    {
        Dimension,
        Row, 
        HeaderFooter,
        MergeCells,
        Cols
    }
}
