﻿namespace ExcelDataReader.Core
{
    internal class Col
    {
        public int Min { get; set; }

        public int Max { get; set; }

        public double Width { get; set; }

        public bool CustomWidth { get; set; }

        public bool Hidden { get; set; }
    }
}
