﻿namespace MakeScript
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gvWrite = new System.Windows.Forms.DataGridView();
            this.SEL = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvWrite)).BeginInit();
            this.SuspendLayout();
            // 
            // gvWrite
            // 
            this.gvWrite.AllowUserToAddRows = false;
            this.gvWrite.AllowUserToDeleteRows = false;
            this.gvWrite.BackgroundColor = System.Drawing.Color.LightYellow;
            this.gvWrite.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvWrite.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SEL});
            this.gvWrite.Dock = System.Windows.Forms.DockStyle.Top;
            this.gvWrite.Location = new System.Drawing.Point(0, 0);
            this.gvWrite.Name = "gvWrite";
            this.gvWrite.RowTemplate.Height = 24;
            this.gvWrite.Size = new System.Drawing.Size(968, 304);
            this.gvWrite.TabIndex = 17;
            // 
            // SEL
            // 
            this.SEL.HeaderText = "SEL";
            this.SEL.Name = "SEL";
            this.SEL.Width = 60;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(59, 344);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 33);
            this.button1.TabIndex = 18;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(968, 452);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gvWrite);
            this.Name = "Form3";
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.gvWrite)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gvWrite;
        private System.Windows.Forms.DataGridViewCheckBoxColumn SEL;
        private System.Windows.Forms.Button button1;
    }
}