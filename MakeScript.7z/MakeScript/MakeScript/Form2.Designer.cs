﻿namespace MakeScript
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gvWrite2 = new System.Windows.Forms.DataGridView();
            this.btnHand2 = new System.Windows.Forms.Button();
            this.txtCompWO = new System.Windows.Forms.TextBox();
            this.txtTemplate = new System.Windows.Forms.TextBox();
            this.txtwo = new System.Windows.Forms.TextBox();
            this.txtsummary = new System.Windows.Forms.TextBox();
            this.com2 = new System.Windows.Forms.ComboBox();
            this.btnWrite2 = new System.Windows.Forms.Button();
            this.btnReadTxt = new System.Windows.Forms.Button();
            this.btnMain = new System.Windows.Forms.Button();
            this.btnF3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvWrite2)).BeginInit();
            this.SuspendLayout();
            // 
            // gvWrite2
            // 
            this.gvWrite2.AllowUserToAddRows = false;
            this.gvWrite2.AllowUserToDeleteRows = false;
            this.gvWrite2.BackgroundColor = System.Drawing.Color.LightYellow;
            this.gvWrite2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvWrite2.Dock = System.Windows.Forms.DockStyle.Top;
            this.gvWrite2.Location = new System.Drawing.Point(0, 0);
            this.gvWrite2.Name = "gvWrite2";
            this.gvWrite2.RowTemplate.Height = 24;
            this.gvWrite2.Size = new System.Drawing.Size(1116, 145);
            this.gvWrite2.TabIndex = 18;
            this.gvWrite2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvWrite2_CellContentClick);
            // 
            // btnHand2
            // 
            this.btnHand2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHand2.Location = new System.Drawing.Point(567, 187);
            this.btnHand2.Name = "btnHand2";
            this.btnHand2.Size = new System.Drawing.Size(79, 39);
            this.btnHand2.TabIndex = 19;
            this.btnHand2.Text = "Hand 2";
            this.btnHand2.UseVisualStyleBackColor = true;
            this.btnHand2.Click += new System.EventHandler(this.btnHand2_Click);
            // 
            // txtCompWO
            // 
            this.txtCompWO.Font = new System.Drawing.Font("SimSun", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtCompWO.Location = new System.Drawing.Point(0, 238);
            this.txtCompWO.Multiline = true;
            this.txtCompWO.Name = "txtCompWO";
            this.txtCompWO.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCompWO.Size = new System.Drawing.Size(1104, 242);
            this.txtCompWO.TabIndex = 20;
            // 
            // txtTemplate
            // 
            this.txtTemplate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtTemplate.Font = new System.Drawing.Font("SimSun", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtTemplate.Location = new System.Drawing.Point(0, 486);
            this.txtTemplate.Multiline = true;
            this.txtTemplate.Name = "txtTemplate";
            this.txtTemplate.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTemplate.Size = new System.Drawing.Size(1116, 256);
            this.txtTemplate.TabIndex = 21;
            // 
            // txtwo
            // 
            this.txtwo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtwo.Location = new System.Drawing.Point(12, 151);
            this.txtwo.Name = "txtwo";
            this.txtwo.Size = new System.Drawing.Size(232, 29);
            this.txtwo.TabIndex = 22;
            // 
            // txtsummary
            // 
            this.txtsummary.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsummary.Location = new System.Drawing.Point(250, 151);
            this.txtsummary.Name = "txtsummary";
            this.txtsummary.Size = new System.Drawing.Size(746, 29);
            this.txtsummary.TabIndex = 23;
            // 
            // com2
            // 
            this.com2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.com2.FormattingEnabled = true;
            this.com2.Location = new System.Drawing.Point(12, 193);
            this.com2.Name = "com2";
            this.com2.Size = new System.Drawing.Size(421, 28);
            this.com2.TabIndex = 24;
            this.com2.SelectedIndexChanged += new System.EventHandler(this.com2_SelectedIndexChanged);
            // 
            // btnWrite2
            // 
            this.btnWrite2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWrite2.Location = new System.Drawing.Point(458, 187);
            this.btnWrite2.Name = "btnWrite2";
            this.btnWrite2.Size = new System.Drawing.Size(81, 39);
            this.btnWrite2.TabIndex = 25;
            this.btnWrite2.Text = "Write";
            this.btnWrite2.UseVisualStyleBackColor = true;
            this.btnWrite2.Click += new System.EventHandler(this.btnWrite2_Click);
            // 
            // btnReadTxt
            // 
            this.btnReadTxt.Location = new System.Drawing.Point(0, 0);
            this.btnReadTxt.Name = "btnReadTxt";
            this.btnReadTxt.Size = new System.Drawing.Size(75, 23);
            this.btnReadTxt.TabIndex = 28;
            // 
            // btnMain
            // 
            this.btnMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMain.ForeColor = System.Drawing.Color.Red;
            this.btnMain.Location = new System.Drawing.Point(849, 186);
            this.btnMain.Name = "btnMain";
            this.btnMain.Size = new System.Drawing.Size(61, 38);
            this.btnMain.TabIndex = 27;
            this.btnMain.Text = "F1";
            this.btnMain.UseVisualStyleBackColor = false;
            this.btnMain.Click += new System.EventHandler(this.btnMain_Click);
            // 
            // btnF3
            // 
            this.btnF3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnF3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF3.ForeColor = System.Drawing.Color.Red;
            this.btnF3.Location = new System.Drawing.Point(927, 184);
            this.btnF3.Name = "btnF3";
            this.btnF3.Size = new System.Drawing.Size(60, 42);
            this.btnF3.TabIndex = 29;
            this.btnF3.Text = "F3";
            this.btnF3.UseVisualStyleBackColor = false;
            this.btnF3.Click += new System.EventHandler(this.btnF3_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1116, 742);
            this.Controls.Add(this.btnF3);
            this.Controls.Add(this.btnMain);
            this.Controls.Add(this.btnReadTxt);
            this.Controls.Add(this.btnWrite2);
            this.Controls.Add(this.com2);
            this.Controls.Add(this.txtsummary);
            this.Controls.Add(this.txtwo);
            this.Controls.Add(this.txtTemplate);
            this.Controls.Add(this.txtCompWO);
            this.Controls.Add(this.btnHand2);
            this.Controls.Add(this.gvWrite2);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvWrite2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gvWrite2;
        private System.Windows.Forms.Button btnHand2;
        private System.Windows.Forms.TextBox txtCompWO;
        private System.Windows.Forms.TextBox txtTemplate;
        private System.Windows.Forms.TextBox txtwo;
        private System.Windows.Forms.TextBox txtsummary;
        private System.Windows.Forms.ComboBox com2;
        private System.Windows.Forms.Button btnWrite2;
        private System.Windows.Forms.Button btnReadTxt;
        private System.Windows.Forms.Button btnMain;
        private System.Windows.Forms.Button btnF3;
    }
}