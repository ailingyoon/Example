﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public class clsMoveC13
    {

   public  string clsMoveToC13 = @"
USE @QNXT
------------------------------------------------------
PRINT 'Update claimpend history'
------------------------------------------------------
SELECT cph.*
INTO BDU_TEMP.edi.[@EXCEL_cph]
FROM @QNXT..claimpendhistory cph (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON cph.claimid = tem.claimid
JOIN @QNXT..claimedit ce
ON ce.claimid = tem.claimid
WHERE cph.overrider = '' AND ce.ruleid IN ('913')
AND ce.status = 'PEND'

UPDATE cph SET overrider = 'PHX\EDIUser', overridedate = GETDATE()
FROM @QNXT..claimpendhistory cph (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON cph.claimid = tem.claimid
JOIN @QNXT..claimedit ce
ON ce.claimid = tem.claimid
WHERE cph.overrider = '' AND ce.ruleid IN ('913')
AND ce.status = 'PEND' 

 
/*------ Okay the claim EDITs----OR below description---*/
PRINT 'Okay edit where rule id = 913'

select ce.status, Count(*)
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline
where ruleid in ( '913')
group by ce.status

select ce.* 
into  [BDU_Temp].[EDI].[@EXCEL_ce1]
 from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline
where ruleid in ('913')

update ce set ce.status = 'OKAY', ce.clearby = 'PHX\EDIUser', ce.cleardate = getdate(), ce.state = 'MANUAL'
from @QNXT..claimedit ce (nolock)
join [BDU_Temp].[EDI].[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline
where ruleid in ('913')

------------------------------------------------------
PRINT 'Update existing memos'
------------------------------------------------------
SELECT m.*, tem.*, ROW_NUMBER() over (PARTITION BY cm.claimid ORDER BY m.createdate ASC) AS CreatedOrder
INTO BDU_TEMP.edi.[@EXCEL_ExistingMemos]
FROM @QNXT..memo m (NOLOCK)
JOIN @QNXT..claimmemo cm (NOLOCK)
ON m.memoid = cm.memoid
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON cm.claimid = tem.claimid
WHERE (
m.description LIKE 'P0%'
OR m.description LIKE 'P1%'
OR m.description LIKE 'H0%'
OR m.description LIKE 'H1%'
OR m.description LIKE 'H2%'
OR m.description LIKE 'H3%'
OR m.description LIKE 'H4%'
OR m.description LIKE 'H7%' 
OR m.description LIKE 'H9%'
OR m.description LIKE 'C0%'
OR m.description LIKE 'C1%'
OR m.description LIKE 'C2%'
OR m.description LIKE 'C3%'
OR m.description LIKE 'C4%'
OR m.description LIKE 'C5%'
OR m.description LIKE 'C6%'
OR m.description LIKE 'C7%'
OR m.description LIKE 'C8%'
OR m.description LIKE 'C9%'
) AND m.termdate =CONVERT(smalldatetime,'2078-12-31 00:00:00')


select m.* 
into  [BDU_Temp].[EDI].[@EXCEL_memo]
from @QNXT..memo m (nolock)
join @QNXT..claimmemo cm (nolock) on m.memoid = cm.memoid
join [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem
on cm.claimid = tem.claimid and m.memoid = tem.memoid
where CreatedOrder = 1

Declare @varInfo1 varchar(40)= '< ' + CONVERT(varchar(10),GETDATE(),101) +STUFF(RIGHT(CONVERT(varchar(26),GETDATE(),109),15),7,7, ' ' )+' – N314740 > '; 
update m set m.description = tem.excel_desc + ' ' + CAST(m.[description] as varchar(max)),
m.message = @varInfo1 + tem.excel_message + ' ' + CAST(m.[message] as varchar(max))
 from @QNXT..memo m (nolock)
 join @QNXT..claimmemo cm (nolock) on m.memoid = cm.memoid
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem
on  cm.claimid = tem.claimid and m.memoid = tem.memoid
where CreatedOrder = 1

------------------------------------------------------
PRINT 'Terminate additional memos'
------------------------------------------------------
SELECT m.*  
INTO  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos_term]
FROM  @QNXT..memo m (NOLOCK)
JOIN [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem
ON m.memoid = tem.memoid WHERE CreatedOrder> 1

update m set termdate = getdate() 
from  @QNXT..memo m (nolock)
join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] tem on  m.memoid = tem.memoid
where CreatedOrder> 1

------------------------------------------------------
PRINT 'claim memo does not exist, add a claim from excel'
------------------------------------------------------ 
Declare @varInfo2 varchar(40)= '< ' + CONVERT(varchar(10),GETDATE(),101) +STUFF(RIGHT(CONVERT(varchar(26),GETDATE(),109),15),7,7, ' ' )+' – N314740 > '; 
insert into [BDU_Temp].[EDI].insertmemo (environment, srcid, memoidQual, memotype, [message], source, [description])
select distinct '@QNXT', tem.claimid, 'C', 'WO'+substring('@WO',10,6), @varInfo2 + tem.excel_message,'claim', tem.excel_desc
from [BDU_Temp].[EDI].[@EXCEL]  tem
left join  [BDU_Temp].[EDI].[@EXCEL_ExistingMemos] em on tem.claimid = em.claimid
where  em.claimid is null

USE BDU_TEMP
EXEC usp_insertmemo '@QNXT'

SELECT COUNT (DISTINCT im.srcid), memoflag, createid
FROM  edi.insertmemo im(NOLOCK)
 JOIN BDU_TEMP.edi.[@EXCEL] tem
 ON tem.claimid= im.srcid
 WHERE createdate > GETDATE() - 0.1
 AND environment = '@QNXT'
 AND memotype = 'WO' + substring('@WO', 10, 6)
 GROUP BY memoflag, createid

";

    }
}
