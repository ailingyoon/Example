﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
public class clsCombo1
{ 
public string DENY_Reason16_AND_M119 = @"
/*Insert rule ID = 915, status = DENY, STATE = Manual, and Reason = 16 AND M119*/

---------------------------------------------------------------------
PRINT 'Update and insert primary reason 16'
---------------------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.EDI.[@EXCEL_ce]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND tem.claimline = ce.claimline
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ruleid IN ('915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')  

UPDATE ce
SET status = 'DENY', clearby = 'PHX\EDIUser', cleardate = GETDATE(), state = 'MANUAL', reason = '16'
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND tem.claimline = ce.claimline 		
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ruleid IN ('915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')  

SELECT ce.status, COUNT(*), ce.reason
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND tem.claimline = ce.claimline 		
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ruleid IN ('915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')  
GROUP BY ce.status, ce.reason

INSERT INTO @QNXT..claimedit (claimid, claimline, ruleid, status, reason,state)
SELECT DISTINCT tem.claimid, tem.claimline,'915','DENY','16', 'MANUAL' 
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND tem.claimline = ce.claimline
AND  ruleid IN ('915') AND ce.status = 'DENY'
AND ce.reason = '16'
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE  ce.claimid IS NULL
AND ce.claimline IS NULL
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND tem.claimid IS NOT NULL

SELECT ce.status, COUNT(*), ce.reason
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND tem.claimline = ce.claimline 		
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ruleid IN ('915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')  
GROUP BY ce.status, ce.reason

---------------------------------------------------------------------
PRINT 'Remit M119'
---------------------------------------------------------------------

DECLARE @overridemessage VARCHAR(600)
DECLARE @messageid VARCHAR(6)='M119'
DECLARE @messagetype VARCHAR(10)='remit'
SELECT @overridemessage = reporttext  FROM  @QNXT..rulereason  WHERE reasonid = @messageid  AND reasontype = @messagetype

PRINT @messagetype
PRINT @messageid
PRINT @overridemessage

INSERT INTO [@QNXT].[dbo].[claimeditmessage]
([claimid],[claimline],[ruleid],[messageid],[messagetype],[overridemessage])
SELECT DISTINCT [claimid], claimline, '915', @messageid, @messagetype, @overridemessage FROM BDU_TEMP.EDI.[@EXCEL] 
WHERE claimid IS NOT NULL
AND claimid + CONVERT(VARCHAR(20), claimline) NOT IN
(
	SELECT cem.claimid + CONVERT(VARCHAR(20), cem.claimline)
	FROM BDU_TEMP.EDI.[@EXCEL] tem
	JOIN [@QNXT].[dbo].[claimeditmessage] cem
	ON tem.claimid = cem.claimid
	WHERE cem.messageid = @messageid
)
 

";

public string CARC_RARC_combination = @"
---!!  CARC/RARC combination = @code/@remit  (example : 252/N706)
---!!  if tem.claimline not exist in excel, then put '0' to claimline 
select top 1 claimline from  BDU_TEMP.edi.[@EXCEL] order by claimid

---------------------------------------------------------------------
PRINT 'Update and insert primary reason'
PRINT 'for claimedit.claimline=0, insert claimedit.ruleid=915 to DENY, and Deny Claim with @code'
---------------------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.edi.[@EXCEL_ce]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid 		
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ruleid IN ('915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')  

UPDATE ce
SET status = 'DENY', clearby = 'PHX\EDIUser', cleardate = GETDATE(), state = 'MANUAL', reason = '@code'
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid 		
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ruleid IN ('915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')  

SELECT ce.status, COUNT(*), ce.reason
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid 		
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE ruleid IN ('915')
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')  
GROUP BY ce.status, ce.reason

INSERT INTO @QNXT..claimedit (claimid, claimline, ruleid, status, reason,state)
SELECT DISTINCT tem.claimid, 0,'915','DENY','@code', 'MANUAL' 
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid  
AND  ruleid IN ('915')
AND ce.status = 'DENY'
AND ce.reason = '@code'
JOIN @QNXT..claim clm (NOLOCK)
ON clm.claimid = tem.claimid
WHERE  ce.claimid IS NULL
AND ce.claimline IS NULL
AND clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
AND tem.claimid IS NOT NULL

---------------------------------------------------------------------
PRINT 'Remit @remit'
---------------------------------------------------------------------
DECLARE @overridemessage VARCHAR(500)
DECLARE @messageid VARCHAR(5)='@remit'
DECLARE @messagetype VARCHAR(6)='remit'
SELECT @overridemessage = reporttext
FROM  @QNXT..rulereason WHERE reasonid = @messageid AND reasontype = @messagetype

PRINT @messagetype
PRINT @messageid
PRINT @overridemessage 

INSERT INTO [@QNXT].[dbo].[claimeditmessage] 
([claimid],[claimline],[ruleid],[messageid],[messagetype],[overridemessage])
SELECT DISTINCT  claimid , '0', '915', @messageid, @messagetype, @overridemessage 
FROM BDU_TEMP.edi.[@EXCEL] 
WHERE claimid NOT IN
(
	SELECT cem.claimid
	FROM BDU_TEMP.edi.[@EXCEL] tem
	JOIN [@QNXT].[dbo].[claimeditmessage] cem
	ON tem.claimid = cem.claimid 
	WHERE cem.messageid = @messageid
    AND cem.claimline='0'
)
";


public string  ITWR_C35 = @"
---------------------------------------------
PRINT 'Insert PEND edit 913 with claimline 0'
---------------------------------------------
--Initial check
SELECT ce.status, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem 
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913')
AND ce.claimline = '0'
GROUP BY ce.status

--Backup
SELECT ce.*
INTO BDU_TEMP.edi.[@EXCEL_ce]
FROM BDU_TEMP.edi.[@EXCEL] tem (NOLOCK)
JOIN @QNXT..claim clm (NOLOCK)
ON tem.claimid = clm.claimid
JOIN @QNXT..claimedit ce (NOLOCK) 
ON clm.claimid = ce.claimid
AND ce.ruleid IN ('913')
AND ce.claimline = '0'
AND ce.status != 'PEND'

--Update
UPDATE ce SET status = 'PEND', state = 'MANUAL'
FROM BDU_TEMP.edi.[@EXCEL] tem (NOLOCK)
JOIN @QNXT..claim clm (NOLOCK)
ON tem.claimid = clm.claimid
JOIN @QNXT..claimedit ce (NOLOCK) 
ON clm.claimid = ce.claimid
AND ce.ruleid IN ('913')
AND ce.claimline = '0'
AND ce.status != 'PEND'


--Count before insert
SELECT COUNT(1)
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913')
AND ce.claimline = '0'
WHERE ce.claimid IS NULL
AND tem.claimid IS NOT NULL

--Insert 
INSERT INTO @QNXT..claimedit (claimid, claimline, status, ruleid, state)  
SELECT DISTINCT tem.ClaimID, '0','PEND', '913', 'MANUAL' -- 0 numeric or text? Either
-- SELECT ce.status, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913')
AND ce.claimline = '0'
WHERE ce.claimid IS NULL
AND tem.claimid IS NOT NULL
----------------------------------------------------
PRINT 'Update and insert claimpendhistory overrider'
-----------------------------------------------------
--Backup
SELECT cph.*
INTO BDU_TEMP.edi.[@EXCEL_CPH1]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK)
ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')
AND ce.claimline = '0'
AND cph.overrider = '' 

--Update
UPDATE cph
SET overridedate = GETDATE(), overrider = 'PHX\EDIUser'
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK)
ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')
AND ce.claimline = '0'
AND cph.overrider = ''

--Count before insert
SELECT COUNT(DISTINCT tem.claimid)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
LEFT JOIN @QNXT..claimpendhistory cph (NOLOCK)
ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')
AND ce.claimline = '0'
AND tem.claimid IS NOT NULL

--Insert
INSERT INTO @QNXT..claimpendhistory (claimid, pendreasonid, penddate)
SELECT DISTINCT tem.claimid, 'C35', GETDATE()
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem 
ON tem.claimid = ce.claimid
LEFT JOIN @QNXT..claimpendhistory cph (NOLOCK)
ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')
AND ce.claimline = '0'
AND tem.claimid IS NOT NULL

---------------------
PRINT 'Update memos'
---------------------
SELECT m.*, tem.*, ROW_NUMBER() over (PARTITION BY cm.claimid ORDER BY m.createdate ASC) AS MemoCreatedOrder
INTO  BDU_TEMP.edi.[@EXCEL_ExistingMemos]
FROM @QNXT..memo m (NOLOCK)
JOIN @QNXT..claimmemo cm (NOLOCK)
ON m.memoid = cm.memoid
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON cm.claimid = tem.claimid
WHERE (m.description LIKE 'B01%'
OR m.description LIKE 'B05%'
OR m.description LIKE 'B06%')
AND tem.claimid IS NOT NULL 
AND m.termdate =CONVERT(smalldatetime,'2078-12-31 00:00:00')


SELECT m.*
INTO BDU_TEMP.edi.[@EXCEL_memo22]
FROM @QNXT..memo m (NOLOCK)
JOIN @QNXT..claimmemo cm (NOLOCK)
ON m.memoid = cm.memoid
JOIN  BDU_TEMP.edi.[@EXCEL_ExistingMemos] tem
ON cm.claimid = tem.claimid
AND m.memoid = tem.memoid
--WHERE MemoCreatedOrder = 1

UPDATE m
SET m.description = 'C35 ' + CAST(m.description AS varchar(MAX)), 
m.message = '< ' + convert( varchar(10), getdate(), 101) +stuff( right( convert( varchar(26), getdate(), 109 ), 15 ), 7, 7, ' ' ) +' – N314740 > ' + 
tem.mm + ' ' + CAST(m.message AS varchar(MAX))
FROM @QNXT..memo m (NOLOCK)
JOIN @QNXT..claimmemo cm (NOLOCK)
ON m.memoid = cm.memoid
JOIN BDU_TEMP.edi.[@EXCEL_ExistingMemos] tem
ON cm.claimid = tem.claimid
AND m.memoid = tem.memoid
--WHERE MemoCreatedOrder = 1


-------------------------
PRINT 'Insert claim memo'
-------------------------
INSERT INTO BDU_TEMP.edi.insertmemo
(environment,
srcid,
memoidQual,
memotype,
message,
source,
description)
SELECT DISTINCT '@QNXT',
tem.claimid,
'C',
'WO' + substring('@WO', 10, 6),
'< ' + convert( varchar(10), getdate(), 101) +stuff( right( convert( varchar(26), getdate(), 109 ), 15 ), 7, 7, ' ' ) +' – N314740 > ' + 
tem.mm,
'claim',
'C35'
FROM BDU_TEMP.edi.[@EXCEL] tem
LEFT JOIN BDU_TEMP.edi.[@EXCEL_ExistingMemos] em
ON tem.claimid = em.claimid
WHERE tem.claimid IS NOT NULL
AND em.claimid IS NULL

----------------------------
PRINT 'Claim status to PEND'
----------------------------
SELECT clm.* INTO BDU_Temp.edi.[@EXCEL_CLM]
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.edi.[@EXCEL] tem 
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status = 'PEND'
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.edi.[@EXCEL] tem 
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 

SELECT clm.status, COUNT(*), COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.edi.[@EXCEL] tem 
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status
-----------------------------------
PRINT 'Memo insertion verification'
-----------------------------------
USE BDU_TEMP
EXEC usp_insertmemo '@QNXT'

USE BDU_TEMP
SET nocount ON
SELECT COUNT (DISTINCT im.srcid), memoflag, createid
FROM edi.insertmemo im (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid=im.srcid
WHERE createdate > GETDATE() - 0.2
AND environment = '@QNXT'
AND memotype = 'WO' + substring('@WO', 10, 6)
GROUP BY memoflag, createid
";

 public string claimpendhistory_claimEdit_rule913_PEND_line0 = @"
/*
   Where claimedit.ruleid = '913' exists: 
   Where claimpendhistory.overrider = '' 
   Set claimpendhistory.overridedate = getdate 
   Set claimpendhistory.overrider = PHOENIX\EDI User
   Insert claimpendhistory.pendreasonid = 'Ref Column B'
   Set claimpendhistory.penddate = GETDATE 
   Where claimedit.ruleid = '913' does not exist:
   Insert claimedit.ruleid = '913'
   Set claimedit.claimline = 0
   Set claimedit.status = 'PEND'
   Insert claimpendhistory.pendreasonid = 'Ref Column B'
   Set claimpendhistory.penddate = GETDATE 
*/
----------------------------------------------------------------------------
PRINT 'Insert PEND edit 913 with claimline 0'
----------------------------------------------------------------------------
----Initial check
SELECT ce.status, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem 
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913')
AND ce.claimline = '0'
GROUP BY ce.status

----Backup
SELECT ce.*  INTO BDU_TEMP.EDI.[@EXCEL_ce3]
FROM BDU_TEMP.EDI.[@EXCEL] tem (NOLOCK) JOIN @QNXT..claim clm (NOLOCK)
ON tem.claimid = clm.claimid
JOIN @QNXT..claimedit ce (NOLOCK)  
ON clm.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' AND ce.status != 'PEND'

----Update
UPDATE ce SET status = 'PEND', state = 'MANUAL'
FROM BDU_TEMP.EDI.[@EXCEL] tem (NOLOCK)
JOIN @QNXT..claim clm (NOLOCK) ON tem.claimid = clm.claimid
JOIN @QNXT..claimedit ce (NOLOCK) ON clm.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' AND ce.status != 'PEND'

--Verification
SELECT COUNT(*), ce.status 
FROM BDU_TEMP.EDI.[@EXCEL] tem (NOLOCK)
JOIN @QNXT..claim clm (NOLOCK) ON tem.claimid = clm.claimid
JOIN @QNXT..claimedit ce (NOLOCK) 
ON clm.claimid = ce.claimid  AND ce.ruleid IN ('913') 
AND ce.claimline = '0'
GROUP BY ce.status

--Count before insert
SELECT COUNT(1)
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' 
WHERE ce.claimid IS NULL  AND tem.claimid IS NOT NULL
 
----Insert 
INSERT INTO @QNXT..claimedit (claimid, claimline, status, ruleid, state)  
SELECT DISTINCT tem.ClaimID, '0','PEND', '913', 'MANUAL'  
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
AND ce.ruleid IN ('913') AND ce.claimline = '0' 
WHERE ce.claimid IS NULL  AND  tem.claimid IS NOT NULL

----------------------------------------------------------------------------
PRINT 'Update and insert claimpendhistory overrider'
----------------------------------------------------------------------------
----Backup
SELECT cph.*
INTO BDU_TEMP.EDI.[@EXCEL_CPH1]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem  
ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK)  ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913') AND ce.claimline = '0' AND cph.overrider = '' 

----Update
UPDATE cph
SET overridedate = GETDATE(), overrider = 'PHX\EDIUser'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK) ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913') AND ce.claimline = '0' AND cph.overrider = ''

----Count before insert
SELECT COUNT(DISTINCT tem.claimid)
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.EDI.[@EXCEL] tem  
ON tem.claimid = ce.claimid
LEFT JOIN @QNXT..claimpendhistory cph (NOLOCK) ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913') AND ce.claimline = '0'

----Insert
INSERT INTO @QNXT..claimpendhistory (claimid, pendreasonid, penddate)
SELECT DISTINCT tem.claimid, tem.dd, GETDATE()
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem 
ON tem.claimid = ce.claimid
LEFT JOIN @QNXT..claimpendhistory cph (NOLOCK)
ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')  AND ce.claimline = '0'  
AND tem.claimid IS NOT NULL  AND cph.claimid is NULL
";
    }
}
