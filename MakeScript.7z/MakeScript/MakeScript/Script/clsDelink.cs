﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public class clsDelink
    {
  public string sDelink = @"
USE @QNXT
 
SELECT CLAIMID, ORGCLAIMID, RESUBCLAIMID,status 
FROM @QNXT..claim  WHERE  claimid  LIKE  '##%' 
--------------------------------------------------
PRINT  'Backup claim  before update'
--------------------------------------------------
SELECT c.* into [BDU_TEMP].[EDI].[@EXCEL_bk1]
FROM @QNXT..claim c  where  claimid  LIKE  '##%' 

--------------------------------------------
PRINT  'delink' 
----------------------------------------
update @QNXT..claim  set resubclaimid = '',ORGCLAIMID='' WHERE  claimid  LIKE   '##%' 

-----------------------------
PRINT 'Validation Script'
----------------------------
SELECT c.claimid, c.orgclaimid,c.resubclaimid, c.status
FROM @QNXT..claim C WHERE claimid  LIKE '##%' ";
         
 }
  
}
