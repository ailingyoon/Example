﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{ 
  
 public class clsSpecial1
    {
public string  CARC_RARC_915_DENY = @"
------------------------------------------------------
PRINT 'Insert Edit 915 to manually deny '
--Place CARC code in claimedit table = column B
--Place RARC code in claimeditmessage table = column C
------------------------------------------------------

select ce.status, Count(*),ce.reason
from @QNXT..claimedit ce (nolock)
join BDU_TEMP.EDI.[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline		
where ruleid in ( '915') 
group by ce.status, ce.reason                                                     

select ce.* into BDU_TEMP.EDI.[@EXCEL_ce]
from @QNXT..claimedit ce (nolock)
join BDU_TEMP.EDI.[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline		
where ruleid in ( '915') 

update ce set status = 'DENY',clearby = 'PHX\EDIUser',cleardate = getdate(), state = 'MANUAL', reason = tem.CARC
from @QNXT..claimedit ce (nolock)
join BDU_TEMP.EDI.[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline		
where ruleid in ( '915') 

select ce.status, Count(*),ce.reason
from @QNXT..claimedit ce (nolock)
join BDU_TEMP.EDI.[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline		
join @QNXT..claim clm (nolock) on clm.claimid = tem.claimid
where ruleid in ( '915') and clm.status not in ('PAID','DENIED','VOID', 'REVERSED')  
group by ce.status, ce.reason                        

insert into @QNXT..claimedit (claimid, claimline, ruleid, status, reason,state)
select distinct tem.claimid, '0','915','DENY',tem.carc, 'MANUAL' 
from @QNXT..claimedit ce (nolock)
right join BDU_TEMP.EDI.[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline 
and  ruleid in ( '915') and ce.status = 'DENY' and ce.reason = tem.carc
where  ce.claimid is null and ce.claimline is  null  
and tem.claimid is not null and tem.carc is not null

INSERT INTO [@QNXT].[dbo].[claimeditmessage]
           ([claimid]
           ,[claimline]
           ,[ruleid]
           ,[messageid]
           ,[messagetype]
           ,[overridemessage])
select distinct tem.claimid, 0, '915', rr.reasonid,rr.reasontype,rr.reporttext 
from  BDU_TEMP.EDI.[@EXCEL] tem(nolock)
join @QNXT..rulereason rr(nolock) on rr.reasonid= tem.RARC and rr.reasontype='remit' 
and tem.claimid not in (select a.claimid from [@QNXT].[dbo].[claimeditmessage] a inner join 
BDU_TEMP.EDI.[@EXCEL] b on 
a.claimid=b.claimid 
where a.ruleid='915' and a.claimline=0 and a.messageid=b.RARC)
";

 public string memo01 = @"
------------------------------------------------------
PRINT 'Update existing memos'
------------------------------------------------------
SELECT m.*, tem.*, ROW_NUMBER() over (PARTITION BY cm.claimid ORDER BY m.createdate ASC) AS CreatedOrder
INTO  BDU_TEMP.EDI.[@EXCEL_ExistingMemos]
FROM @QNXT..memo m (NOLOCK) JOIN @QNXT..claimmemo cm (NOLOCK)  ON m.memoid = cm.memoid 
JOIN BDU_TEMP.EDI.[@EXCEL] tem  ON cm.claimid = tem.claimid
WHERE (
m.description LIKE 'P0%' 
OR m.description LIKE 'P1%' OR m.description LIKE 'H0%'
OR m.description LIKE 'H1%' OR m.description LIKE 'H2%'
OR m.description LIKE 'H3%' OR m.description LIKE 'H4%'
OR m.description LIKE 'H7%' OR m.description LIKE 'H9%'
OR m.description LIKE 'C0%' OR m.description LIKE 'C1%'
OR m.description LIKE 'C2%' OR m.description LIKE 'C3%'
OR m.description LIKE 'C4%' OR m.description LIKE 'C5%'
OR m.description LIKE 'C6%' OR m.description LIKE 'C7%'
OR m.description LIKE 'C8%' OR m.description LIKE 'C9%'
)  AND tem.claimid IS NOT NULL  
 AND m.termdate =CONVERT(smalldatetime,'2078-12-31 00:00:00')

 
--SELECT cm.claimid , m.*
SELECT COUNT(cm.claimid)
FROM @QNXT..memo m (NOLOCK)
JOIN @QNXT..claimmemo cm (NOLOCK)
ON m.memoid =cm.memoid
JOIN BDU_TEMP.EDI.[@EXCEL_ExistingMemos] tem
ON cm.claimid = tem.claimid
AND m.memoid = tem.memoid
WHERE CreatedOrder = 1

SELECT m.*
INTO BDU_TEMP.EDI.[@EXCEL_memo20]
FROM @QNXT..memo m (NOLOCK)
JOIN @QNXT..claimmemo cm (NOLOCK)
ON m.memoid =cm.memoid
JOIN  BDU_TEMP.EDI.[@EXCEL_ExistingMemos] tem
ON cm.claimid = tem.claimid
AND m.memoid =tem.memoid
WHERE CreatedOrder = 1

UPDATE m
SET m.description = tem.excel_desc + ' ' + CAST(m.description AS varchar(MAX)), m.message = '< ' + convert( varchar(10), getdate(), 101) +
stuff( right( convert( varchar(26), getdate(), 109 ), 15 ), 7, 7, ' ' ) + ' – N314740 > ' + tem.excel_message +' ' + CAST(m.message AS varchar(MAX))
FROM @QNXT..memo m (NOLOCK)
JOIN @QNXT..claimmemo cm (NOLOCK)
ON m.memoid =cm.memoid
JOIN BDU_TEMP.EDI.[@EXCEL_ExistingMemos] tem
ON cm.claimid = tem.claimid
AND m.memoid = tem.memoid
WHERE CreatedOrder = 1
"; 

    }
}
