﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{ 
  
 public class clsSpecial1
    {

 public string DENY_RARC_code = @"
------------------------------------------------------
PRINT  'DENY claim lines with RARC code @code'
------------------------------------------------------ 

select ce.status, Count(*),ce.reason
from @QNXT..claimedit ce (nolock)
join BDU_Temp.EDI.[@EXCEL] tem on tem.claimid = ce.claimid   		
where ce.ruleid in ( '915') 
group by ce.status, ce.reason

select ce.* into BDU_Temp.EDI.[@EXCEL_ce]
from @QNXT..claimedit ce (nolock)
join BDU_Temp.EDI.[@EXCEL] tem on tem.claimid = ce.claimid 		
where ce.ruleid in ( '915') 

update ce set status = 'DENY',clearby = 'PHX\EDIUser',cleardate = getdate(), state = 'MANUAL', reason = '@code'
from @QNXT..claimedit ce (nolock)
join BDU_Temp.EDI.[@EXCEL] tem on tem.claimid = ce.claimid  and tem.claimline=ce.claimline
where ce.ruleid in ( '915') 


select ce.status, Count(*),ce.reason
from @QNXT..claimedit ce (nolock)
join BDU_Temp.EDI.[@EXCEL] tem on tem.claimid = ce.claimid 		
group by ce.status, ce.reason

insert into @QNXT..claimedit (claimid, claimline, ruleid, status, reason,state)
select distinct tem.claimid, tem.claimline ,'915','DENY','@code', 'MANUAL' 
from @QNXT..claimedit ce (nolock)
right join BDU_Temp.EDI.[@EXCEL] tem on tem.claimid = ce.claimid  and tem.claimline=ce.claimline
and  ruleid in ( '915') and ce.status = 'DENY' and ce.reason = '@code'
join @QNXT..claim clm (nolock) on clm.claimid = tem.claimid
where  ce.claimid is null and ce.claimline is  null  
and clm.status not in ('PAID','DENIED','VOID', 'REVERSED')  
and tem.claimid is not null
";

public string  CARC_RARC_915_DENY = @"
------------------------------------------------------
PRINT 'Insert Edit 915 to manually deny '
--Place CARC code in claimedit table = column B
--Place RARC code in claimeditmessage table = column C
------------------------------------------------------

select ce.status, Count(*),ce.reason
from @QNXT..claimedit ce (nolock)
join BDU_TEMP.EDI.[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline		
where ruleid in ( '915') 
group by ce.status, ce.reason                                                     

select ce.* into BDU_TEMP.EDI.[@EXCEL_ce]
from @QNXT..claimedit ce (nolock)
join BDU_TEMP.EDI.[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline		
where ruleid in ( '915') 

update ce set status = 'DENY',clearby = 'PHX\EDIUser',cleardate = getdate(), state = 'MANUAL', reason = tem.CARC
from @QNXT..claimedit ce (nolock)
join BDU_TEMP.EDI.[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline		
where ruleid in ( '915') 

select ce.status, Count(*),ce.reason
from @QNXT..claimedit ce (nolock)
join BDU_TEMP.EDI.[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline		
join @QNXT..claim clm (nolock) on clm.claimid = tem.claimid
where ruleid in ( '915') and clm.status not in ('PAID','DENIED','VOID', 'REVERSED')  
group by ce.status, ce.reason                        

insert into @QNXT..claimedit (claimid, claimline, ruleid, status, reason,state)
select distinct tem.claimid, '0','915','DENY',tem.carc, 'MANUAL' 
from @QNXT..claimedit ce (nolock)
right join BDU_TEMP.EDI.[@EXCEL] tem on tem.claimid = ce.claimid and  '0' = ce.claimline 
and  ruleid in ( '915') and ce.status = 'DENY' and ce.reason = tem.carc
where  ce.claimid is null and ce.claimline is  null  
and tem.claimid is not null and tem.carc is not null

INSERT INTO [@QNXT].[dbo].[claimeditmessage]
           ([claimid]
           ,[claimline]
           ,[ruleid]
           ,[messageid]
           ,[messagetype]
           ,[overridemessage])
select distinct tem.claimid, 0, '915', rr.reasonid,rr.reasontype,rr.reporttext 
from  BDU_TEMP.EDI.[@EXCEL] tem(nolock)
join @QNXT..rulereason rr(nolock) on rr.reasonid= tem.RARC and rr.reasontype='remit' 
and tem.claimid not in (select a.claimid from [@QNXT].[dbo].[claimeditmessage] a inner join 
BDU_TEMP.EDI.[@EXCEL] b on 
a.claimid=b.claimid 
where a.ruleid='915' and a.claimline=0 and a.messageid=b.RARC)
";

  public string DENY_Servcode= @"
---------------------------------------------------------------------
PRINT 'Where servcode @code exits, DENY All Claim DETAIL LINES with below reasons'
---------------------------------------------------------------------
select tem.*
from [BDU_TEMP].[EDI].[@EXCEL] tem 
join @QNXT..claimdetail a 
on  tem.claimid=a.claimid 
where a.servcode not in ('@code')  
 
delete tem 
from [BDU_TEMP].[EDI].[@EXCEL] tem 
join @QNXT..claimdetail a 
on  tem.claimid=a.claimid 
where a.servcode not in ('@code') 
";

 public string Deny915_Remit = @"
---------------------------------------------------------------------
----Insert rule ID = 915, status = DENY, STATE = Manual, and Reason = 226  OR N705 or N202
PRINT 'Remit @code'
---------------------------------------------------------------------
DECLARE @overridemessage VARCHAR(2000)
DECLARE @messageid VARCHAR(10)='@code'
DECLARE @messagetype VARCHAR(6)='remit'

SELECT @overridemessage = rtrim(reporttext)
FROM  @QNXT..rulereason
WHERE reasonid = @messageid  AND reasontype = @messagetype
 
PRINT @messageid
PRINT @overridemessage

INSERT INTO [@QNXT].[dbo].[claimeditmessage]
     ([claimid],[claimline],[ruleid],[messageid] ,[messagetype],[overridemessage])
SELECT DISTINCT [claimid], '0', '915', @messageid, @messagetype, @overridemessage 
FROM BDU_TEMP.EDI.[@EXCEL] 
WHERE claimid IS NOT NULL 

";

public string Deny915_DSA = @"
---------------------------------------------------------------------
---Insert rule ID = 915, status = DENY, STATE = Manual, and Reason = DSA
PRINT 'UPDATE and insert primary reason DSA'
---------------------------------------------------------------------
SELECT ce.*
INTO BDU_TEMP.edi.[@EXCEL_DSA]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid 
and tem.claimline = ce.claimline		
JOIN @QNXT..claimdetail cd (NOLOCK) 
ON cd.claimid = tem.claimid
WHERE ruleid IN ( '915') 
 
UPDATE ce
SET status = 'DENY', clearby = 'PHX\EDIUser', cleardate = GETDATE(), state = 'MANUAL', reason = 'DSA'
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid 
and tem.claimline = ce.claimline	
JOIN @QNXT..claimdetail cd (NOLOCK) 
ON cd.claimid = tem.claimid
WHERE ruleid IN ( '915') 

SELECT ce.status, COUNT(*), ce.reason
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid 
and tem.claimline = ce.claimline	
JOIN @QNXT..claimdetail cd (NOLOCK) 
ON cd.claimid = tem.claimid
WHERE ruleid IN ( '915') 
--AND cd.servcode ='S9124' 
GROUP BY ce.status, ce.reason

INSERT INTO @QNXT..claimedit (claimid, claimline, ruleid, status, reason,state)
SELECT DISTINCT tem.claimid, tem.claimline,'915','DENY','DSA', 'MANUAL' 
FROM @QNXT..claimedit ce (NOLOCK)
RIGHT JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid 
and tem.claimline = ce.claimline
AND  ruleid IN ('915')
AND ce.status = 'DENY'
AND ce.reason = 'DSA'
WHERE  ce.claimid IS NULL
AND ce.claimline IS NULL
AND tem.claimid IS NOT NULL
";



 }
}
