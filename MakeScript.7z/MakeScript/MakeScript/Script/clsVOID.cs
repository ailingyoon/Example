﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public class clsVOID
    {
        public string SetToVOID = @"
USE @QNXT 
------------------------------------------------------------------------
PRINT 'VOID process START'
------------------------------------------------------------------------
------------------------------------------------------------------------
PRINT 'claimcond'
------------------------------------------------------------------------

SELECT claimcond.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimcond]
FROM claimcond 
WHERE claimid IN 
	(SELECT claimid	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimcond 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimproc'
------------------------------------------------------------------------

SELECT claimproc.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimproc]
FROM claimproc 
WHERE claimid IN
	( SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimproc 
WHERE claimid IN
	( SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimvalue'
------------------------------------------------------------------------

SELECT claimvalue.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimvalue]
FROM claimvalue 
WHERE claimid IN
	( SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimvalue 
WHERE claimid IN
	( SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimoccurrence'
------------------------------------------------------------------------

SELECT claimoccurrence.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimoccurrence]
FROM claimoccurrence
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimoccurrence
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimmemo'
------------------------------------------------------------------------

SELECT claimmemo.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimmemo]
FROM claimmemo
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimmemo
WHERE claimid IN
	(SELECT claimid    FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimstep'
------------------------------------------------------------------------

SELECT claimstep.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimstep]
FROM claimstep 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE  FROM claimstep 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimexplain'
------------------------------------------------------------------------
SELECT claimexplain.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimexplain]
FROM claimexplain 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimexplain 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimeobexplain'
------------------------------------------------------------------------
SELECT claimeobexplain.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimeobexplain]
FROM claimeobexplain 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimeobexplain 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimedit'
------------------------------------------------------------------------
SELECT claimedit.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimedit]
FROM claimedit 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimedit 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimeob'
------------------------------------------------------------------------
SELECT claimeob.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimeob]
FROM claimeob 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimeob 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimdetailapc'
------------------------------------------------------------------------
SELECT claimdetailapc.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimdetailapc]
FROM claimdetailapc 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimdetailapc 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'ClaimDetailPriceCode'
------------------------------------------------------------------------

SELECT ClaimDetailPriceCode.*
INTO [BDU_TEMP].[EDI].[@EXCEL_ClaimDetailPriceCode]
FROM ClaimDetailPriceCode 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE  FROM ClaimDetailPriceCode 
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimpharm'
------------------------------------------------------------------------

SELECT claimpharm.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimpharm]
FROM claimpharm
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimpharm
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'ClaimDetailExtEdit'
------------------------------------------------------------------------

SELECT ClaimDetailExtEdit.*
INTO [BDU_TEMP].[EDI].[@EXCEL_ClaimDetailExtEdit]
FROM ClaimDetailExtEdit
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)
	
DELETE FROM ClaimDetailExtEdit
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimdetail'
------------------------------------------------------------------------

SELECT claimdetail.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimdetail]
FROM claimdetail
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

DELETE FROM claimdetail
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'claimdiag'
------------------------------------------------------------------------

SELECT claimdiag.*
INTO [BDU_TEMP].[EDI].[@EXCEL_claimdiag]
FROM claimdiag
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)
	
DELETE FROM claimdiag
WHERE claimid IN
	(SELECT claimid 	FROM [BDU_TEMP].[EDI].[@EXCEL]	)

------------------------------------------------------------------------
PRINT 'Set claim parameters to 0'
------------------------------------------------------------------------

-- Backup
SELECT c.*
INTO [BDU_TEMP].[EDI].[@EXCEL_c1]
FROM claim c (NOLOCK)
JOIN [BDU_TEMP].[EDI].[@EXCEL] sp
ON sp.claimid = c.claimid

-- UPDATE
UPDATE c
SET	totaldeduct = 0,
	priorpay = 0,
	estamtdue = 0,
	eligibleamt = 0,
	eobamt = 0,
	eobeligibleamt = 0,
	totalpaid = 0,
	shareofcost = 0,
	ffspoolamt = 0,
	totalreimburseamt = 0,
	totalrefundamt = 0,
	totalsubmitdiscount = 0,
	totaladdlmemamt = 0
FROM claim c (NOLOCK)
JOIN [BDU_TEMP].[EDI].[@EXCEL] sp
ON sp.claimid = c.claimid

------------------------------------------------------------------------
PRINT 'Set status to VOID'
------------------------------------------------------------------------

-- Count
SELECT COUNT(*), COUNT(DISTINCT clm.claimid), clm.status
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status

-- Backup
SELECT clm.*
INTO BDU_Temp.edi.[@EXCEL_CLM]
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

-- Update
UPDATE clm SET clm.status = 'VOID'
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

-- Verify
SELECT COUNT(*), COUNT(DISTINCT clm.claimid), clm.status
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.edi.[@EXCEL] tem
ON clm.claimid = tem.claimid
--WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status

------------------------------------------------------------------------
PRINT 'VOID process END'
------------------------------------------------------------------------
";
         
 }
  
}
