﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
public class clsTab_claimeditmessage
{
//public string Remit16 = @"
//print 'messageid 16'
//declare @overridemessage varchar(255)
//declare @messageid varchar(2)='16'
//declare @messagetype varchar(8)='remit'
//select  @overridemessage= reporttext from  @QNXT..rulereason  
//where reasonid=  @messageid and reasontype=@messagetype

//print 'overridemessage :' + @overridemessage   

//INSERT INTO [@QNXT].[dbo].[claimeditmessage]
//           ([claimid]
//           ,[claimline]
//           ,[ruleid]
//           ,[messageid]
//           ,[messagetype]
//           ,[overridemessage])
//select distinct tem.claimid, tem.claimline, '915', rr.reasonid,rr.reasontype,rr.reporttext 
//from  BDU_TEMP.EDI.[@EXCEL] tem(nolock)
//join @QNXT..rulereason rr (nolock) 
//on rr.reasonid= @messageid and rr.reasontype='remit' 
//left outer join  [@QNXT].[dbo].[claimeditmessage] cem on cem.claimid=tem.claimid 
//and cem.ruleid='915' and cem.claimline=tem.claimline and cem.messagetype='remit'
//where cem.claimid is null
//";
public string Remit_915_PASS = @"
/*
 claimeditmessage.status = DENY
 claimeditmessage.state = MANUAL
 claimeditmessage.ruleid = 915
 claimeditmessage.reason= @remit
*/
USE @QNXT;
DECLARE @overridemessage VARCHAR(500) , @messageid VARCHAR(6)='@remit'
SELECT @overridemessage = reporttext
FROM @QNXT..rulereason
WHERE reasonid = @messageid  AND reasontype = 'remit'

PRINT @messageid
PRINT 'overridemessage :' + @overridemessage 

INSERT INTO [@QNXT].[dbo].[claimeditmessage]
   ([claimid],[claimline],[ruleid],[messageid],[messagetype],[overridemessage])

SELECT DISTINCT  claimid , claimline, '915', @messageid, 'remit', @overridemessage
FROM BDU_TEMP.EDI.[@EXCEL]
WHERE claimid IS NOT NULL
AND claimid + CONVERT(VARCHAR(10),claimline) NOT IN
(
    SELECT cem.claimid + CONVERT(VARCHAR(10),cem.claimline)
	FROM BDU_TEMP.EDI.[@EXCEL] tem
    JOIN [@QNXT].[dbo].[claimeditmessage] cem
    ON tem.claimid = cem.claimid
    WHERE cem.messageid = @messageid
)
";

 public string Remit226_N705_N202= @"
Declare @Id int=1,  @count int ;
create table #temp1 ( id int identity(1,1) primary key,	messagetype varchar(8) default ('remit'),	messageid varchar(8),	overridemessage varchar(255))

insert  into #temp1(messageid)  select '226' union select 'N705' union select 'N202'
update p  set overridemessage= r.reporttext
from  #temp1 as p   join  @QNXT..rulereason r
on p.messageid=r.reasonid and p.messagetype=r.reasontype 
select @count =count(1) from #temp1
 
While (@Id<= @count)  
Begin
	DECLARE @overridemessage VARCHAR(255)
	DECLARE @messageid VARCHAR(10) 
    Select  @overridemessage= overridemessage, @messageid=messageid  From #temp1  Where id=@Id; 

	INSERT INTO [@QNXT].[dbo].[claimeditmessage]
           ([claimid] ,[claimline],[ruleid],[messageid],[messagetype],[overridemessage])
	SELECT DISTINCT [claimid], '0', '915', @messageid,'remit', @overridemessage 
	FROM BDU_TEMP.edi.[@EXCEL] t join  @QNXT..claim clm on t.claimid=clm.claimid 
	WHERE (t.claimid + cast(@messageid as varchar)) NOT IN
	(
		SELECT cem.claimid + cast( @messageid as varchar) 	FROM BDU_TEMP.edi.[@EXCEL] tem
		JOIN [@QNXT].[dbo].[claimeditmessage] cem 	ON tem.claimid = cem.claimid
		WHERE cem.messageid = @messageid
	)

	SET @Id=@Id+1; 
End
";

    }
}
