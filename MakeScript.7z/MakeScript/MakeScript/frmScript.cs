﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.IO;
using Utilities;
using BDUScript;

namespace MakeScript
{
    public partial class frmScript : Form
    {
        clsWO obj;
        IniFile iniFile = new IniFile("CONFIG.ini");
        public frmScript()
        {
            InitializeComponent();
        }

        private void frmScript_Load(object sender, EventArgs e)
        {
            FillOptToCom();
            DG2.DefaultCellStyle.Font = new Font("Tahoma", 11);
            DG2.RowTemplate.MinimumHeight = 30;
            DG1.DefaultCellStyle.Font = new Font("Tahoma", 11);
            DG1.RowTemplate.MinimumHeight = 30;
            //DG1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            //DG1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            DG1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            
         

        }
        private void frmScript_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            Application.Exit();
        }
        private void FillOptToCom()
        {
            com.Items.Clear(); 
            com.Items.Add("MEMO");
            com.Items.Add("ClaimEdit");      
            com.Items.Add("Claim");
            com.Items.Add("ClaimDetail");      
            com.Items.Add("claimPendHistory");
            com.Items.Add("Attribute");
            com.Items.Add("ClaimEditMessage");
            com.Items.Add("Combo");

        }
 
        private  DataTable TClaim()
        {
            //模拟数据：
            DataTable dt1 = new DataTable(); 
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsTab_Claim  T = new clsTab_Claim();
            dt1.Rows.Add("1", "SET to OPEN", T.claimStatusToOPEN);
   
            dt1.Rows.Add("2", "SET to ## (replace ##)", T.AssignHeaderStatus);
            dt1.Rows.Add("3", "SET to OPEN, enrollid , isltc from excel", T.OPEN_enrollid_isltc);
    
            //dt1.Rows.Add("4", "SET to OPEN, where ruleid=111 and status=PEND", T.SetToOPEN_forPend_111);            
            dt1.Rows.Add("4", "SET to OPEN, isltc = 'N' ", T.StatusToOPEN_ISLTC);
            dt1.Rows.Add("5", "SET to OPEN, provid = '##',affiliationid = '##'", T.provid_affilationid);
            dt1.Rows.Add("6", "SET to OPEN, eobreceived  = 'Y'", T.OPEN_eobreceived);
            //dt1.Rows.Add("10", "SET to OPEN, enrollid  from excel", T.OPEN_enrollid);         
            dt1.Rows.Add("7", "SET to PEND", T.claimStatusToPEND);
            dt1.Rows.Add("8", "SET to PEND, where  status IN ('##','##')", T.claimStatusToPEND_ifStatus);
            dt1.Rows.Add("9", "SET to VOID", new clsVOID().SetToVOID);
            T = null; 

            return dt1;
           
        }
        private DataTable TAttribute()
        {
            //模拟数据：
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsClaimAttribute T = new clsClaimAttribute();
            dt1.Rows.Add("1", "Delete attribute", T.Delete_CLAIMATTRIBUTE);
            dt1.Rows.Add("2", "Add attribute", T.Add_CLAIMATTRIBUTE);
            dt1.Rows.Add("3", "Update  attribute", T.Update_Attribute); 

            return dt1;

        }
        private DataTable TClaimEditMessage()
        {
            //模拟数据：
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsTab_claimeditmessage T = new clsTab_claimeditmessage();
            dt1.Rows.Add("1", "claimeditmessage.status = DENY, reason =@remit,915", T.Remit_915_PASS);
        

            return dt1;

        }
        private DataTable Combo()
        {
            //模拟数据：
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsCombo1 T = new clsCombo1();
            dt1.Rows.Add("1", "ITWR-PEND(logn script with 913 & claimpendhistory) ",T.claimpendhistory_claimEdit_rule913_PEND_line0);
            dt1.Rows.Add("2", " ITWR_C35 with  update memo .... ", T.ITWR_C35);
            clsSpecial1 cs = new clsSpecial1();
            
            dt1.Rows.Add("3", "Where servcode @code exits, DENY All Claim DETAIL LINES with below reasons", cs.DENY_Servcode);
            dt1.Rows.Add("4", "Insert rule ID = 915, status = DENY, STATE = Manual, and Reason = 16 AND M119", T.DENY_Reason16_AND_M119);
            dt1.Rows.Add("5", "(replace @code) Insert rule ID=915, status=DENY, STATE=Manual,and Reason = 226,N705,N..  ", cs.Deny915_Remit);
            dt1.Rows.Add("6", "Insert rule ID=915, status=DENY, STATE=Manual,and Reason = DSA", cs.Deny915_DSA);
            dt1.Rows.Add("7", "CARC/RARC combination = @code/@remit", T.CARC_RARC_combination + new clsTab_Claim().claimStatusToOPEN);
            //String strDENY = new clsTab_Claim().AssignHeaderStatus;
            //strDENY = strDENY.Replace("##", "DENY");
            string M79 = cs.DENY_RARC_code.Replace("@code", "M79");

            dt1.Rows.Add("8", "DENY claim lines with RARC code M79(replace with @code)", M79);

            clsTab_claimcond T2 = new clsTab_claimcond();
            dt1.Rows.Add("9", " claimcond.condcode = value in column B", T2.UpdateClaimcond);


            T = null;
            cs = null;
            T2 = null;
        
            return dt1;

        }
        private DataTable TClaimEdit()
        {
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsTab_Claimedit T = new clsTab_Claimedit();
            dt1.Rows.Add("0", "Override edit, where ruleid in ##", T.Override_Edit);
            dt1.Rows.Add("1", "OKAY_EDIT, where ruleid ##", T.OKAY_EDIT);
            dt1.Rows.Add("2", "OKAY_EDIT, where ruleid=913", T.OKAY_EDIT_913);
            dt1.Rows.Add("3", "OKAY_EDIT, where claimline and ruleid  from excel", T.OKAY_EDIT_at_EXCEL_Ruleid_Claimline);
            //dt1.Rows.Add("4", "OKAY_EDIT, where ruleid in ## and status=PEND", T.OKAY_EDIT_forPEND_Status);
            dt1.Rows.Add("4", "Clear EDIT, where  913 (may have PEND)", T.ClearEdit_forPEND_913);
            dt1.Rows.Add("5", "Clear All Edit,on claimid & claimline", T.ClearAllEdit);
            dt1.Rows.Add("6", "DENY_EDIT, where ruleid in ## ", T.SET_deny_forPEND_RuleID);
            dt1.Rows.Add("7", "DENY claim edits for ruleid= ## and PEND status ", T.SET_deny_forPEND2_RuleID);

            dt1.Rows.Add("8", "rule ID ##, DENY,No claimline, and Reason =@code", T.updatePrimaryReason_No_claimline);
            dt1.Rows.Add("9", "rule ID ##, DENY,has claimline, and Reason =@code", T.updatePrimaryReason_Has_claimline);
            dt1.Rows.Add("10", "rule ID =915,  DENY->remit @code ,insert claimeditmessage", T.RemitCode_with915);
           
            dt1.Rows.Add("11", "INSERT deny 915,reason = M119 ", T.InsertDeny915);
 
            dt1.Rows.Add("12", "INSERT & UPDATE Set to PEND,where 913 and claimline 0", T.PEND913_claimline_0);
           
          
            dt1.Rows.Add("13", "INSERT & UPDATE deny 915 ,reason=97 , where REVCODE", T.Deny915_Reason97_RevcodeNotLike);
            dt1.Rows.Add("14", "INSERT & UPDATE deny 915 ,reason=97 , where REVCODE also servcode", T.Deny915_Reason97_servcode_revcode);
        
            dt1.Rows.Add("15", "Update and insert primary reason FOR DSA", T.Update_primary_DSA);
            dt1.Rows.Add("16", "Insert Edit 915 to manually deny ,CARC,RARC ", new clsSpecial1().CARC_RARC_915_DENY);
            dt1.Rows.Add("17", "H99_CLAIMS,ce.ruleid IN ('154','157','185','208','271','330','155')", T.H99_CLAIMS);

            return dt1;
        }
        private DataTable TMemo()
        {
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            dt1.Rows.Add("1", "Insert FixMessage No Join ", clsMemo.AddMemoWithNID_NoJoin_FixMessage + clsMemo.ExecuteMemo);
            dt1.Rows.Add("2", "Insert MEMO ,No Join,from excel ", clsMemo.AddMemoWithNID_NoJoin + clsMemo.ExecuteMemo);      
            dt1.Rows.Add("3", "update the Oldest exist memo(dd,mm),and term additional memos", clsMemo.UpdateExistMemoWithNID_excelDesc_message+ clsMemo.TermAdditionalMemo);
            dt1.Rows.Add("4", "Add to current claims memo message(only with message part)", clsMemo.UpdateExistMemo_Fixmessage);

            dt1.Rows.Add("5", "Insert MEMO with NID, Join Exist ", clsMemo.AddMemoWithNID_JoinExist + clsMemo.ExecuteMemo);
            dt1.Rows.Add("6", "Update All ExistMemo,NID, and description like", clsMemo.UpdateExistMemoHasNID_forAllExistMemo);
            dt1.Rows.Add("7", "Terminate additional memos", clsMemo.TermAdditionalMemo);
            dt1.Rows.Add("8", "Term All Memo without Existing ", clsMemo.TermAllMemo);  
            dt1.Rows.Add("9", "ExecuteMemo", clsMemo.ExecuteMemo);
            return dt1;
        }

        private DataTable Tclaimpendhistory()
        {
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsTab_claimpendhistory T = new  clsTab_claimpendhistory();

            dt1.Rows.Add("1", "Where claimpendhistory.overrider  = ''.  If edit 913 is not present or claimedit.status <> Pend, no action is necessary", T.Update_913_PEND);

            dt1.Rows.Add("2", "Where claimpendhistory.overrider = ''. update it", T.UpdateOverRider);
            dt1.Rows.Add("3", "Where claimpendhistory.overrider = ''  and ruleid in ##. update it", T.UpdateByOverRiderRuleid);

            //UpdateByOverRiderRuleid
            dt1.Rows.Add("4", "Insert a record into claimpendhistory ,pendreasonid =@code", T.Rule913_claimline0_FixReasonid);
            dt1.Rows.Add("5", "Pend claim to  @code  Pend Bucket,pendreasonid=@code", T.Pend_claim_toSomething);
          
            dt1.Rows.Add("6", "Update overrider,where 913 and 0", T.overrider_913_claimline0_OnlyUpdate);
            dt1.Rows.Add("7", "Update and insert  overrider,where 913 and 0", T.overrider_913_claimline0);            
            dt1.Rows.Add("8", "Update overrider,where 913 No ClaimLine", T.Update_913_NoStatus_Noclaimline);
            dt1.Rows.Add("9", "Update overrider,where ruleid in ##,pass ruleid", T.Update_PassRuleid);
            dt1.Rows.Add("10", "Pend claim to H97  Pend Bucket", T.H97PendBucket);
           
            return dt1;
      
        }
        private DataTable TclaimDetail()
        {
            DataTable dt1 = new DataTable();
            dt1.Columns.Add("ID", typeof(string));
            dt1.Columns.Add("Description", typeof(string));
            dt1.Columns.Add("script", typeof(string));
            clsTab_claimdetail T = new clsTab_claimdetail();
            dt1.Rows.Add("1", "Remove all referrals from all claim lines ", T.RemoveAllClaimdetail);
            dt1.Rows.Add("2", "claimdetail.payasprimary =  Y ", T.payasprimary);
            dt1.Rows.Add("3", "Update claim detail set manualcontractpriceamt and usemanualcontractprice", T.usemanualcontractprice);
         
            return dt1;

        }


        //private void txtWOdetail_TextChanged(object sender, EventArgs e)
        //{
           
        //}

        private void com_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Bind(this.com.Text);
            string commandName = this.com.Text;
            DataTable dt1 = null;
            switch (commandName)
            {
                case "ClaimEdit":
                    dt1 = TClaimEdit();
                    break;
                case "Claim":                    
                   dt1= TClaim();
                    break;             
                case "MEMO":
                    dt1 = TMemo();
                    break;
                case "claimPendHistory":
                  dt1 = Tclaimpendhistory();
                    break;
                case "ClaimDetail":
                    dt1 = TclaimDetail();
                    break;
                case "Attribute":
                 dt1 = TAttribute();                
                    break;
                case "ClaimEditMessage":
                    dt1 = TClaimEditMessage();
                    break;
                case "Combo":
                    dt1 = Combo();
                    break;
                default:
                    Console.WriteLine(String.Format("Unknown command: {0}", commandName));
                    break;
            }

            DG1.ClearSelection();
      
            if (dt1!=null)
            {
               
                DG1.DataSource = null;
                DG1.DataSource = dt1;
                DataGridViewColumn column1 = DG1.Columns[1];
                DataGridViewColumn column2 = DG1.Columns[2];
                column2.Width = 550;
                column1.Width = 30;
            }
      
        }

        private void  Refresh_gvWrite()
        {
            this.txtEXCEL.Text = "";
            this.txtHPID.Text = "";
            this.txtBox.Text = "";
            this.cob.SelectedIndex = -1;
            this.txtBox2.Text = "";
            this.cob2.SelectedIndex = -1;
            this.txtBox3.Text = "";
            this.cob3.SelectedIndex = -1;
            this.txtBox4.Text = "";
            this.cob4.SelectedIndex = -1;

            string sql = @" SELECT w.work_order_id,case when w.TransExcel =1 then 'YES' ELSE 'NO' END AS EXCEL ,w.datalog as plans,Summary as summ, detail 
   FROM   [EDI].[stgAuditLog] w   where   w.wantsta='YES' AND  w.worksta='PICK'  order by w.work_order_id";

            const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            //<br/>  --line break
            DataSet ds2 = Utilities.SqlHelper.ExecuteDataSet(connectionString, CommandType.Text, sql, null);
            if (ds2 != null && ds2.Tables.Count > 0)
            {

                DataTable dt2 = ds2.Tables[0];

                gvWrite.DataSource = null;
                gvWrite.Rows.Clear();
                gvWrite.Columns.Clear();
                //<br/>  --line break

                if (dt2 != null)
                {
                    DataGridViewButtonColumn col = new DataGridViewButtonColumn();
                    gvWrite.DataSource = dt2;
                    col.HeaderText = "Click";
                    col.Width = 60;

                    gvWrite.Columns.Insert(0, col);

                    //gvWO.AutoResizeColumn(3);
                    gvWrite.Columns[4].Width = 500;
                    gvWrite.Columns[5].Visible = false;
                    gvWrite.Columns[1].Width = 145;
                    gvWrite.Columns[2].Width = 50;
                    gvWrite.Columns[3].Width = 70;

                }



            }
            ds2 = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();

        }
        private void btnOnHand_Click(object sender, EventArgs e)
        {
            Refresh_gvWrite();
        }

        private void gvWrite_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.ColumnIndex > 0) return;
            try
            {
                var senderGrid = (DataGridView)sender;

                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    //DataGridViewCheckBoxCell checkbox = (DataGridViewCheckBoxCell)gvWO.CurrentCell;
                    //bool isChecked = (bool)checkbox.EditedFormattedValue;
                    //int index = checkbox.RowIndex;
                    int index = e.RowIndex;
                    obj = new clsWO();

                    //if (isChecked)
                    //{
                    DataGridViewRow row = gvWrite.Rows[index];
                    //string message = row.Cells["summ"].Value.ToString();
                    obj.summary = row.Cells["summ"].Value.ToString();
                    string detail = row.Cells["detail"].Value.ToString();
                    obj.detail = detail;
                    string[] data = detail.Split('#');
                    string newDetail = "";
                    obj.WO = row.Cells["work_order_id"].Value.ToString();
                    obj.SUBMITDATE = DateTime.Now.ToString("yyyy-MM-dd");
                    obj.plans = row.Cells["plans"].Value.ToString();
                    this.txtBoxWO.Text = obj.WO.Substring(10,5) ;

                    if (detail.Trim().Length > 0)
                    {

                        newDetail = obj.WO + Environment.NewLine;

                        for (int d = 0; d < data.Length; d++)
                        {
                            if (data[d].Trim().Length > 0)
                                newDetail += data[d] + Environment.NewLine;
                        }
                       
                        this.txtComp2.Text = newDetail;
                    }
                    else
                    {
                        this.txtComp2.Text = "No data!" + obj.WO;

                    }


                    bool b = detail.Contains("VOID");
                    if (b)
                    {
                        int index2 = detail.IndexOf("VOID");
                        if (index2 >= 0)
                            MessageBox.Show("VOID begins at character position " + (index2 + 1).ToString());

                    }

                }


                //2019 - 02 - 01
            }
            catch (Exception)
            { 
                obj = null;
                throw;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DG2.Rows.Clear();
            DG2.DataSource = null;
            this.txtEXCEL.Text = "";
            this.txtHPID.Text = "";
            this.txtBox.Text = "";
            this.cob.SelectedIndex = -1;
            this.txtBox2.Text = "";
            this.cob2.SelectedIndex = -1;
            this.txtBox3.Text = "";
            this.cob3.SelectedIndex = -1;
            this.txtBox4.Text = "";
            this.cob4.SelectedIndex = -1;
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
          

            if (DG1.DataSource != null && DG1.Rows.Count > 0)
            { 

                //DataTable dt1 = new DataTable();
                //dt1.Columns.Add("ID", typeof(string));
                //dt1.Columns.Add("Description", typeof(string));
                //dt1.Columns.Add("script", typeof(string));
                DG2.ColumnCount = 3;
                DG2.Columns[0].Name = "ID";
                DG2.Columns[1].Name = "Description";
                DG2.Columns[1].Width = 500;
                DG2.Columns[2].Name = "script";

                for (int i = 0; i < DG1.Rows.Count; i++)
                {
                    if (Convert.ToBoolean(DG1.Rows[i].Cells["check1"].Value))//获取选中的
                    {
                        //dt1.Rows.Add(DG1.Rows[i].Cells["ID"].Value.ToString(),
                        //            DG1.Rows[i].Cells["Description"].Value.ToString(),
                        //            DG1.Rows[i].Cells["script"].Value.ToString());
                        string ID = DG1.Rows[i].Cells["ID"].Value.ToString();
                        string DESC = DG1.Rows[i].Cells["Description"].Value.ToString();
                        string strScript = DG1.Rows[i].Cells["script"].Value.ToString();
                        string txt1 = txtBox.Text.Trim();
                        string txt2 = txtBox2.Text.Trim();
                        string txt3 = txtBox3.Text.Trim();
                        string txt4 = txtBox4.Text.Trim();
                        if (txt1 != "")
                            strScript = strScript.Replace(cob.Text, txt1);

                        if (txt2 != "")
                            strScript = strScript.Replace(cob2.Text, txt2);

                        if (txt3 != "")
                            strScript = strScript.Replace(cob3.Text, txt3);

                        if (txt4 != "")
                            strScript = strScript.Replace(cob4.Text, txt4);

                        DG2.Rows.Add(ID, DESC, strScript);
                       

                    }
                }
                
            }
        }
        private String GetQNXT(string HPID)
        {
            string qnxt = "";
            switch (HPID)
            {
                case "OH":
                    qnxt = "plandata_QNXT_OHIO";
                    break;
                case "TX":
                    qnxt = "plandata_QNXT_TXMS";
                    break;
                default:
                    qnxt = "plandata_QNXT_" + HPID.ToUpper().Trim();
                    break;
            }

            return qnxt;

        }
        private void PushToLog(string LogData, string QNXT, string strExcel, string WO, string HPID,string FileExt)
        {
            string sData = LogData.Replace("@QNXT", QNXT).Replace("@EXCEL", strExcel).Replace("@WO", WO);
            //string strFileName = WO + "_F1_" + HPID;
            string strFileName = WO + "_" + HPID;

            if (FileExt != string.Empty)
                strFileName = strFileName + "-" + FileExt;

            string FilePath = @"C:\Users\n314740\Downloads\LogExcel\" + strFileName + ".sql";
            if (File.Exists(FilePath)) File.Delete(FilePath);
            System.Threading.Thread.Sleep(300);
            LogUtility.Log(sData, LogType.SQL, strFileName);
        }
        private void PushToLog_NoReplace(string LogData, string summ, string FileExt)
        {
            
            string strFileName = summ;
            if (FileExt != string.Empty)
                strFileName = strFileName + "-" + FileExt; 


            string FilePath = @"C:\Users\n314740\Downloads\LogExcel\OO_" + strFileName + ".txt";
            if (File.Exists(FilePath)) File.Delete(FilePath);
            LogUtility.Log(LogData, LogType.SQL, strFileName);
        }


        private void btnWrite_Click(object sender, EventArgs e)
        { 
            string strDate = DateTime.Today.ToString("MMddyyyy");
            string HPID2 = obj.plans;
            string WO = obj.WO;
            string summary = obj.summary;
            string detail = obj.detail;

            string[] arr = new string[] { };
            var HPID_list = new List<string>();
            if (this.txtHPID.Text=="")
            {
                if (HPID2.Contains(","))
                {
                    arr = HPID2.Split(',');
                    foreach (string s in arr)
                    {
                        if (s.Trim().Length > 0)
                            HPID_list.Add(s);
                    }

                }
                else
                { HPID_list.Add(HPID2); }
            } else
            {
                HPID_list.Add(txtHPID.Text.Trim().ToUpper());
            }
    
          

            foreach (string HPID in HPID_list) // Loop through List with foreach
            {
                string FileExt = string.Empty;
                StringBuilder sb = new StringBuilder();
                string QNXTDB = GetQNXT(HPID);
                string PRODUCTION = iniFile.GetString("PRODUCTION", HPID, "");
               
                //sb.AppendLine("----" + PRODUCTION);
                sb.AppendLine("/*");
                sb.AppendLine("Conn  : " + PRODUCTION);
                sb.AppendLine("WO#   : " + WO);             
                sb.AppendLine("plans : " + HPID);
                sb.AppendLine("NID   :   N314740");
                sb.AppendLine("Date  : " + DateTime.Now.ToString("MM-dd-yyyy"));
                sb.Append("Title :" + summary + Environment.NewLine);
                string[] data = detail.Split('#');

                sb.AppendLine("***Description :----------------------------------------------------------------");
                sb.AppendLine("");
                if (detail.Trim().Length > 0)
                {
                    for (int d = 0; d < data.Length; d++)
                    {
                        if (data[d].Trim().Length > 0)
                            sb.AppendLine(data[d]);
                    }
                }


                sb.AppendLine("");
                sb.AppendLine("***End Description  -----------------------------------------------------------");
                sb.AppendLine("*/");

                summary = summary.ToUpper();
                string strExcel = "N314740_" + WO + "_" + HPID + "_" + strDate;
                if   (this.txtEXCEL.Text !="")
                {
                    FileExt = txtEXCEL.Text.Trim().ToUpper();
                    strExcel = strExcel + "_" + FileExt;
                }
                

                if (this.chkExcelInit.Checked)
                    sb.Append(clsExcelCheck.cExcelCheck);
                else
                    sb.Append(clsExcelCheck.cExcelRemoveNull);
               

                for (int i = 0; i < (DG2.Rows.Count-1); i++)
                { 
                    string strScript = DG2.Rows[i].Cells[2].Value.ToString();
                    if (this.txtBox.Text != "")
                        strScript = strScript.Replace(this.cob.Text,  this.txtBox.Text.Trim());

                    sb.Append(strScript); 
                }

                string logData = sb.ToString();
                PushToLog(logData, QNXTDB, strExcel, WO, HPID,FileExt);
                PushToLog_NoReplace(logData, WO +"_"+summary.ToUpper().Replace("/",""),FileExt);
                sb = null;

             }
             
            GC.Collect();
            GC.WaitForPendingFinalizers();
            this.txtEXCEL.Text = "";
            this.txtHPID.Text = "";
            this.txtBox.Text = "";
            Refresh_gvWrite();
            MessageBox.Show("Write completed !");

        }

        private void btnOpen2_Click(object sender, EventArgs e)
        {
           
            List<Form> forms = new List<Form>(); 
            foreach (Form f in Application.OpenForms)
            {
                if (f.Name == "Form2")
                {
                    f.Close();
                    break;
                }
            }

            Form2 nextForm = new Form2();
            this.Hide();
            nextForm.ShowDialog();
            this.Close();
 
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            Application.Exit(); 
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DG1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void rdoMEMO_CheckedChanged(object sender, EventArgs e)
        {
        
            DataTable dt1 = TMemo();
            SetDataToDG1(dt1);
        }

        private void SetDataToDG1(DataTable dt1)
        {
            DG1.ClearSelection(); 
            DG1.DataSource = dt1;
            DataGridViewColumn column1 = DG1.Columns[1];
            DataGridViewColumn column2 = DG1.Columns[2];
            column2.Width =680;
            column1.Width = 30;

        }

        private void rdoClaimEdit_CheckedChanged(object sender, EventArgs e)
        {
            DataTable dt1 = TClaimEdit();
            SetDataToDG1(dt1);

           
        }

        private void rdoClaim_CheckedChanged(object sender, EventArgs e)
        {
             

            DataTable dt1 = TClaim();
            SetDataToDG1(dt1);
 
        }

        private void rdoPendHistory_CheckedChanged(object sender, EventArgs e)
        {
      

            DataTable dt1 = Tclaimpendhistory();
            SetDataToDG1(dt1);
 
        }

        private void rdoClaimDetail_CheckedChanged(object sender, EventArgs e)
        { 

            DataTable dt1 = TclaimDetail();
            SetDataToDG1(dt1);
 
        }

        private void rdoClaimEditMessage_CheckedChanged(object sender, EventArgs e)
        {
           
            DataTable dt1 = TClaimEditMessage();
            SetDataToDG1(dt1);
 
        }

        private void rdoAttribute_CheckedChanged(object sender, EventArgs e)
        { 
            DataTable dt1 = TAttribute();
            SetDataToDG1(dt1); 
        }

        private void rdoCombo_CheckedChanged(object sender, EventArgs e)
        { 
            DataTable dt1 = Combo();
            SetDataToDG1(dt1);
        }

        private void btnDeleteRule_Click(object sender, EventArgs e)
        {
            this.txtEXCEL.Text = "";
            this.txtHPID.Text = "";
            this.txtBox.Text = "";
            this.cob.SelectedIndex = -1;
            this.txtBox2.Text = "";
            this.cob2.SelectedIndex = -1;
            this.txtBox3.Text = "";
            this.cob3.SelectedIndex = -1;
            this.txtBox4.Text = "";
            this.cob4.SelectedIndex = -1;
        }

        private void GU_Enter(object sender, EventArgs e)
        {

        }
    }
}
