﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MakeScript
{
    public class clsWO
    {
        public string WO;
        public string SUBMITDATE;
        public string detail;
        public string summary;
        public string plans;
        public string EXMM;
        public string EXOO;
        //public string key1;       
        //public string key2;
        //public string key3;
        public string keyname;
        public string txtFile; 

    }

    public class clsKeyFile
    {
  
        public string MM;
        public string OO;
        public string key1;
        public string key2;
        public string key3;
        public string key4;
        public string key5;
        public string key6;
        public string warning;
        public string keyname;
        public string txtFile;
        public string WO;

    }


}
