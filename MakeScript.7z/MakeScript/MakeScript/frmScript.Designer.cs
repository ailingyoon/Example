﻿namespace MakeScript
{
    partial class frmScript
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gvWrite = new System.Windows.Forms.DataGridView();
            this.txtComp2 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.GU = new System.Windows.Forms.GroupBox();
            this.rdoCombo = new System.Windows.Forms.RadioButton();
            this.rdoClaimDetail = new System.Windows.Forms.RadioButton();
            this.rdoClaimEditMessage = new System.Windows.Forms.RadioButton();
            this.rdoAttribute = new System.Windows.Forms.RadioButton();
            this.rdoPendHistory = new System.Windows.Forms.RadioButton();
            this.rdoClaim = new System.Windows.Forms.RadioButton();
            this.rdoClaimEdit = new System.Windows.Forms.RadioButton();
            this.rdoMEMO = new System.Windows.Forms.RadioButton();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtBoxWO = new System.Windows.Forms.TextBox();
            this.btnOpen2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnWrite = new System.Windows.Forms.Button();
            this.DG2 = new System.Windows.Forms.DataGridView();
            this.btnGet = new System.Windows.Forms.Button();
            this.DG1 = new System.Windows.Forms.DataGridView();
            this.check1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.btnOnHand = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.com = new System.Windows.Forms.ComboBox();
            this.chkExcelInit = new System.Windows.Forms.CheckBox();
            this.txtEXCEL = new System.Windows.Forms.TextBox();
            this.lblExcel = new System.Windows.Forms.Label();
            this.txtHPID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBox = new System.Windows.Forms.TextBox();
            this.cob = new System.Windows.Forms.ComboBox();
            this.cob2 = new System.Windows.Forms.ComboBox();
            this.txtBox2 = new System.Windows.Forms.TextBox();
            this.cob3 = new System.Windows.Forms.ComboBox();
            this.txtBox3 = new System.Windows.Forms.TextBox();
            this.cob4 = new System.Windows.Forms.ComboBox();
            this.txtBox4 = new System.Windows.Forms.TextBox();
            this.btnDeleteRule = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvWrite)).BeginInit();
            this.panel2.SuspendLayout();
            this.GU.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DG2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DG1)).BeginInit();
            this.SuspendLayout();
            // 
            // gvWrite
            // 
            this.gvWrite.AllowUserToAddRows = false;
            this.gvWrite.AllowUserToDeleteRows = false;
            this.gvWrite.BackgroundColor = System.Drawing.Color.LightYellow;
            this.gvWrite.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gvWrite.DefaultCellStyle = dataGridViewCellStyle2;
            this.gvWrite.Location = new System.Drawing.Point(3, 0);
            this.gvWrite.Name = "gvWrite";
            this.gvWrite.RowTemplate.Height = 24;
            this.gvWrite.Size = new System.Drawing.Size(962, 134);
            this.gvWrite.TabIndex = 17;
            this.gvWrite.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvWrite_CellContentClick);
            // 
            // txtComp2
            // 
            this.txtComp2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtComp2.Font = new System.Drawing.Font("SimSun", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtComp2.Location = new System.Drawing.Point(0, 620);
            this.txtComp2.Multiline = true;
            this.txtComp2.Name = "txtComp2";
            this.txtComp2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtComp2.Size = new System.Drawing.Size(980, 216);
            this.txtComp2.TabIndex = 18;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnDeleteRule);
            this.panel2.Controls.Add(this.GU);
            this.panel2.Controls.Add(this.btnExit);
            this.panel2.Controls.Add(this.txtBoxWO);
            this.panel2.Controls.Add(this.btnOpen2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.btnWrite);
            this.panel2.Controls.Add(this.DG2);
            this.panel2.Controls.Add(this.btnGet);
            this.panel2.Controls.Add(this.DG1);
            this.panel2.Controls.Add(this.btnOnHand);
            this.panel2.Controls.Add(this.btnClose);
            this.panel2.Location = new System.Drawing.Point(3, 140);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(969, 392);
            this.panel2.TabIndex = 20;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // GU
            // 
            this.GU.Controls.Add(this.rdoCombo);
            this.GU.Controls.Add(this.rdoClaimDetail);
            this.GU.Controls.Add(this.rdoClaimEditMessage);
            this.GU.Controls.Add(this.rdoAttribute);
            this.GU.Controls.Add(this.rdoPendHistory);
            this.GU.Controls.Add(this.rdoClaim);
            this.GU.Controls.Add(this.rdoClaimEdit);
            this.GU.Controls.Add(this.rdoMEMO);
            this.GU.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GU.Location = new System.Drawing.Point(513, 166);
            this.GU.Name = "GU";
            this.GU.Size = new System.Drawing.Size(449, 84);
            this.GU.TabIndex = 31;
            this.GU.TabStop = false;
            // 
            // rdoCombo
            // 
            this.rdoCombo.AutoSize = true;
            this.rdoCombo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoCombo.Location = new System.Drawing.Point(360, 50);
            this.rdoCombo.Name = "rdoCombo";
            this.rdoCombo.Size = new System.Drawing.Size(70, 20);
            this.rdoCombo.TabIndex = 7;
            this.rdoCombo.TabStop = true;
            this.rdoCombo.Text = "Combo";
            this.rdoCombo.UseVisualStyleBackColor = true;
            this.rdoCombo.CheckedChanged += new System.EventHandler(this.rdoCombo_CheckedChanged);
            // 
            // rdoClaimDetail
            // 
            this.rdoClaimDetail.AutoSize = true;
            this.rdoClaimDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoClaimDetail.Location = new System.Drawing.Point(7, 51);
            this.rdoClaimDetail.Name = "rdoClaimDetail";
            this.rdoClaimDetail.Size = new System.Drawing.Size(107, 24);
            this.rdoClaimDetail.TabIndex = 6;
            this.rdoClaimDetail.TabStop = true;
            this.rdoClaimDetail.Text = "ClaimDetail";
            this.rdoClaimDetail.UseVisualStyleBackColor = true;
            this.rdoClaimDetail.CheckedChanged += new System.EventHandler(this.rdoClaimDetail_CheckedChanged);
            // 
            // rdoClaimEditMessage
            // 
            this.rdoClaimEditMessage.AutoSize = true;
            this.rdoClaimEditMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoClaimEditMessage.Location = new System.Drawing.Point(124, 51);
            this.rdoClaimEditMessage.Name = "rdoClaimEditMessage";
            this.rdoClaimEditMessage.Size = new System.Drawing.Size(140, 20);
            this.rdoClaimEditMessage.TabIndex = 5;
            this.rdoClaimEditMessage.TabStop = true;
            this.rdoClaimEditMessage.Text = "ClaimEditMessage";
            this.rdoClaimEditMessage.UseVisualStyleBackColor = true;
            this.rdoClaimEditMessage.CheckedChanged += new System.EventHandler(this.rdoClaimEditMessage_CheckedChanged);
            // 
            // rdoAttribute
            // 
            this.rdoAttribute.AutoSize = true;
            this.rdoAttribute.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoAttribute.Location = new System.Drawing.Point(280, 51);
            this.rdoAttribute.Name = "rdoAttribute";
            this.rdoAttribute.Size = new System.Drawing.Size(74, 20);
            this.rdoAttribute.TabIndex = 4;
            this.rdoAttribute.TabStop = true;
            this.rdoAttribute.Text = "Attribute";
            this.rdoAttribute.UseVisualStyleBackColor = true;
            this.rdoAttribute.CheckedChanged += new System.EventHandler(this.rdoAttribute_CheckedChanged);
            // 
            // rdoPendHistory
            // 
            this.rdoPendHistory.AutoSize = true;
            this.rdoPendHistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoPendHistory.Location = new System.Drawing.Point(288, 16);
            this.rdoPendHistory.Name = "rdoPendHistory";
            this.rdoPendHistory.Size = new System.Drawing.Size(142, 22);
            this.rdoPendHistory.TabIndex = 3;
            this.rdoPendHistory.TabStop = true;
            this.rdoPendHistory.Text = "claimPendHistory";
            this.rdoPendHistory.UseVisualStyleBackColor = true;
            this.rdoPendHistory.CheckedChanged += new System.EventHandler(this.rdoPendHistory_CheckedChanged);
            // 
            // rdoClaim
            // 
            this.rdoClaim.AutoSize = true;
            this.rdoClaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoClaim.Location = new System.Drawing.Point(205, 16);
            this.rdoClaim.Name = "rdoClaim";
            this.rdoClaim.Size = new System.Drawing.Size(66, 24);
            this.rdoClaim.TabIndex = 2;
            this.rdoClaim.TabStop = true;
            this.rdoClaim.Text = "Claim";
            this.rdoClaim.UseVisualStyleBackColor = true;
            this.rdoClaim.CheckedChanged += new System.EventHandler(this.rdoClaim_CheckedChanged);
            // 
            // rdoClaimEdit
            // 
            this.rdoClaimEdit.AutoSize = true;
            this.rdoClaimEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoClaimEdit.Location = new System.Drawing.Point(89, 15);
            this.rdoClaimEdit.Name = "rdoClaimEdit";
            this.rdoClaimEdit.Size = new System.Drawing.Size(94, 24);
            this.rdoClaimEdit.TabIndex = 1;
            this.rdoClaimEdit.TabStop = true;
            this.rdoClaimEdit.Text = "ClaimEdit";
            this.rdoClaimEdit.UseVisualStyleBackColor = true;
            this.rdoClaimEdit.CheckedChanged += new System.EventHandler(this.rdoClaimEdit_CheckedChanged);
            // 
            // rdoMEMO
            // 
            this.rdoMEMO.AutoSize = true;
            this.rdoMEMO.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdoMEMO.Location = new System.Drawing.Point(7, 15);
            this.rdoMEMO.Name = "rdoMEMO";
            this.rdoMEMO.Size = new System.Drawing.Size(76, 24);
            this.rdoMEMO.TabIndex = 0;
            this.rdoMEMO.TabStop = true;
            this.rdoMEMO.Text = "MEMO";
            this.rdoMEMO.UseVisualStyleBackColor = true;
            this.rdoMEMO.CheckedChanged += new System.EventHandler(this.rdoMEMO_CheckedChanged);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(3, 209);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(84, 36);
            this.btnExit.TabIndex = 30;
            this.btnExit.Text = "exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtBoxWO
            // 
            this.txtBoxWO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtBoxWO.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxWO.ForeColor = System.Drawing.Color.Red;
            this.txtBoxWO.Location = new System.Drawing.Point(114, 212);
            this.txtBoxWO.Name = "txtBoxWO";
            this.txtBoxWO.Size = new System.Drawing.Size(132, 29);
            this.txtBoxWO.TabIndex = 27;
            // 
            // btnOpen2
            // 
            this.btnOpen2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnOpen2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpen2.Location = new System.Drawing.Point(117, 167);
            this.btnOpen2.Name = "btnOpen2";
            this.btnOpen2.Size = new System.Drawing.Size(140, 34);
            this.btnOpen2.TabIndex = 28;
            this.btnOpen2.Text = "Form 2";
            this.btnOpen2.UseVisualStyleBackColor = false;
            this.btnOpen2.Click += new System.EventHandler(this.btnOpen2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(263, 167);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 34);
            this.button1.TabIndex = 23;
            this.button1.Text = "清空";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWrite.Location = new System.Drawing.Point(388, 206);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(119, 35);
            this.btnWrite.TabIndex = 26;
            this.btnWrite.Text = "寫";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // DG2
            // 
            this.DG2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DG2.Location = new System.Drawing.Point(0, 257);
            this.DG2.Name = "DG2";
            this.DG2.Size = new System.Drawing.Size(962, 124);
            this.DG2.TabIndex = 1;
            // 
            // btnGet
            // 
            this.btnGet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGet.Location = new System.Drawing.Point(388, 167);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(119, 34);
            this.btnGet.TabIndex = 25;
            this.btnGet.Text = "取值";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // DG1
            // 
            this.DG1.AllowUserToAddRows = false;
            this.DG1.AllowUserToDeleteRows = false;
            this.DG1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DG1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.check1});
            this.DG1.Dock = System.Windows.Forms.DockStyle.Top;
            this.DG1.Location = new System.Drawing.Point(0, 0);
            this.DG1.Name = "DG1";
            this.DG1.Size = new System.Drawing.Size(969, 161);
            this.DG1.TabIndex = 0;
            this.DG1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DG1_CellContentClick);
            // 
            // check1
            // 
            this.check1.HeaderText = "Sel";
            this.check1.Name = "check1";
            this.check1.Width = 35;
            // 
            // btnOnHand
            // 
            this.btnOnHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOnHand.Location = new System.Drawing.Point(3, 167);
            this.btnOnHand.Name = "btnOnHand";
            this.btnOnHand.Size = new System.Drawing.Size(108, 34);
            this.btnOnHand.TabIndex = 24;
            this.btnOnHand.Text = "Hand";
            this.btnOnHand.UseVisualStyleBackColor = true;
            this.btnOnHand.Click += new System.EventHandler(this.btnOnHand_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(0, 0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 29;
            // 
            // com
            // 
            this.com.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.com.FormattingEnabled = true;
            this.com.Location = new System.Drawing.Point(871, 580);
            this.com.Name = "com";
            this.com.Size = new System.Drawing.Size(94, 28);
            this.com.TabIndex = 22;
            this.com.SelectedIndexChanged += new System.EventHandler(this.com_SelectedIndexChanged);
            // 
            // chkExcelInit
            // 
            this.chkExcelInit.AutoSize = true;
            this.chkExcelInit.Checked = true;
            this.chkExcelInit.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkExcelInit.Location = new System.Drawing.Point(639, 585);
            this.chkExcelInit.Name = "chkExcelInit";
            this.chkExcelInit.Size = new System.Drawing.Size(57, 17);
            this.chkExcelInit.TabIndex = 2;
            this.chkExcelInit.Text = "Check";
            this.chkExcelInit.UseVisualStyleBackColor = true;
            // 
            // txtEXCEL
            // 
            this.txtEXCEL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEXCEL.Location = new System.Drawing.Point(70, 543);
            this.txtEXCEL.Name = "txtEXCEL";
            this.txtEXCEL.Size = new System.Drawing.Size(131, 24);
            this.txtEXCEL.TabIndex = 21;
            // 
            // lblExcel
            // 
            this.lblExcel.AutoSize = true;
            this.lblExcel.Location = new System.Drawing.Point(3, 550);
            this.lblExcel.Name = "lblExcel";
            this.lblExcel.Size = new System.Drawing.Size(52, 13);
            this.lblExcel.TabIndex = 22;
            this.lblExcel.Text = "@EXCEL";
            // 
            // txtHPID
            // 
            this.txtHPID.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHPID.Location = new System.Drawing.Point(51, 575);
            this.txtHPID.Name = "txtHPID";
            this.txtHPID.Size = new System.Drawing.Size(63, 24);
            this.txtHPID.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 582);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 24;
            this.label1.Text = "HPID";
            // 
            // txtBox
            // 
            this.txtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBox.Location = new System.Drawing.Point(319, 543);
            this.txtBox.Name = "txtBox";
            this.txtBox.Size = new System.Drawing.Size(304, 26);
            this.txtBox.TabIndex = 25;
            // 
            // cob
            // 
            this.cob.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cob.FormattingEnabled = true;
            this.cob.Items.AddRange(new object[] {
            "##",
            "@code",
            "#ME",
            "#MO",
            "@remit"});
            this.cob.Location = new System.Drawing.Point(224, 543);
            this.cob.Name = "cob";
            this.cob.Size = new System.Drawing.Size(89, 26);
            this.cob.TabIndex = 26;
            // 
            // cob2
            // 
            this.cob2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cob2.FormattingEnabled = true;
            this.cob2.Items.AddRange(new object[] {
            "##",
            "@code",
            "#ME",
            "#MO",
            "@remit"});
            this.cob2.Location = new System.Drawing.Point(639, 541);
            this.cob2.Name = "cob2";
            this.cob2.Size = new System.Drawing.Size(89, 26);
            this.cob2.TabIndex = 27;
            // 
            // txtBox2
            // 
            this.txtBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBox2.Location = new System.Drawing.Point(734, 541);
            this.txtBox2.Name = "txtBox2";
            this.txtBox2.Size = new System.Drawing.Size(238, 26);
            this.txtBox2.TabIndex = 28;
            // 
            // cob3
            // 
            this.cob3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cob3.FormattingEnabled = true;
            this.cob3.Items.AddRange(new object[] {
            "##",
            "@code",
            "#ME",
            "#MO",
            "@remit"});
            this.cob3.Location = new System.Drawing.Point(160, 580);
            this.cob3.Name = "cob3";
            this.cob3.Size = new System.Drawing.Size(89, 26);
            this.cob3.TabIndex = 29;
            // 
            // txtBox3
            // 
            this.txtBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBox3.Location = new System.Drawing.Point(256, 579);
            this.txtBox3.Name = "txtBox3";
            this.txtBox3.Size = new System.Drawing.Size(117, 26);
            this.txtBox3.TabIndex = 30;
            // 
            // cob4
            // 
            this.cob4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cob4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cob4.FormattingEnabled = true;
            this.cob4.Items.AddRange(new object[] {
            "##",
            "@code",
            "#ME",
            "#MO",
            "@remit"});
            this.cob4.Location = new System.Drawing.Point(398, 579);
            this.cob4.Name = "cob4";
            this.cob4.Size = new System.Drawing.Size(89, 26);
            this.cob4.TabIndex = 31;
            // 
            // txtBox4
            // 
            this.txtBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBox4.Location = new System.Drawing.Point(493, 580);
            this.txtBox4.Name = "txtBox4";
            this.txtBox4.Size = new System.Drawing.Size(117, 26);
            this.txtBox4.TabIndex = 32;
            // 
            // btnDeleteRule
            // 
            this.btnDeleteRule.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteRule.Location = new System.Drawing.Point(286, 210);
            this.btnDeleteRule.Name = "btnDeleteRule";
            this.btnDeleteRule.Size = new System.Drawing.Size(84, 34);
            this.btnDeleteRule.TabIndex = 32;
            this.btnDeleteRule.Text = "清空條件";
            this.btnDeleteRule.UseVisualStyleBackColor = true;
            this.btnDeleteRule.Click += new System.EventHandler(this.btnDeleteRule_Click);
            // 
            // frmScript
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 836);
            this.Controls.Add(this.txtBox4);
            this.Controls.Add(this.cob4);
            this.Controls.Add(this.chkExcelInit);
            this.Controls.Add(this.com);
            this.Controls.Add(this.txtBox3);
            this.Controls.Add(this.cob3);
            this.Controls.Add(this.txtBox2);
            this.Controls.Add(this.cob2);
            this.Controls.Add(this.cob);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtHPID);
            this.Controls.Add(this.txtBox);
            this.Controls.Add(this.lblExcel);
            this.Controls.Add(this.txtEXCEL);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtComp2);
            this.Controls.Add(this.gvWrite);
            this.Name = "frmScript";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmScript_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvWrite)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.GU.ResumeLayout(false);
            this.GU.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DG2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DG1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gvWrite;
        private System.Windows.Forms.TextBox txtComp2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox chkExcelInit;
        private System.Windows.Forms.DataGridView DG2;
        private System.Windows.Forms.DataGridView DG1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox com;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn check1;
        private System.Windows.Forms.Button btnOnHand;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.TextBox txtBoxWO;
        private System.Windows.Forms.Button btnOpen2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox GU;
        private System.Windows.Forms.RadioButton rdoCombo;
        private System.Windows.Forms.RadioButton rdoClaimDetail;
        private System.Windows.Forms.RadioButton rdoClaimEditMessage;
        private System.Windows.Forms.RadioButton rdoAttribute;
        private System.Windows.Forms.RadioButton rdoPendHistory;
        private System.Windows.Forms.RadioButton rdoClaim;
        private System.Windows.Forms.RadioButton rdoClaimEdit;
        private System.Windows.Forms.RadioButton rdoMEMO;
        private System.Windows.Forms.TextBox txtEXCEL;
        private System.Windows.Forms.Label lblExcel;
        private System.Windows.Forms.TextBox txtHPID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBox;
        private System.Windows.Forms.ComboBox cob;
        private System.Windows.Forms.ComboBox cob2;
        private System.Windows.Forms.TextBox txtBox2;
        private System.Windows.Forms.ComboBox cob3;
        private System.Windows.Forms.TextBox txtBox3;
        private System.Windows.Forms.ComboBox cob4;
        private System.Windows.Forms.TextBox txtBox4;
        private System.Windows.Forms.Button btnDeleteRule;
    }
}

