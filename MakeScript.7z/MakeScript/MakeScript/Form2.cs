﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.IO;
using Utilities;
using BDUScript;

namespace MakeScript
{
    public partial class Form2 : Form
    {
        clsWO obj;
        private string ComTxtFile = "";
        IniFile iniFile = new IniFile("CONFIG.ini");
        public Form2()
        {
            InitializeComponent();
        }
        private void GetHand2()
        {
            string sql = @" SELECT w.work_order_id,case when w.TransExcel =1 then 'YES' ELSE 'NO' END AS EXCEL ,w.datalog as plans,Summary as summ, detail 
   FROM   [EDI].[stgAuditLog] w   where   w.wantsta='YES' AND  w.worksta='PICK'  order by w.work_order_id";
            const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
           
            DataSet ds2 = Utilities.SqlHelper.ExecuteDataSet(connectionString, CommandType.Text, sql, null);
            if (ds2 != null && ds2.Tables.Count > 0)
            {

                DataTable dt2 = ds2.Tables[0];
                gvWrite2.DataSource = null;
                gvWrite2.Rows.Clear();
                gvWrite2.Columns.Clear();
                //<br/>  --line break

                if (dt2 != null)
                {
                    DataGridViewButtonColumn col = new DataGridViewButtonColumn();
                    gvWrite2.DataSource = dt2;
                    col.HeaderText = "Click";
                    col.Width = 60;

                    gvWrite2.Columns.Insert(0, col);

                    //gvWO.AutoResizeColumn(3);
                    gvWrite2.Columns[4].Width = 500;
                    gvWrite2.Columns[5].Visible = false;
                    gvWrite2.Columns[1].Width = 120;
                    gvWrite2.Columns[2].Width = 50;
                    gvWrite2.Columns[3].Width = 70;
                }
            }
            ds2 = null;

        }
        private void btnHand2_Click(object sender, EventArgs e)
        {
            GetHand2();
        }

        private void gvWrite2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.ColumnIndex > 0) return;
            try
            {
                var senderGrid = (DataGridView)sender;

                if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex >= 0)
                {
                    //DataGridViewCheckBoxCell checkbox = (DataGridViewCheckBoxCell)gvWO.CurrentCell;
                    //bool isChecked = (bool)checkbox.EditedFormattedValue;
                    //int index = checkbox.RowIndex;
                    int index = e.RowIndex;
                    obj = new clsWO();

                    //if (isChecked)
                    //{
                    DataGridViewRow row = gvWrite2.Rows[index];
                    //string message = row.Cells["summ"].Value.ToString();
                    obj.summary = row.Cells["summ"].Value.ToString();
                    string detail = row.Cells["detail"].Value.ToString();
                    obj.detail = detail;
                    string[] data = detail.Split('#');
                    string newDetail = "";
                    obj.WO = row.Cells["work_order_id"].Value.ToString();
                    obj.SUBMITDATE = DateTime.Now.ToString("yyyy-MM-dd");
                    obj.plans = row.Cells["plans"].Value.ToString();
                    this.txtwo.Text = obj.WO;
                    this.txtsummary.Text = obj.summary;

                    if (detail.Trim().Length > 0)
                    {

                        newDetail = obj.WO + Environment.NewLine;

                        for (int d = 0; d < data.Length; d++)
                        {
                            if (data[d].Trim().Length > 0)
                                newDetail += data[d] + Environment.NewLine;
                        }

                        this.txtCompWO.Text = newDetail;
                    }
                    else
                    {
                        this.txtCompWO.Text = "No data!" + obj.WO;

                    }


                    bool b = detail.Contains("VOID");
                    if (b)
                    {
                        int index2 = detail.IndexOf("VOID");
                        if (index2 >= 0)
                            MessageBox.Show("VOID begins at character position " + (index2 + 1).ToString());

                    }

                }


                //2019 - 02 - 01
            }
            catch (Exception)
            {
                obj = null;
                throw;
            }
        }
        private String GetQNXT(string HPID)
        {
            string qnxt = "";
            switch (HPID)
            {
                case "OH":
                    qnxt = "plandata_QNXT_OHIO";
                    break;
                case "TX":
                    qnxt = "plandata_QNXT_TXMS";
                    break;
                default:
                    qnxt = "plandata_QNXT_" + HPID.ToUpper().Trim();
                    break;
            }

            return qnxt;

        }

        private void btnWrite2_Click(object sender, EventArgs e)
        {
            string strDate = DateTime.Today.ToString("MMddyyyy");
            const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            clsKeyFile objKey = new clsKeyFile();
            string HPID2 = obj.plans;
            string WO = obj.WO;
            string summary = obj.summary;
            //string detail = obj.detail;
            //string ME = "";
            //string MO = "";
            //string key1 = "";
            //string key2 = "";
            //string key3 = "";
            StringBuilder sb3 = new StringBuilder();
            string[] data = obj.detail.Split('#');
  
            for (int d = 0; d < data.Length; d++)
            {
                if (data[d].Trim().Length > 0)
                {
                    sb3.AppendLine(data[d]);
                } 
            }

            string detailOnFile = sb3.ToString();
            sb3 = null;


            string txtFile = com2.Text.Trim();
            string sql = @" select isnull(key1,'') as key1,isnull(key2,'') as key2 ,isnull(key3,'') as key3 , 
  isnull(key6, '') as key6, isnull(key5, '') as key5 ,isnull(key4, '') as key4 ,ISNULL(warning,'') warning,
  isnull(MM,'') AS  MM , isnull(DD,'')  AS OO 
from  [EDI].[stgAuditSum]  where  (keyname='" + txtFile + "'  OR  txtname ='" + txtFile + "')";
            summary = summary.ToUpper();
            DataSet DS = Utilities.SqlHelper.ExecuteDataSet(connectionString, CommandType.Text, sql, null);
            if (DS != null && DS.Tables.Count > 0)
            {
                //DataTable  DTT= DS.Tables[0];
                DataRow RRR = DS.Tables[0].Rows[0];
                objKey.MM = RRR["MM"].ToString();
                objKey.OO = RRR["OO"].ToString();       
                objKey.key1 =RRR["key1"].ToString();
                objKey.key2 =RRR["key2"].ToString();
                objKey.key3 = RRR["key3"].ToString();
                objKey.key4 = RRR["key4"].ToString();
                objKey.key5 = RRR["key5"].ToString();
                objKey.key6 = RRR["key6"].ToString();
                objKey.warning = RRR["warning"].ToString();
            }
            DS = null;


            string[] arr = new string[] { };
            var HPID_list = new List<string>();
            if (HPID2.Contains(","))
            {
                arr = HPID2.Split(',');
                foreach (string s in arr)
                {
                    if (s.Trim().Length > 0)
                        HPID_list.Add(s);
                }
            }
            else
            {
                HPID_list.Add(HPID2);
            }

            foreach (string HPID in HPID_list) // Loop through List with foreach
            {
                StringBuilder sb = new StringBuilder();
                string QNXTDB = GetQNXT(HPID);
                string PRODUCTION = iniFile.GetString("PRODUCTION", HPID, "");

                //sb.AppendLine("--" + PRODUCTION);
                if (objKey.key1 != "")
                    sb.AppendLine("--" + objKey.key1);
                if (objKey.key2 != "")
                    sb.AppendLine("--" + objKey.key2);
                if (objKey.key3 != "")
                    sb.AppendLine("--" + objKey.key3);
                if (objKey.key4 != "")
                    sb.AppendLine("--" + objKey.key4);
                if (objKey.key5 != "")
                    sb.AppendLine("--" + objKey.key5);
                if (objKey.key6 != "")
                    sb.AppendLine("--" + objKey.key6);

                //if (ME != "")
                //    sb.AppendLine("--#ME:" + ME);
                //if (MO != "")
                //    sb.AppendLine("--#MO:" + MO);

                sb.AppendLine("");
                sb.AppendLine("/*");
                sb.AppendLine("Conn  : " + PRODUCTION);
                sb.AppendLine("WO#   : " + WO);
                sb.AppendLine("plans : " + HPID);
                sb.AppendLine("NID   :   N314740");
                sb.AppendLine("Date  : " + DateTime.Now.ToString("MM-dd-yyyy"));
                sb.Append("Title :" + summary + Environment.NewLine);
              
                string strExcel = "N314740_" + WO + "_" + HPID + "_" + strDate;
                sb.AppendLine("***Description :----------------------------------------------------------------");
                sb.AppendLine("");
              
            
                sb.Append(detailOnFile);
                sb.AppendLine("");
                sb.AppendLine("***End Description  -----------------------------------------------------------");
                sb.AppendLine("*/");



                sb.AppendLine("");
                if (chkF2Excel.Checked==false)
                   sb.Append(clsExcelCheck.cExcelCheck);


                string AddScript = txtTemplate.Text;
                if (objKey.MM != "")
                    AddScript = AddScript.Replace("#ME", objKey.MM);

                if (objKey.OO != "")
                    AddScript = AddScript.Replace("#MO", objKey.OO);


                sb.Append(AddScript);
                sb.AppendLine("");
                if (objKey.MM != "")
                    sb.AppendLine("----Message :" + objKey.MM);
                if (objKey.OO != "")
                    sb.AppendLine("----MEMO :" + objKey.OO);

                string FileExt = txtFileExtName.Text.Trim();

                PushToLog(sb.ToString(), QNXTDB, strExcel, WO, HPID, FileExt);
                sb = null;

            }

            txtFileExtName.Text = "";
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GetHand2();
            MessageBox.Show("Write completed !");
        }
        private void PushToLog(string LogData, string QNXT, string TableName, string WO, string HPID,string FileExt)
        {
            if (FileExt != "")
                TableName = TableName + "_" + FileExt.ToUpper();

            string sData = LogData.Replace("@QNXT", QNXT).Replace("@EXCEL", TableName).Replace("@WO", WO);
            //string sqlFile = WO + "_F2_" + HPID;
            string sqlFile = WO + "_" + HPID;
            if ( ComTxtFile=="-DENY.XLSX"  || ComTxtFile== "-PEND.XLSX")
            {
                sqlFile = sqlFile + "_" + ComTxtFile.Substring(0,5);
            }

            if (FileExt != "")
                sqlFile = sqlFile + "_" + FileExt.ToUpper();


           string FilePath = @"C:\Users\n314740\Downloads\LogExcel\" + sqlFile + ".sql";

            if (File.Exists(FilePath)) File.Delete(FilePath);
            System.Threading.Thread.Sleep(300);
            LogUtility.Log(sData, LogType.SQL, sqlFile);
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string strsql = "select distinct keyname from   [PlanEDI].[EDI].[stgAuditSum]  where hasTxt = 'Y'";  
            const string connectionString = "Server=MBUPRODRPT;Database=PlanEDI;Trusted_Connection=True;";
            if (com2.Items.Count ==0)
            {
                DataSet ds2 = Utilities.SqlHelper.ExecuteDataSet(connectionString, CommandType.Text, strsql, null);
                DataTable dt = ds2.Tables[0];
                ds2 = null;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    com2.Items.Add(dt.Rows[i][0].ToString());
                }
                dt = null;
            }

            GetHand2();
        }

        private string ReadFileByALL(string s)
        {
            StreamReader sr = new StreamReader(s, false);
            string str = sr.ReadToEnd();
            sr.Close();
            return str;

        }

        //private void btnReadTxt_Click(object sender, EventArgs e)
        //{
        //    string strRoot = @"C:\Users\n314740\Downloads\TXT_BDUS\";
        //    string strPath = strRoot + this.com2.Text.Trim()+ ".txt";
        //    ComTxtFile = this.com2.Text.Trim();
        //    string str = ReadFileByALL(strPath);
        //    txtTemplate.Text = str;

        //}

        private void btnMain_Click(object sender, EventArgs e)
        {
            //List<Form> forms = new List<Form>();
            //foreach (Form f in Application.OpenForms)
            //{
            //    if (f.Name == "frmScript")
            //    {
            //        f.Close();
            //        break;
            //    }
            //}

            frmScript nextForm = new frmScript();
            this.Hide();
            nextForm.ShowDialog();
            this.Close();


        }

        private void com2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strRoot = @"C:\Users\n314740\Downloads\TXT_BDUS\";
            string strPath = strRoot + this.com2.Text.Trim() + ".txt";
            ComTxtFile = this.com2.Text.Trim();
            string str = ReadFileByALL(strPath);
            txtTemplate.Text = str;
        }

        private void btnF3_Click(object sender, EventArgs e)
        {

            Form3 nextForm = new Form3();  
            this.Hide();
            nextForm.ShowDialog();
            this.Close();
        }
    }
}
