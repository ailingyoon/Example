RSS icons

Ammount of icons:
28

Icon Sizes:
32x32, 24x24, 16x16

File Types:
.png: 
32x32(32bit)
16x16(32bit)

.ico: 
32x32(xp,8bit,16 colors)
24x24(xp,8bit,16 colors)
16x16(xp,8bit,16 colors)

.icns: 
32x32(rgb/a,8bit,16 colors,mono)
16x16(rgb/a,8bit,16 colors,mono)

.tiff:
32x32(32bit)
16x16(32bit)