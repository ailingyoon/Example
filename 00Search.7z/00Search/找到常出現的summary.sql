 drop  table  #plandetail3
create  TABLE #plandetail3 ( wo  varchar(15),summary varchar(Max),submit_date date,Assignee varchar(60), detail varchar(Max),desclen int,lensum int,SUMM2 VARCHAR(400));

WITH cteUnAssign (wo,summary,ssdate,Assignee,detail)
  AS 
  (  select  t.work_order_id as wo, ltrim(RTRIM(t.[Summary]))  AS Summary  , cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date) as ssdate,t.Request_Assignee,
  replace(replace(replace(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(replace(replace(replace(replace(cast(t.Detailed_Description as varchar(Max)), char(13) + char(10),'#'), 
char(10), '#'),char(13),' '),char(9),' '),CHAR(32),'()'),')(',''),'()',CHAR(32)))),rtrim(t.summary)+'##', ''),'Hello',''),'##','#')  as detail 
	from [ARSystem].[dbo].[WOI_WorkOrder] t WITH (NOLOCK)  
	where    [Categorization_Tier_2] = 'claims'    
	and  cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date) between   '03-01-2019' and '03-16-2019' 
	and t.Detailed_Description is not null 
  )

insert into #plandetail3 (wo,summary,submit_date,Assignee,detail)
SELECT wo,summary,ssdate, Assignee,detail  FROM  cteUnAssign AS sp  where detail not like '%VOID%'

 

UPDATE ce  SET    ce.detail =ltrim(rtrim(substring(detail, CHARINDEX('#',  detail)+1 ,len(detail)-CHARINDEX('#',  detail))))
,summary=ltrim(rtrim(summary))
FROM    #plandetail3 ce 
 where ce.detail like '%#%'

--UPDATE ce  SET    desclen=len(detail),lensum=len(summary)-11
--FROM    #plandetail3 ce
--WHERE len(summary)>20

--UPDATE ce  SET   SUMM2=SUBSTRING(summary,10,lensum)
--FROM    #plandetail3 ce
--WHERE len(summary)>20

UPDATE ce  SET   SUMM2=replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(summary,FORMAT(submit_date , 'M/d/yyyy'),''),
FORMAT (submit_date , 'MM.dd.yyyy'),'' ),FORMAT (submit_date , 'MM.dd.yy'),''),
format(submit_date , 'M/d/yy'),''),FORMAT(submit_date ,'MM dd yy'),'') , FORMAT(submit_date , 'MM-dd-yyyy') ,''),FORMAT(submit_date ,'M-d-yy'),'') 
,FORMAT(submit_date ,'MMddyy'),''),FORMAT(submit_date ,'MMddyyyy'),''),FORMAT(submit_date ,'M.d.yy'),''),FORMAT(submit_date ,'yyyyMMdd'),''),FORMAT(submit_date ,'MMdd'),'')
, FORMAT(submit_date ,'MM-dd-yy'),''), FORMAT(submit_date ,'MMdd'),''),FORMAT(submit_date ,'MM.d.yyyy'),''),FORMAT(submit_date ,'MM/dd/yyyy'),'')
FROM    #plandetail3 ce

 update #plandetail3 set summ2=upper(summ2)
 DELETE FROM #plandetail3 WHERE (summ2 like '%MOVE TO C13%' or  summ2  like '%DELINK%')

 
   
 


select  summ2 ,count(summ2) from #plandetail3
--where summ2  like '%ITWR%'
group by summ2 
order by  count(summ2) desc


 
 select  summ2 ,count(summ2) from #plandetail3
 where summ2 not in (select summary
  from [PlanEDI].[EDI].[stgAuditSummary] 
  ) group by summ2 
order by  count(summ2) desc

select summary
  from [PlanEDI].[EDI].[stgAuditSummary] where summary like '%MOVE TO C PEND%'

 
 