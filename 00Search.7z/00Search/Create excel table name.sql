 
 
DECLARE  @WO VARCHAR(25)='WO0000000177554';   --- INPUT PARAM
DECLARE @PLANID VARCHAR(8) ='OHIO'  --- INPUT PARAM 
DECLARE @LOGINID VARCHAR(10), @vUser varchar(15)=RTRIM(CURRENT_USER);
DECLARE @SQL  NVARCHAR(MAX) 
DECLARE @varToday varchar(8);
SET @varToday= Replace(CONVERT(varchar(10),  Getdate(), 101),'/','');  
SET @LOGINID=SUBSTRING(@vUser,6, LEN(@vUser)-5) ; 
 
DECLARE @tbBase varchar(80)=  @LOGINID + '_' + @WO + '_' + @PLANID + '_' + @varToday;
DECLARE @tbExcel varchar(90)='[EDI].['+ @tbBase+'_EX]';
DECLARE @tbClaim  VARCHAR(90)=@tbBase+'_CLM';
PRINT @tbExcel

