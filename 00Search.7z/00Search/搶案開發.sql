declare @year int =year(getdate())-1;
select @year ;

DECLARE @beginningofyear date = CONVERT(DATE,CONVERT(varchar(15),DATEPART(yyyy,GETDATE())) + '-01-01');
DECLARE @currentdate date = CONVERT(DATE, GETDATE() + 1);
PRINT @beginningofyear
 
 USE [ARSystem] 
 GO 

DECLARE @beginningofyear date = CONVERT(DATE,CONVERT(varchar(15),DATEPART(yyyy,GETDATE())) + '-01-01');
DECLARE @currentdate date = CONVERT(DATE, GETDATE() + 1);

 print  @beginningofyear

select  work_order_id, replace(rtrim(cast(Detailed_Description as varchar(max))) ,char(10),'#') ,
CASE WHEN t.status = 4 THEN 'In Progress'
WHEN t.status = 0 THEN 'Unstarted'
WHEN t.status = 1 THEN 'Pending' 
WHEN t.status = 5 THEN 'Completed'
WHEN t.status = 8 THEN 'Closed' END as [Request Status] 
,t.Summary,
CAST([Detailed_Description] as VARCHAR(5000)) as summaryDetail
	from [dbo].[WOI_WorkOrder] t where 1=1 
	and t.status=8
	and DATEADD(SECOND, t.[Submit_Date], '19700101') between @beginningofyear and @currentdate 
	order by t.Work_Order_ID desc 
			 
 
SELECT  distinct  [TABLE_NAME]
FROM INFORMATION_SCHEMA.COLUMNS
WHERE 1=1
AND [COLUMN_NAME] = 'work_order_id'
AND [TABLE_SCHEMA] = 'dbo'


DROP TABLE  [PlanEDI].[EDI].[stgVIIARLog] 
select  t.work_order_id ,
 replace(rtrim(cast(t.Detailed_Description as varchar(max))) ,char(10),'#') as detail  ,   len(replace(rtrim(cast(t.Detailed_Description as varchar(max))) ,char(10),'#')) as lenDesc,
 REPLACE(RTRIM(LTRIM(t.[Summary])),char(10),'#') AS [Summary],  
 DATEADD(SECOND, t.[Submit_Date], '19700101') as submitdate 
,t.SRID,  t.Request_Assignee
 into [PlanEDI].[EDI].[stgVIIARLog] 
 from [dbo].[WOI_WorkOrder] t join WOI_WorkInfo  w  
on  t.Work_Order_ID=w.Work_Order_ID  
and t.status=8  and t.Categorization_Tier_2  = 'claims'   
--and t.Work_Order_ID='WO0000000097583'
and  w.Number_of_Attachments >0 
and w.description  like '%script%'  
 and DATEADD(SECOND, t.[Submit_Date], '19700101') between '2018-11-10' and '2019-02-01'
 ORDER BY T.SUMMARY 

select   *  from [PlanEDI].[EDI].[stgVIIARLog]  q
where 1=1
AND q.summary like '%%'
and q.detail  like '%%'
order by q.lendesc,q.summary 





 and  cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date)='2019-02-01'

INSERT INTO [PlanEDI].[EDI].[stgAuditLog] ([work_order_id],[worksta],[wantsta],[assignToMe],[submitdate],[lenDesc],[Summary],[detail],[vpriority])
select  work_order_id,'init','YES',1,
        cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date),
		len(replace(rtrim(cast(t.Detailed_Description as varchar(max))) ,char(10),'#')),  
        REPLACE(RTRIM(LTRIM(t.[Summary])),char(10),'#') ,  
		 replace(rtrim(cast(t.Detailed_Description as varchar(max))) ,char(10),'#')  ,
		 t.WO_Type_Field_18
		  from [dbo].[WOI_WorkOrder] t    
		  WHERE  t.work_order_id='WO0000000178791'
		  and   (t.[Status]=0  and  t.request_assignee is null ) 
		    
select  work_order_id,'init','NO YET',0,
        cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date),len(replace(rtrim(cast(t.Detailed_Description as varchar(max))) ,char(10),'#')) as lenDesc
        REPLACE(RTRIM(LTRIM(t.[Summary])),char(10),'#') ,
		 replace(rtrim(cast(t.Detailed_Description as varchar(max))) ,char(10),'#') ,
		 t.WO_Type_Field_18 

 CREATE TABLE [PlanEDI].[EDI].[stgAuditLog] 
( work_order_id  varchar(15) NOT NULL,
   worksta varchar(15) ,
   wantsta varchar(10),  
   assignToMe int  default 0,
   submitdate date,
	 lenDesc int,
	 Summary varchar(800),
	 detail varchar(MAX),
    vpriority   varchar(15) , 
     datalog varchar(500),
  CONSTRAINT workOrder_pk1 PRIMARY KEY (work_order_id)
);


 

		 

select * from [PlanEDI].[EDI].[stgAuditLog]  
			
		 
 