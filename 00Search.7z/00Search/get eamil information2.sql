 /*
	SERVER: MBUPRODRPT
	DATABASE: ARSystem
*/ 
 ---often use 
 select * from    
 [PlanEDI].[EDI].[LOGARSystem] order by lenDesc    
 
  -----------------------------------------------------------------------------------------------------------------------------------------------------------------
	select t.work_order_id,  
	 t.[status]  as sta ,cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date) as submitdate,
	 replace(rtrim(cast(t.Detailed_Description as varchar(max))) ,char(10),'#')  as detail  ,
	    len(replace(rtrim(cast(t.Detailed_Description as varchar(max))) ,char(10),'#')) as lenDesc, 
	t.Request_Assignee,
	t.WO_Type_Field_18 as [priority], 
	 RTRIM(LTRIM(t.[Summary]))  AS [Summary]  
	from [dbo].[WOI_WorkOrder] t WITH (NOLOCK)    
where 1=1
 and [Categorization_Tier_2] = 'claims'  and  (t.Status=0  and  t.request_assignee is null )   
 and  cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date)=cast(getdate() as date) 
 
 

  	select COUNT(*) as unAssignCount
	from [dbo].[WOI_WorkOrder] t WITH (NOLOCK)    
where  1=1 
 AND  t.work_order_id='WO0000000173155' 
AND   t.request_assignee is null
  
 and  cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date)=cast(getdate() as date) 



 select t2.Work_Order_ID  from [dbo].[AET_WOI_State_Plan_Join] t2  
 where    t2.work_order_id  in ( 
	select t.work_order_id 
	from [dbo].[WOI_WorkOrder] t    
where 1=1
 and [Categorization_Tier_2] = 'claims'   
  --and  (t.Status=0  and  t.request_assignee is null )   
    AND (t.[Summary] LIKE   '%claim%' and t.[status]=8))   

 select * from    [dbo].[AET_WOI_State_Plan_Join] t2  where t2.work_order_id= 'WO0000000027216'
 
 /* sent email */
 ------------------------------------------------------------------------------------------------------------------------------------
  	select   
	'Good Afternoon ' + t.[ContactFullName]  + ',' + CHAR(13)+CHAR(10) +
 'Update is completed as per the given ITWR, Please validate and Approve if met expectation.'
 + CHAR(13)+CHAR(10) + 'Request #  : ' +  t.SRID +   '   ,  Plan :'+ t2.SP_Plan + CHAR(13)+CHAR(10) + 
  'Thanks,' +
    CHAR(13)+CHAR(10) + 'Ailing Yoon'  as Contect,
	t.work_order_id,   t.Work_Order_ID + ' : ' + REPLACE(RTRIM(LTRIM(t.[Summary])),char(10),'')  as emailSubject , 
	 rtrim(cast(t.Internet_E_mail as varchar(200))) + ';' + rtrim(cast(ISNULL(t.WO_Type_Field_01,'') as varchar(200))) as Mailreceiver ,  
	t2.SP_Plan as PlanName ,
	T.Detailed_Description
	from [dbo].[WOI_WorkOrder] t    
	JOIN  [dbo].[AET_WOI_State_Plan_Join] t2  
	ON   t.work_order_id=t2.work_order_id
where 1=1
 and [Categorization_Tier_2] = 'claims' 
 AND  t2.SP_Selected = '0'
 and   t.Status=0
 and  t.Request_Assignee='Ailing Yoon'  
 order by    DATEADD(SECOND, t.[Submit_Date], '19700101') desc   , t.Work_Order_ID,t2.SP_Plan 
 ----------------------------------------------------------------------------------------------------------

   	select    CAST( T.Detailed_Description  as VARCHAR(5000)) as summaryDetail ,t.Work_Order_ID , cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date)  as [Submit_Date]
	from [dbo].[WOI_WorkOrder] t   
where 1=1
 and [Categorization_Tier_2] = 'claims'  
 --and   t.Status=5  
 and  t.Request_Assignee='Ailing Yoon'  
 --and  cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date)='2019-01-29'
 order by DATEADD(SECOND, t.[Submit_Date], '19700101')  desc 
 AND  CAST( T.Detailed_Description  as VARCHAR(5000)) LIKE '%where claimid in (column A)%'

 ------------------EMAIL BY WO----------------------------------------------------------------
 USE  ARSystem 
 GO 
   	select   rtrim(cast(t.Internet_E_mail as varchar(200))) + ';' + rtrim(cast(ISNULL(t.WO_Type_Field_01,'') as varchar(200)))  + '---' + 
	'Good Afternoon ' + t.[ContactFullName]  + ',' + CHAR(13)+CHAR(10) +
 'Update is completed as per the given ITWR, Please validate and Approve if met expectation.'
 + CHAR(13)+CHAR(10) + 'Request #  : ' +  t.SRID +    CHAR(13)+CHAR(10) + 
  'Thanks,' +
    CHAR(13)+CHAR(10) + 'Ailing Yoon'  as Contect,
	t.work_order_id,   t.Work_Order_ID + ' : ' + REPLACE(RTRIM(LTRIM(t.[Summary])),char(10),'')  as emailSubject 
	 
	from [dbo].[WOI_WorkOrder] t  
--where 1=1 
--  and  t.Request_Assignee='Ailing Yoon'  
-- and t.summary like '%remove the zero claimline rule id%'
and   T.WORK_ORDER_ID='WO0000000178396'
 
 

--SELECT 'select top 5 *  from  ' +    TABLE_NAME ,TABLE_NAME 
--FROM    INFORMATION_SCHEMA.TABLES
--WHERE
--   TABLE_NAME
--LIKE    '%WOI%'

 