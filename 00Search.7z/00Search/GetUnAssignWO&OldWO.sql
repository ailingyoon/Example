use PlanEDI 
go 


DECLARE @plandetail TABLE
( wo  varchar(15),summary varchar(Max),detail varchar(Max),desclen int);

DECLARE @plandetail2 TABLE
( wo  varchar(15),summary varchar(Max),detail varchar(Max),desclen int);


WITH cteUnAssign (wo,summary,detail)
  AS
  (  select  t.work_order_id as wo, RTRIM(t.[Summary])  AS Summary  ,
  replace(replace(replace(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(replace(replace(replace(replace(cast(t.Detailed_Description as varchar(Max)), char(13) + char(10),'#'), 
char(10), '#'),char(13),' '),char(9),' '),CHAR(32),'()'),')(',''),'()',CHAR(32)))),rtrim(t.summary)+'##', ''),'Hello',''),'##','#')  as detail 
	from [ARSystem].[dbo].[WOI_WorkOrder] t WITH (NOLOCK)  
	where    [Categorization_Tier_2] = 'claims'   and  (t.Status=0  and  t.request_assignee is null)
	and  cast( DATEADD(SECOND, t.[Submit_Date], '19700101') as date)=cast(getdate() as date) 
  )
   
 
insert into @plandetail (wo,summary,detail)
SELECT wo,summary,detail  FROM  cteUnAssign AS sp

UPDATE ce  SET    ce.detail =ltrim(rtrim(substring(detail, CHARINDEX('#',  detail)+1 ,len(detail)-CHARINDEX('#',  detail))))
FROM    @plandetail ce 
 where ce.detail like '%#%'

UPDATE ce  SET    desclen=len(detail)
FROM    @plandetail ce

 
 
 
select 'UnAssign' as my,ce.wo, st.work_order_id as oldWO, st.summary Old,ce.summary as New, st.Request_Assignee who 
from   @plandetail ce join  [PlanEDI].[EDI].stgVIIARLog st
on SUBSTRING(ce.detail,1,ce.desclen-5)=substring(st.detail2,1,ce.desclen-5)
 
 
select 'UnAss_Short' as my,ce.wo, ce.summary  ,ce.desclen,ce.detail
from   @plandetail ce  where ce.desclen <40


select 'Assign' as my,substring(p.work_order_id,10,6) as NewWO, p.datalog,p.TransExcel,
substring(st.work_order_id,10,6) as oldWO,  p.summary as New,st.summary Old, st.Request_Assignee as  who
from  [EDI].[stgAuditLog]  p join  [PlanEDI].[EDI].stgVIIARLog st
on SUBSTRING(p.detail,1,p.lenDesc-5)=substring(st.detail2,1,p.lenDesc-5)
where p.worksta='PICK' 
 AND P.datalog in ('FL','KS','KY','LA','MCRP','NJ','OH','PA','TXP','TX','VA')    --- Wen 
ORDER BY datalog ,p.work_order_id asc ,st.work_order_id desc 

select count(work_order_id)  ,substring(p.work_order_id,10,6) as WO ,p.submitdate
from  [EDI].[stgAuditLog]  p
where p.worksta='PICK' 
and p.datalog in ('FL','KS','KY','LA','MCRP','NJ','OH','PA','TXP','TX','VA')
group by  p.submitdate, work_order_id 
order by p.submitdate ,p.work_order_id asc 

select count(work_order_id)   
from  [EDI].[stgAuditLog]  p
where p.worksta='MAILED' AND p.submitdate=cast(getdate() as date)

--update pp
--set pp.worksta='MAILED'
--from [EDI].[stgAuditLog]  pp
--where substring(pp.work_order_id,10,6) ='184171' and pp.datalog='KY'

 


 
 


 