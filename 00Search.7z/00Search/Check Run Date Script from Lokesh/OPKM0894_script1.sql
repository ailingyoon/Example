/*
Plan:	MCRP
WO:	WO0000000140403
Doer:	N629051
Date:	09192018


-------------
Title :WO0000000140403 OPKM0894 - Encounter Pre Check Run Process BDU's
--------------
Imported Table: 
drop table [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018]
select count(1), count(distinct claimid)  from [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018]
     
  
            
           delete  from [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018] where claimid is null 
            
----------- -----------
2486        1679

(1 row(s) affected)



 --validate excel

select count(1), count(distinct tem.claimid) 
from  [BDU_Temp].[edi].N629051_WO0000000140403_MCRP_09192018 tem (nolock) 
join [Plandata_QNXT_MCRP]..claim clm (nolock) on clm.claimid=tem.claimid 
where tem.claimid is not null 
and clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 
            
            
            
            
            
----------- -----------
189	155

(1 row(s) affected)



*/


use plandata_QNXT_MCRP

---=========================================================================
--------------------PHASE ONE
---=========================================================================
---=========================================================================
------------- STEP 1.0
---=========================================================================

		use plandata_qnxt_MCRP

		set nocount on

		if object_id('tempdb..#dataset') is not null begin drop table #dataset end
		select *
		into #dataset
		from [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018] 
		where claimid is not null
		
		create index idx_claimid on #dataset (claimid)
		
			
        --Command(s) completed successfully.



---=========================================================================
------------- END STEP 1.0
---=========================================================================

---=========================================================================
------------- STEP 2.0
---=========================================================================

		---2.1
		 select clm.status , count(1)
		from claim clm (nolock)
		join (select distinct #d.claimid,#d.newstat from #dataset #d (nolock)) #d on clm.claimid = #d.claimid
		and clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 
	    group by clm.status

 
		 select clm.* into [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018_clm2]  
		from claim clm (nolock)
		join (select distinct #d.claimid,#d.newstat from #dataset #d (nolock)) #d on clm.claimid = #d.claimid
		and clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 
   
		update clm set status = #d.newstat
		from claim clm (nolock)
		join (select distinct #d.claimid,#d.newstat from #dataset #d (nolock)) #d on clm.claimid = #d.claimid
		and clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 



-----------------PEND-------------------------
select count(*), ce.status 
from BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018] tem (nolock)
join plandata_qnxt_MCRP..claim clm (nolock) on tem.claimid = clm.claimid
join plandata_qnxt_MCRP..claimedit ce (nolock) 
on clm.claimid = ce.claimid and ce.ruleid = '913' and ce.claimline = '0' and [linestatus] = 'PEND'
group by ce.status

select ce.* into BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018_ce]
from BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018] tem (nolock)
join plandata_qnxt_MCRP..claim clm (nolock) on tem.claimid = clm.claimid
join plandata_qnxt_MCRP..claimedit ce (nolock) 
on clm.claimid = ce.claimid and ce.ruleid = '913' and ce.claimline = '0' and [linestatus] = 'PEND'

update ce  set status = 'PEND',state='MANUAL'
from BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018] tem (nolock)
join plandata_qnxt_MCRP..claim clm (nolock) on tem.claimid = clm.claimid
join plandata_qnxt_MCRP..claimedit ce (nolock) 
on clm.claimid = ce.claimid and ce.ruleid = '913' and ce.claimline = '0' and [linestatus] = 'PEND'


insert into plandata_qnxt_MCRP..claimedit (claimid, claimline, status, ruleid, state)  
select distinct tem.ClaimID, '0','PEND', '913', 'MANUAL'
from plandata_qnxt_MCRP..claimedit ce (nolock)
right join BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018] tem 
on tem.claimid = ce.claimid and ce.ruleid in ( '913')  and ce.claimline = '0' 
where ce.claimid is null and tem.claimid is not null
and [linestatus] = 'PEND'

 select cph.* into BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018_CPH]
from plandata_qnxt_MCRP..claimedit ce (nolock)
join BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018] tem on tem.claimid = ce.claimid
join plandata_qnxt_MCRP..claimpendhistory cph (nolock) on cph.claimid = tem.claimid
where ce.ruleid in ( '913')  and ce.claimline = '0'
and cph.overrider = '' and [linestatus] = 'PEND'

update cph set overridedate = getdate(), overrider = 'PHX\EDIUser'
from plandata_qnxt_MCRP..claimedit ce (nolock)
join BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018] tem on tem.claimid = ce.claimid
join plandata_qnxt_MCRP..claimpendhistory cph (nolock) on cph.claimid = tem.claimid
where ce.ruleid in ( '913')  and ce.claimline = '0'
and cph.overrider = '' and [linestatus] = 'PEND'


insert into  plandata_qnxt_MCRP..claimpendhistory (claimid, pendreasonid, penddate)
select distinct tem.claimid, 'H08', getdate()
from plandata_qnxt_MCRP..claimedit ce (nolock)
join BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018] tem on tem.claimid = ce.claimid
left join plandata_qnxt_MCRP..claimpendhistory cph (nolock) on cph.claimid = tem.claimid
where ce.ruleid in ( '913')  and ce.claimline = '0'
and [linestatus] = 'PEND'

insert into BDU_Temp.edi.insertmemo (environment, srcid, memoidQual, memotype, message, source, description)
select distinct 'plandata_qnxt_MCRP', tem.claimid, 'C', 'WO'+substring('WO0000000140403',10,6), 
tem.[memo],
'claim', 'H08' -- !!! checkt the memo desciption and message, comparing with ITWR
from BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018] tem
where tem.claimid is not null 
and [linestatus] = 'PEND' 


use BDU_Temp
exec usp_insertmemo 'plandata_qnxt_MCRP'

use BDU_Temp
set nocount on
select count (1), memoflag, createid
from edi.insertmemo r (nolock)
join BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018] tem on srcid = tem.claimid
where createdate > getdate()-0.01
and environment = 'plandata_qnxt_MCRP'
and memotype = 'WO'+substring('WO0000000140403',10,6)
group by memoflag, createid

 
 
-------------------------------------------------------

		use plandata_qnxt_MCRP
		--2.2
		select cd.* into [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018_Cd1] 
		from claimdetail cd (nolock)
		join (
				select claimid, claimline 
				from #dataset #d (nolock)
				where [linestatus] = 'DENY' 
				) #d on cd.claimid = #d.claimid and cd.claimline = #d.claimline

	     update cd set status = 'DENY'
		from claimdetail cd (nolock)
		join (
				select claimid, claimline 
				from #dataset #d (nolock)
				where [linestatus] = 'DENY' 
				) #d on cd.claimid = #d.claimid and cd.claimline = #d.claimline
		
		--2.3
		-- 20130717: When column D (linestatus) = 'DENY', insert 915 DENY edit for the claimline specified
        select ce.* into [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018_ce915]
		from 	#dataset #d (nolock)
		 join claimedit ce (nolock) on #d.claimid = ce.claimid and #d.claimline = ce.claimline and ce.ruleid = '915' and ce.sequence =#D.sequence
		 and #d.linestatus != 'PEND'

  
		 update ce set ce.status =  #d.linestatus, ce.state= 'MANUAL', Ce.clearby= 'MCRP_ENC', ce. cleardate= getdate(), ce.reason= #d.[remit]
		from 	#dataset #d (nolock)
		 join claimedit ce (nolock) on #d.claimid = ce.claimid and #d.claimline = ce.claimline and ce.ruleid = '915' and ce.sequence =#D.sequence
		 and #d.linestatus != 'PEND'
 
		
		insert into claimedit (claimid, claimline, ruleid, status, state, clearby, cleardate, reason, sequence )
		select distinct #d.claimid, #d.claimline, '915', #d.linestatus, 'MANUAL', 'MCRP_ENC', getdate(), #d.[remit], #d.sequence
		from #dataset #d (nolock)
		left join claimedit ce (nolock) on #d.claimid = ce.claimid and #d.claimline = ce.claimline and ce.ruleid = '915' and ce.sequence =#D.sequence
		where ce.claimid is null and ce.claimline is null  and #d.reason <>'REVERSAL'
		and #d.linestatus != 'PEND' and #d.[remit] is not null

 

--select distinct claimid, convert(varchar(10),claimline),convert(varchar(10), sequence) from [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018] t1 
 --where (select count(distinct remit) from [PlanEdi].[edi].[N629051_WO0000000140403_MCRP_09192018] t2 where t1.claimid=t2.claimid and t1.claimline=t2.claimline )>1 

		--2.4
N629051_WO0000000140403_MCRP_09192018_Cd3
				
			

---=========================================================================
------------- END STEP 2.0
---=========================================================================

---=========================================================================
------------- STEP 3.0
---=========================================================================

---=========================================================================
------------- STEP 4.0
---=========================================================================

		insert into BDU_Temp.edi.insertmemo (environment, srcid, memoidqual, memotype, message, source, description)
		select distinct
		       'plandata_qnxt_MCRP' ,#d.claimid,'C', 'BDU_ENC', #d.memo,'Claim','Encounter Pre-check Run Process'
		from #dataset #d (nolock)
		where   #d.linestatus != 'PEND'
        order by #d.claimid
        
        --1010
        
        --select count(*) from #dataset
		-- 20130717: Insert remit using the value in remit column (column F):
		--insert BDU_Temp.edi.insertremit (environment, claimid, claimline, message, upflag_eob)
		--select distinct
		--	  'plandata_qnxt_MCRP' 
		--	, #d.claimid
		--	, #d.claimline
		--	, rr.reporttext
		--	, 'X'
		--from #dataset #d (nolock)
		--join rulereason rr (NOLOCK)on #d.remit= rr.reasonid 
		--where #d.[linestatus] = 'OKAY' 
		--order by #d.claimid, #d.claimline
---------------------------------run one friday-----------------------------------
		
		insert BDU_Temp.edi.insertremit (environment, claimid, claimline, message, upflag_eob)
		select distinct
			  'plandata_qnxt_MCRP' 
			, #d.claimid
			, #d.claimline
			, rr.reporttext
			, 'X'
		from #dataset #d (nolock)
		join rulereason rr (NOLOCK)on #d.remit= rr.reasonid 
		join claim clm (nolock) on #d.claimid= clm.claimid
		where #d.[linestatus] = 'OKAY'  and clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 
		order by #d.claimid, #d.claimline 
		

		use BDU_Temp
	    exec dbo.usp_insertmemo 'plandata_qnxt_MCRP' 
	    
 

		
use BDU_Temp
set nocount on
select count (distinct im.srcID ), memoflag, createid
from edi.insertmemo im (nolock) 
join BDU_Temp.edi.[N629051_WO0000000140403_MCRP_09192018] tem 
on srcid = tem.claimid 
where createdate > getdate()-0.1
and im.environment = 'plandata_qnxt_MCRP'
group by memoflag, createid
 

select count (1), upflag, createid
from edi.insertremit ir (nolock)
where createdate > getdate()-0.2
and environment = 'plandata_qnxt_MCRP'
group by upflag, createid


---=========================================================================
------------- END STEP 4.0
---=========================================================================

---=========================================================================
---END PHASE ONE
---=========================================================================

---=========================================================================
---PHASE TWO
---=========================================================================
use plandata_qnxt_MCRP

set nocount on

if object_id('tempdb..#dataset') is not null begin drop table #dataset end
select *
into #dataset
from [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018]--openquery (lsphxrpt07, 'select * from plantemp.dbo.k_precheckrun_servcode_check (nolock)') x

create index idx_claimid on #dataset (claimid)


select cd.* into [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018_Cd44]	
		from claimdetail cd (nolock)
join claim clm (nolock) on cd.claimid = clm.claimid
join (
		select distinct claimid, claimline, [oldUnits], [newUnits]
		from #dataset #d (nolock)
		where #d.reason = 'MAXUNITS' and #d.[linestatus] = 'OKAY' 
		) #d ON cd.claimid = #d.claimid and cd.claimline = #d.claimline
		where clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 

update	cd set billedunits = #d.[oldUnits], 
		fracunits = case when cd.fracunits <> #d.[newUnits] then #d.[newUnits] else cd.fracunits end
		from claimdetail cd (nolock)
join claim clm (nolock) on cd.claimid = clm.claimid
join (
		select distinct claimid, claimline, [oldUnits], [newUnits]
		from #dataset #d (nolock)
		where #d.reason = 'MAXUNITS' and #d.[linestatus] = 'OKAY' 
		) #d ON cd.claimid = #d.claimid and cd.claimline = #d.claimline
		where clm.status not in ('PAID','DENIED','VOID', 'REVERSED') 
		
		
-----------------------------------------revert back-------------------------------------	
	
select distinct cd.claimid, cd.claimline ,cd.billedunits , tem1.billedunits
--select cd.* into [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018_Cd3_backup]
--update cd set cd.billedunits = tem1.billedunits
from plandata_QNXT_MCRP..claimdetail cd 			
join [BDU_Temp].[edi].[N629051_WO0000000140403_MCRP_09192018_Cd3] tem1 
on tem1.claimid =cd.claimid and cd.claimline= tem1.claimline 
join  	(select distinct cd.claimid, cd.claimline
from claimdetail cd (nolock)
join claim clm (nolock) on cd.claimid = clm.claimid
join (
		SELECT DISTINCT claimid, 
                claimline, 
                [oldUnits], 
                [newUnits] 
FROM            #dataset #d (nolock) 
WHERE           #d.reason = 'MAXUNITS' 
AND             #d.[linestatus] = 'OKAY' ) #d ON cd.claimid = #d.claimid 
AND 
cd.claimline = #d.claimline WHERE clm.status NOT IN ('PAID', 
                                                     'DENIED', 
                                                     'VOID', 
                                                     'REVERSED')
		
		) as tem 
		on tem.claimid =tem1.claimid 
		and tem.claimline=tem1.claimline

--Command(s) completed successfully.

---=========================================================================
---END PHASE TWO
---=========================================================================


