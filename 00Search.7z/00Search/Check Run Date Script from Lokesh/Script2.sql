USE [BDU_Temp]
GO

--/****** Object:  StoredProcedure [dbo].[usp_ADHOC_RemitAdditions_claimexplain]    Script Date: 04/06/2016 15:10:50 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--CREATE  PROCEDURE [dbo].[usp_ADHOC_RemitAdditions_claimexplain] (@env varchar(50))
--AS
BEGIN

DECLARE 
@env varchar(50)= 'plandata_qnxt_MMIC'
	 , @claimid varchar(20)
	, @claimline int
	, @message nchar(4000)
	, @qMessage nchar(4000)
	, @rType varchar(20)
	, @RemitLevel varchar(1)

	, @HldClaimid varchar(20)
	, @HldMessage nchar(4000)

DECLARE @pSql nchar(4000)

SET @HldClaimid = ''
SET @HldMessage = ''
--SET @rtype = 'TEST'
SET @rtype = 'LIVE'

DECLARE c_Remit CURSOR FOR	

	SELECT claimid, claimline, message
	FROM BDU_Temp.edi.insertremit (NOLOCK)
	WHERE upflag = 'N' AND environment = @env
	ORDER BY claimid, claimline, message

OPEN c_Remit

	FETCH NEXT FROM c_Remit INTO @claimid, @claimline, @message

	WHILE @@FETCH_STATUS = 0 
		BEGIN


			SET @pSql = ''
			SET @pSql = rtrim(@pSql) + ' USE [' + rtrim(@env) + ']'
			SET @pSql = rtrim(@pSql) + ' IF (SELECT count(*) FROM [claimexplain] (NOLOCK) WHERE [claimid] = ''' + rtrim(@claimid) + ''') = 0 BEGIN'
			SET @pSql = rtrim(@pSql) + ' INSERT INTO [claimexplain] ([claimid])'
			SET @pSql = rtrim(@pSql) + ' VALUES (''' + rtrim(@claimid) + ''')'
			SET @pSql = rtrim(@pSql) + ' END'

--			print @pSql
--			print '--------------------------------------------------------------'

			EXEC sp_executeSql @pSql


IF @claimline = 0 BEGIN set @RemitLevel = 'H' END 
IF @claimline > 1 BEGIN set @RemitLevel = 'L' END 

	IF @HldClaimid > '' AND rtrim(@HldClaimid) != rtrim(@claimid)
	BEGIN 

			IF @rType = 'LIVE'
			BEGIN 

					set @HldMessage = replace(@HldMessage, '''', '''''')

-- 					print '*********************'
-- 					print '	Claimid'
-- 					print '	******'
-- 					print @HldClaimid
-- 					print '	------------------------'
-- 					print '	message'
-- 					print '	------------------------'
-- 					print @HldMessage

--					print '==================================='
--					print '--claimid : ' + rtrim(@HldClaimid)
--					print '--length message : ' + convert(varchar, len(rtrim(@HldMessage)))
--					print '--message : ' + rtrim(@HldMessage)
--					print '--mySQL: '
--					print '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'

					SET @pSql = ''
					SET @pSql = rtrim(@pSql) + ' USE [' + rtrim(@env) + ']'
					SET @pSql = rtrim(@pSql) + ' UPDATE [claimexplain]'
					SET @pSql = rtrim(@pSql) + ' SET [explanation] = ''' + rtrim(@HldMessage) + ''''
					SET @pSql = rtrim(@pSql) + ' WHERE [claimid] = ''' + rtrim(@HldClaimid) + ''''

--					print @pSql
--					print '--------------------------------------------------------------'

					--EXEC sp_executeSql @pSql

					--SET @pSql = ''
					--SET @pSql = rtrim(@pSql) + ' USE [' + rtrim(@env) + ']'
					--SET @pSql = rtrim(@pSql) + ' UPDATE [claimexplain]'
					--SET @pSql = rtrim(@pSql) + ' SET [usercomments] = cast(''' + rtrim(@HldMessage) + ''' as nchar(2000))'
					--SET @pSql = rtrim(@pSql) + ' WHERE [claimid] = ''' + rtrim(@HldClaimid) + ''''

--					print @pSql
--					print '--------------------------------------------------------------'

					EXEC sp_executeSql @pSql

					SET @pSql = ''
					SET @pSql = rtrim(@pSql) + ' USE [' + rtrim(@env) + ']'
					SET @pSql = rtrim(@pSql) + ' UPDATE [claimexplain]'
					SET @pSql = rtrim(@pSql) + ' SET [eobexplanation] = ''' + rtrim(@HldMessage) + ''''
					SET @pSql = rtrim(@pSql) + ' WHERE [claimid] = ''' + rtrim(@HldClaimid) + ''''

--					print @pSql
--					print '****************************************'

					EXEC sp_executeSql @pSql


					UPDATE BDU_Temp.edi.insertremit
					SET upflag = 'Y', lastupdate = getdate(), updateid = SUSER_SNAME()
					WHERE claimid = @HldClaimid AND upflag = 'N' AND environment = @env

			END 
	END 

	IF rtrim(@HldClaimid) != rtrim(@claimid)
	BEGIN 

			SET @pSql = ''
			SET @pSql = rtrim(@pSql) + ' USE [' + rtrim(@env) + ']'
			--SET @pSql = rtrim(@pSql) + ' IF object_id(''BDU_Temp.dbo.MsgTemp'') IS NOT NULL BEGIN DROP TABLE BDU_Temp.dbo.MsgTemp END'
			SET @pSql = rtrim(@pSql) + ' IF object_id(''tempdb..##MsgTemp'') IS NOT NULL BEGIN DROP TABLE ##MsgTemp END'
			SET @pSql = rtrim(@pSql) + ' SELECT x.[explanation] msg'
			--SET @pSql = rtrim(@pSql) + ' INTO BDU_Temp.dbo.MsgTemp'
			SET @pSql = rtrim(@pSql) + ' INTO ##MsgTemp'
			SET @pSql = rtrim(@pSql) + ' FROM [claimexplain] x (nolock)'
			SET @pSql = rtrim(@pSql) + ' WHERE x.claimid = ''' + rtrim(@claimid) + ''''

			EXEC sp_executeSql @pSql

			--SET @qMessage = (select cast(msg as nchar(4000)) FROM BDU_Temp.dbo.MsgTemp (nolock))
			SET @qMessage = (select cast(msg as nchar(4000)) FROM ##MsgTemp (nolock))
			IF @qMessage IS NULL BEGIN SET @qMessage = '' END 

			IF @qMessage = ''
			BEGIN 
						IF @RemitLevel = 'L' BEGIN
							SET @message = 'Line ' + rtrim(convert(varchar, @claimline)) + '. - ' + rtrim(@message)
						END

						IF @RemitLevel = 'H' BEGIN
							SET @message = '' + rtrim(@message)
						END

			END

			IF @qMessage > ''
			BEGIN 
						IF @RemitLevel = 'L' BEGIN
							SET @message = rtrim(@qMessage) + '
Line ' + rtrim(convert(varchar, @claimline)) + '. - ' + rtrim(@message)
						END

						IF @RemitLevel = 'H' BEGIN
							SET @message = rtrim(@message) + '
' + rtrim(@qMessage)
						END

			END 
	END 

	IF rtrim(@HldClaimid) = rtrim(@claimid)
	BEGIN 
		IF @RemitLevel = 'L' BEGIN
			SET @message = rtrim(@HldMessage) + '
Line ' + rtrim(convert(varchar, @claimline)) + '. - ' + rtrim(@message)
		END

		IF @RemitLevel = 'H' AND @HldMessage > '' BEGIN
			SET @message = rtrim(@message) + '
' + rtrim(@HldMessage)
		END

		IF @RemitLevel = 'H' AND (@HldMessage = ''  OR @HldMessage IS NULL) BEGIN
			SET @message = rtrim(@message) + '
' + rtrim(@HldMessage)
		END

	END 

		SET @HldClaimid = @claimid
		SET @HldMessage = @message

		FETCH NEXT FROM c_Remit INTO @claimid, @claimline, @message

		END

CLOSE c_Remit
DEALLOCATE c_Remit

			IF @rType = 'LIVE'
			BEGIN 

					set @HldMessage = replace(@HldMessage, '''', '''''')
-- 
-- 					print '*********************'
-- 					print '	Claimid'
-- 					print '	******'
-- 					print @HldClaimid
-- 					print '	------------------------'
-- 					print '	message'
-- 					print '	------------------------'
-- 					print @HldMessage

					SET @pSql = ''
					SET @pSql = rtrim(@pSql) + ' USE [' + rtrim(@env) + ']'
					SET @pSql = rtrim(@pSql) + ' UPDATE [claimexplain]'
					SET @pSql = rtrim(@pSql) + ' SET [explanation] = ''' + rtrim(@HldMessage) + ''''
					SET @pSql = rtrim(@pSql) + ' WHERE [claimid] = ''' + rtrim(@HldClaimid) + ''''

--					print @pSql
--					print '--------------------------------------------------------------'

					--EXEC sp_executeSql @pSql

					--SET @pSql = ''
					--SET @pSql = rtrim(@pSql) + ' USE [' + rtrim(@env) + ']'
					--SET @pSql = rtrim(@pSql) + ' UPDATE [claimexplain]'
					--SET @pSql = rtrim(@pSql) + ' SET [usercomments] = cast(''' + rtrim(@HldMessage) + ''' as nchar(2000))'
					--SET @pSql = rtrim(@pSql) + ' WHERE [claimid] = ''' + rtrim(@HldClaimid) + ''''

--					print @pSql
--					print '--------------------------------------------------------------'

					EXEC sp_executeSql @pSql

					SET @pSql = ''
					SET @pSql = rtrim(@pSql) + ' USE [' + rtrim(@env) + ']'
					SET @pSql = rtrim(@pSql) + ' UPDATE [claimexplain]'
					SET @pSql = rtrim(@pSql) + ' SET [eobexplanation] = ''' + rtrim(@HldMessage) + ''''
					SET @pSql = rtrim(@pSql) + ' WHERE [claimid] = ''' + rtrim(@HldClaimid) + ''''

--					print @pSql
--					print '****************************************'

					EXEC sp_executeSql @pSql

					UPDATE BDU_Temp.edi.insertremit
					SET upflag = 'Y', lastupdate = getdate(), updateid = SUSER_SNAME()
					WHERE claimid = @HldClaimid AND upflag = 'N' AND environment = @env

			END 

END

GO




