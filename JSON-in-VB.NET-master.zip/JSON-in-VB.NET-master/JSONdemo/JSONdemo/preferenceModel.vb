﻿Public Class preferenceModel
    Public firstName As String
    Public middleName As String
    Public lastName As String
End Class
