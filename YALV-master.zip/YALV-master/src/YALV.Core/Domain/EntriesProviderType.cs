namespace YALV.Core.Domain
{
    public enum EntriesProviderType { Xml, Sqlite, MsSqlServer }
}