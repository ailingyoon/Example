Linq2DataTable
==============

add some linq like function to datatable(not linq to sql)
