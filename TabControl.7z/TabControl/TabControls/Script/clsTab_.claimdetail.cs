﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
   public  class clsTab_claimdetail
    {
public string payasprimary = @"
------------------------------------------------------
PRINT 'Update claim detail,SET payasprimary=Y'
------------------------------------------------------
SELECT cd.*
INTO BDU_TEMP.EDI.[@EXCEL_cd1]
FROM @QNXT..claimdetail cd (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON cd.claimid = tem.claimid
 AND cd.claimline = tem.claimline
JOIN @QNXT..claim clm
ON tem.claimid= clm.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE cd SET payasprimary = 'Y'
FROM @QNXT..claimdetail cd (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON cd.claimid = tem.claimid
 AND cd.claimline = tem.claimline
JOIN @QNXT..claim clm
ON tem.claimid= clm.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

SELECT cd.payasprimary
FROM @QNXT..claimdetail cd (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON cd.claimid = tem.claimid
 AND cd.claimline = tem.claimline
JOIN @QNXT..claim clm
ON tem.claimid= clm.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY cd.payasprimary
";

public string usemanualcontractprice= @"
------------------------------------------------------
PRINT 'Update claim detail set manualcontractpriceamt and usemanualcontractprice'
------------------------------------------------------
SELECT cd.* INTO BDU_TEMP.EDI.[@EXCEL_cd1]
FROM @QNXT..claimdetail cd (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON cd.claimid = tem.claimid  AND cd.claimline = tem.claimline
JOIN @QNXT..claim clm  ON tem.claimid=clm.claimid 
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 

UPDATE cd SET cd.usemanualcontractprice = 'Y', cd.manualcontractpriceamt =0
FROM @QNXT..claimdetail cd (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem ON cd.claimid = tem.claimid  AND cd.claimline = tem.claimline
JOIN @QNXT..claim clm  ON tem.claimid=clm.claimid 
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
 
SELECT cd.usemanualcontractprice, COUNT(cd.usemanualcontractprice)
FROM @QNXT..claimdetail cd (NOLOCK)  JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON cd.claimid = tem.claimid  AND cd.claimline = tem.claimline
JOIN @QNXT..claim clm
ON tem.claimid=clm.claimid 
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')
GROUP BY cd.usemanualcontractprice
";

    }
}
