﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public class clsSpecial1
    {
        public string memo01 = @"
------------------------------------------------------
PRINT 'Update existing memos'
------------------------------------------------------
SELECT m.*, tem.*, ROW_NUMBER() over (PARTITION BY cm.claimid ORDER BY m.createdate ASC) AS CreatedOrder
INTO  BDU_TEMP.EDI.[@EXCEL_ExistingMemos]
FROM @QNXT..memo m (NOLOCK) JOIN @QNXT..claimmemo cm (NOLOCK)  ON m.memoid = cm.memoid 
JOIN BDU_TEMP.EDI.[@EXCEL] tem  ON cm.claimid = tem.claimid
WHERE (
m.description LIKE 'P0%' 
OR m.description LIKE 'P1%' OR m.description LIKE 'H0%'
OR m.description LIKE 'H1%' OR m.description LIKE 'H2%'
OR m.description LIKE 'H3%' OR m.description LIKE 'H4%'
OR m.description LIKE 'H7%' OR m.description LIKE 'H9%'
OR m.description LIKE 'C0%' OR m.description LIKE 'C1%'
OR m.description LIKE 'C2%' OR m.description LIKE 'C3%'
OR m.description LIKE 'C4%' OR m.description LIKE 'C5%'
OR m.description LIKE 'C6%' OR m.description LIKE 'C7%'
OR m.description LIKE 'C8%' OR m.description LIKE 'C9%'
)  AND tem.claimid IS NOT NULL  
 AND m.termdate =CONVERT(smalldatetime,'2078-12-31 00:00:00')

 
--SELECT cm.claimid , m.*
SELECT COUNT(cm.claimid)
FROM @QNXT..memo m (NOLOCK)
JOIN @QNXT..claimmemo cm (NOLOCK)
ON m.memoid =cm.memoid
JOIN BDU_TEMP.EDI.[@EXCEL_ExistingMemos] tem
ON cm.claimid = tem.claimid
AND m.memoid = tem.memoid
WHERE CreatedOrder = 1

SELECT m.*
INTO BDU_TEMP.EDI.[@EXCEL_memo20]
FROM @QNXT..memo m (NOLOCK)
JOIN @QNXT..claimmemo cm (NOLOCK)
ON m.memoid =cm.memoid
JOIN  BDU_TEMP.EDI.[@EXCEL_ExistingMemos] tem
ON cm.claimid = tem.claimid
AND m.memoid =tem.memoid
WHERE CreatedOrder = 1

UPDATE m
SET m.description = tem.excel_desc + ' ' + CAST(m.description AS varchar(MAX)), m.message = '< ' + convert( varchar(10), getdate(), 101) +
stuff( right( convert( varchar(26), getdate(), 109 ), 15 ), 7, 7, ' ' ) + ' – N314740 > ' + tem.excel_message +' ' + CAST(m.message AS varchar(MAX))
FROM @QNXT..memo m (NOLOCK)
JOIN @QNXT..claimmemo cm (NOLOCK)
ON m.memoid =cm.memoid
JOIN BDU_TEMP.EDI.[@EXCEL_ExistingMemos] tem
ON cm.claimid = tem.claimid
AND m.memoid = tem.memoid
WHERE CreatedOrder = 1
"; 

    }
}
