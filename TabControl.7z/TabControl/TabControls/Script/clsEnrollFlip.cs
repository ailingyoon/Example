﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDUScript
{
    public class clsEnrollFlip
    {
        public string strEnrollFlip = @"
----------------------------------------------------------------------------
PRINT '----Update claimpendhistory overrider'
----------------------------------------------------------------------------
--Backup
SELECT cph.*
INTO BDU_TEMP.EDI.[@EXCEL_CPH1]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK)
ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')
AND cph.overrider = '' 
AND ce.status = 'PEND'

--Update
UPDATE cph
SET overridedate = GETDATE(), overrider = 'PHX\EDIUser'
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK)
ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')
AND cph.overrider = ''
AND ce.status = 'PEND'
------------------------------------------------------
PRINT '----Okay edit where rule id = 913 and status = PEND'
------------------------------------------------------
SELECT ce.*
INTO BDU_Temp.EDI.[@EXCEL_ce1]
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
WHERE ce.ruleid IN ('913')
AND ce.status = 'PEND'

UPDATE ce SET ce.status = 'OKAY',ce.clearby = 'PHX\EDIUser',ce.cleardate = GETDATE(), ce.state = 'MANUAL'
FROM @QNXT..claimedit ce (NOLOCK)  JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
WHERE ce.ruleid IN ('913')
AND ce.status = 'PEND'

SELECT ce.status, COUNT(*)
FROM @QNXT..claimedit ce (NOLOCK)  JOIN BDU_Temp.EDI.[@EXCEL] tem
ON tem.claimid = ce.claimid
WHERE ce.ruleid IN ('913')
AND ce.status = 'PEND'
GROUP BY ce.status

----------------------------------------------------------------------
PRINT '----Claim status to OPEN and enrollid to column'
----------------------------------------------------------------------
SELECT clm.*
INTO BDU_Temp.EDI.[@EXCEL_CLM]
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

UPDATE clm SET clm.status = 'OPEN', clm.enrollid = tem.enrollid
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED')

SELECT clm.status, clm.enrollid, COUNT(*), COUNT(DISTINCT clm.claimid)
FROM @QNXT..claim clm (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON clm.claimid = tem.claimid
WHERE clm.status NOT IN ('PAID','DENIED','VOID', 'REVERSED') 
GROUP BY clm.status, clm.enrollid ";
    }
}
