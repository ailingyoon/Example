﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BDUScript
{
    public class clsTab_claimpendhistory
    {

 public string Pend_claim_toSomething = @"
----------------------------------------------------------------------------
PRINT 'Pend claim to  ##  Pend Bucket'
----------------------------------------------------------------------------
insert into  @QNXT..claimpendhistory(claimid, pendreasonid, penddate)
select distinct tem.claimid, ## , getdate()
from @QNXT..claimedit ce (nolock)
join BDU_TEMP.edi.[@EXCEL] tem on tem.claimid = ce.claimid
left join @QNXT..claimpendhistory cph (nolock) on cph.claimid = tem.claimid
where ce.ruleid in ( '913')  and ce.claimline = '0'  
and tem.claimid IS NOT NULL
";

 public string Rule913_claimline0_FixReasonid = @"
----------------------------------------------------------------------------
PRINT 'Insert claimpendhistory overrider with ruleid in 913 and claimline=0'
----------------------------------------------------------------------------
--Count before insert
SELECT COUNT(DISTINCT tem.claimid)
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
LEFT JOIN @QNXT..claimpendhistory cph (NOLOCK)
ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')
AND ce.claimline = '0'
AND tem.claimid IS NOT NULL

--Insert
INSERT INTO @QNXT..claimpendhistory (claimid, pendreasonid, penddate)
SELECT DISTINCT tem.claimid, '##', GETDATE()
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem 
ON tem.claimid = ce.claimid
LEFT JOIN @QNXT..claimpendhistory cph (NOLOCK)
ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')
AND ce.claimline = '0'
AND tem.claimid IS NOT NULL
";
public string overrider_913_claimline0_OnlyUpdate = @"
----------------------------------------------------------------------------
PRINT 'Update claimpendhistory overrider'
----------------------------------------------------------------------------
SELECT COUNT(1)
FROM  @QNXT..claimpendhistory cph (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem 
ON cph.claimid = tem.claimid
JOIN  @QNXT..claimedit ce (NOLOCK) 
ON tem.claimid = ce.claimid 
WHERE  cph.overrider = '' AND ce.ruleid IN ( '913') 

----Backup
SELECT cph.*
INTO BDU_TEMP.edi.[@EXCEL_CPH1]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.edi.[@EXCEL] tem  ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK)  ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')   AND cph.overrider = '' 

----Update
UPDATE cph
SET overridedate = GETDATE(), overrider = 'PHX\EDIUser'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK) ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')   AND cph.overrider = ''
";

 public string overrider_913_claimline0 = @"
       ----------------------------------------------------------------------------
PRINT 'Update and insert claimpendhistory overrider'
----------------------------------------------------------------------------
----Backup
SELECT cph.*
INTO BDU_TEMP.edi.[@EXCEL_CPH1]
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.edi.[@EXCEL] tem  ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK)  ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913') AND ce.claimline = '0' AND cph.overrider = '' 

----Update
UPDATE cph
SET overridedate = GETDATE(), overrider = 'PHX\EDIUser'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK) ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913') AND ce.claimline = '0' AND cph.overrider = ''

----Count before insert
SELECT COUNT(DISTINCT tem.claimid)
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.edi.[@EXCEL] tem  ON tem.claimid = ce.claimid
LEFT JOIN @QNXT..claimpendhistory cph (NOLOCK) ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913') AND ce.claimline = '0'

----Insert
INSERT INTO @QNXT..claimpendhistory (claimid, pendreasonid, penddate)
SELECT DISTINCT tem.claimid, tem.dd, GETDATE()
FROM @QNXT..claimedit ce (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem 
ON tem.claimid = ce.claimid
LEFT JOIN @QNXT..claimpendhistory cph (NOLOCK)
ON cph.claimid = tem.claimid
WHERE ce.ruleid IN ('913')  AND ce.claimline = '0'  
AND tem.claimid IS NOT NULL  AND cph.claimid is NULL
"; 

public string Update_913_PEND = @"
----------------------------------------------------------------------------
PRINT  'Update claimpendhistory'
----------------------------------------------------------------------------
SELECT COUNT(1)
FROM @QNXT..claimpendhistory cph (NOLOCK)
JOIN BDU_TEMP.edi.[@EXCEL] tem 
ON cph.claimid = tem.claimid
JOIN @QNXT..claimedit ce (NOLOCK) 
ON tem.claimid = ce.claimid 
WHERE  cph.overrider = '' AND ce.ruleid IN ( '913') and ce.status = 'PEND'

SELECT cph.*
INTO BDU_TEMP.edi.[@EXCEL_CPH]
FROM @QNXT..claimedit ce (NOLOCK) 
JOIN BDU_TEMP.edi.[@EXCEL] tem  ON tem.claimid = ce.claimid
JOIN @QNXT..claimpendhistory cph (NOLOCK)  ON cph.claimid = tem.claimid
WHERE ce.ruleid ='913'   AND  ce.status = 'PEND'  AND  cph.overrider = ''
----AND cph.pendreasonid IN ('C54', 'C73', 'C74', 'H01', 'P01', 'P05', 'P07')


UPDATE cph  SET overridedate = GETDATE(), overrider = 'PHX\EDIUser'
FROM @QNXT..claimedit ce (NOLOCK) JOIN BDU_TEMP.edi.[@EXCEL] tem
ON tem.claimid = ce.claimid
JOIN  @QNXT..claimpendhistory cph (NOLOCK) ON cph.claimid = tem.claimid
WHERE ce.ruleid ='913'  AND  ce.status = 'PEND'  AND cph.overrider = ''
----AND cph.pendreasonid IN ('C54', 'C73', 'C74', 'H01', 'P01', 'P05', 'P07')
";
public string Update_913_NoStatus_Noclaimline = @"
---------------------------------------------
PRINT 'UPDATE clamipendhistory ruleid  913'
---------------------------------------------
SELECT cph.* INTO BDU_Temp.EDI.[@EXCEL_cph]
FROM @QNXT..claimpendhistory cph (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem ON cph.claimid = tem.claimid
JOIN @QNXT..claimedit ce (NOLOCK) ON tem.claimid = ce.claimid
WHERE cph.overrider = '' AND ce.ruleid IN ( '913')

UPDATE cph SET overrider = 'PHX\EDIUser', overridedate = getdate()
FROM @QNXT..claimpendhistory cph (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem ON cph.claimid = tem.claimid
JOIN @QNXT..claimedit ce (NOLOCK) ON tem.claimid = ce.claimid
WHERE cph.overrider = '' AND ce.ruleid IN ( '913')

SELECT COUNT(1)
FROM @QNXT..claimpendhistory cph (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem ON cph.claimid = tem.claimid
JOIN @QNXT..claimedit ce (NOLOCK) ON tem.claimid = ce.claimid
WHERE cph.overrider = '' AND ce.ruleid IN ( '913')
";

 public string Update_PassRuleid = @"
USE @QNXT
--------------------------------
PRINT 'UPDATE clamipendhistory'
-------------------------------- 
SELECT cph.* INTO BDU_Temp.EDI.[@EXCEL_cph]
FROM @QNXT..claimpendhistory cph (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON cph.claimid = tem.claimid
JOIN @QNXT..claimedit ce (NOLOCK)
ON tem.claimid = ce.claimid
WHERE cph.overrider = '' AND ce.ruleid IN ('@RULEID')

UPDATE cph SET overrider = 'PHX\EDIUser', overridedate = getdate()
FROM @QNXT..claimpendhistory cph (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON cph.claimid = tem.claimid
JOIN @QNXT..claimedit ce (NOLOCK)
ON tem.claimid = ce.claimid
WHERE cph.overrider = '' AND ce.ruleid IN ('@RULEID')

SELECT COUNT(1)
FROM @QNXT..claimpendhistory cph (NOLOCK)
JOIN BDU_Temp.EDI.[@EXCEL] tem
ON cph.claimid = tem.claimid
JOIN @QNXT..claimedit ce (NOLOCK)
ON tem.claimid = ce.claimid
WHERE cph.overrider = '' AND ce.ruleid IN ('@RULEID')
";
    }
}
