﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TabControls
{
    public class clsWO
    {
        public string WO;
        public string SUBMITDATE;
        public string detail;
        public string summary;
        public string plans;

    }
}
