﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Utilities
{ 
    class ClsGlobal
    {
        public struct CONN
        {
            public string sSERVER  ;
            public string sDB; 
        }
         
       

    }
  
}
