﻿using System;
using System.Data;
using System.IO;
using NPOI.HSSF.UserModel;///Excel 2003: *.xls
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;///Excel 2007: *.xlsx
using System.Collections;

namespace Utilities
{
    

    public class ExcelClass
    {
        //public ArrayList ArryList1=new ArrayList(); 
        public ArrayList GetSheet(string path)
        {
            IWorkbook workbook = null;

            string ExtensionName = Path.GetExtension(path).ToLower();
            using (FileStream file = new FileStream(path, FileMode.Open, FileAccess.Read))
            {
                if (ExtensionName == ".xlsx")
                    workbook = new XSSFWorkbook(file);
                else if (ExtensionName == ".xls")
                    workbook = new HSSFWorkbook(file);
            }
            //ISheet sheet = workbook.GetSheetAt(iIndex);
            //return  sheet.SheetName;
            ArrayList ArryList1 = new ArrayList();
            Boolean  boolRead = true;
            int i = 0;
            while (boolRead)
            {
                try
                {
                    ISheet sheet = workbook.GetSheetAt(i);
                    if (sheet != null && sheet.SheetName.Length > 0)
                    {
                        ArryList1.Add(sheet.SheetName);
                    }
                    else
                    {
                        boolRead = false;
                    }
                    i++;
                }
                catch
                {
                    boolRead = false;
                } 

            }

            return ArryList1;

        }
        public DataTable ExcelToDataTable(string path,int iIndex,out ArrayList Cols)
        {
            DataTable dt1 = new DataTable();
            IWorkbook workbook = null;
            Cols = new ArrayList();

            try {
                string ExtensionName = Path.GetExtension(path).ToLower();
                using (FileStream file = new FileStream(path, FileMode.Open, FileAccess.Read))
                    { 
                        if (ExtensionName == ".xlsx")
                            workbook = new XSSFWorkbook(file);
                        else if (ExtensionName == ".xls")
                            workbook = new HSSFWorkbook(file);
                    }
                    ISheet sheet = workbook.GetSheetAt(iIndex);
                    //SheetName = sheet.SheetName;
                    
                    System.Collections.IEnumerator rows = sheet.GetRowEnumerator();

                    IRow headerRow = sheet.GetRow(0);
                    int cellCount = headerRow.LastCellNum;

                    for (int j = 0; j < cellCount; j++)
                    {
                        ICell cell = headerRow.GetCell(j);
                        string col = cell.ToString().ToLower().Trim().Replace(" ","");
                        dt1.Columns.Add(col);
                        Cols.Add(col); 
                    }

                    for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++)
                    {
                        IRow row = sheet.GetRow(i);
                        DataRow dataRow = dt1.NewRow();

                        for (int j = row.FirstCellNum; j < cellCount; j++)
                        {
                            if (row.GetCell(j) != null)
                                dataRow[j] = row.GetCell(j).ToString().Trim();
                        }
                        dt1.Rows.Add(dataRow);
                    }


                return dt1;

            } 
            catch (Exception ex)
            {
                /**********************************
                       * 1.This file has been opened.
                       * 2.Data is empty.
                   **********************************/

                //SheetName = "";
                throw;
                //return null;
            }
     
   
        }

        public bool DataTableToExcel(string path, string SheetName, DataTable dt, bool ColumnWritten)
        {
            if (dt != null)
            {
                try
                {
                    using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite))
                    {
                        /* Initialize Workbook */
                        IWorkbook workbook = null;
                        string ExtensionName = Path.GetExtension(path).ToLower();
                        if (ExtensionName == ".xlsx")
                            workbook = new XSSFWorkbook();
                        else if (ExtensionName == ".xls")
                            workbook = new HSSFWorkbook();
                        /* Convert To Excel */
                        ISheet sheet = workbook.CreateSheet(SheetName);
                        /* Columns Name Written */
                        int count;
                        if (ColumnWritten)
                        {
                            IRow row = sheet.CreateRow(0);
                            for (int i = 0; i < dt.Columns.Count; ++i)
                                row.CreateCell(i).SetCellValue(dt.Columns[i].ColumnName);
                            count = 1;
                        }
                        else
                            count = 0;
                        /* Excel Cell Value Written */
                        for (int i = 0; i < dt.Rows.Count; ++i)
                        {
                            IRow row = sheet.CreateRow(count);
                            for (int j = 0; j < dt.Columns.Count; ++j)
                                row.CreateCell(j).SetCellValue(dt.Rows[i][j].ToString());
                            ++count;
                        }
                        workbook.Write(fs);
                    }
                    return true;
                }
                catch
                {
                    /**********************************
                        * 1.This file has been opened.
                        * 2.Data is empty.
                    **********************************/
                    return false;
                }
            }
            else
                return false;
        }
    }
}