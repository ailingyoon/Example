﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SendMail
{
    class Program
    {
        static void Main(string[] args)
        {//主要输入：服务器IP，发件人，收件人，抄送，密送，主题，内容，文件
            if (args.Length != 9)
            {
                Console.WriteLine("请正确传入参数,例如:");
                Console.WriteLine("SendMail 这是邮件服务器IP 这是发件人 这是显示名称 这是收件人 这是抄送 这是密送 这是主题 这是内容 这是文件");
                return;
            }

            SendMail mails = new SendMail(args);
            if (mails.DoSendMail()) { Console.WriteLine("发送成功"); }
            else { Console.WriteLine("发送失败"); }
        }
    }
}
