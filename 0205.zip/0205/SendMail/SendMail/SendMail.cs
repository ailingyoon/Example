﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Net.Mail;

namespace SendMail
{
    class SendMail
    {
        private string[] tmpInput;
        private string serIp;
        private string mailFrom;
        private string showName;
        private ArrayList mailTo;
        private ArrayList mailCc;
        private ArrayList mailBcc;
        private string mailSubject;
        private string mailBody;
        private ArrayList mailFile;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="tmpInput">主要输入：服务器IP，发件人，收件人，抄送，密送，主题，内容，文件</param>
        public SendMail(string[] tmpInput)
        {
            this.tmpInput = tmpInput;
        }

        public bool DoSendMail()
        {
            if (!ChkConf()) { return false; }
            try
            {
                MailMessage msg = new MailMessage();
                msg.SubjectEncoding = System.Text.Encoding.UTF8;
                msg.BodyEncoding = System.Text.Encoding.UTF8;
                msg.From = new MailAddress(mailFrom, showName);  // 发件人地址，只有一个
                foreach (string item in mailTo)
                {
                    msg.To.Add(item);
                }
                foreach (string item in mailCc)
                {
                    msg.CC.Add(item);
                }
                foreach (string item in mailBcc)
                {
                    msg.Bcc.Add(item);
                }
                msg.Subject = mailSubject;
                msg.Body = mailBody;
                foreach (string item in mailFile)
                {
                    msg.Attachments.Add(new Attachment(item));
                }
                SmtpClient client = new SmtpClient(serIp, 25); // Notes的服务器地址和端口
                client.Send(msg); // 发送邮件
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// 检测输入的合法性
        /// </summary>
        /// <returns>必须输入合法才会检测通过</returns>
        private bool ChkConf()
        {
            System.Net.IPAddress tmIP = null;
            if (!System.Net.IPAddress.TryParse(tmpInput[0], out tmIP))
            {
                Console.WriteLine("服务器IP填写不正确!");
                return false;
            }
            serIp = tmpInput[0];
            //************************************************************
            if (!DoCheckMailLegal(tmpInput[1]))
            {
                Console.WriteLine("发件人填写不正确!");
                return false;
            }
            mailFrom = tmpInput[1];
            //************************************************************
            showName = tmpInput[2];
            //************************************************************
            mailTo = new ArrayList(); // 检测合格的邮箱才会添加到 mailTo
            foreach (string item in tmpInput[3].Split(';'))
            {
                if (DoCheckMailLegal(item))
                {
                    mailTo.Add(item);
                }
            }
            if (mailTo.Count == 0)
            { // 如果没有一个邮箱是合法的，则返回错误
                Console.WriteLine("收件人填写不正确,至少要有一个合法邮箱!");
                return false;
            }
            //************************************************************
            mailCc = new ArrayList(); // 检测合格的邮箱才会添加到 抄送
            foreach (string item in tmpInput[4].Split(';'))
            {
                if (DoCheckMailLegal(item))
                {
                    mailCc.Add(item);
                }
            }
            //************************************************************
            mailBcc = new ArrayList(); // 检测合格的邮箱才会添加到 抄送
            foreach (string item in tmpInput[5].Split(';'))
            {
                if (DoCheckMailLegal(item))
                {
                    mailBcc.Add(item);
                }
            }
            //************************************************************
            mailSubject = tmpInput[6];
            //************************************************************
            mailBody = tmpInput[7];
            //************************************************************
            mailFile = new ArrayList(); // 检测合格的邮箱才会添加到 mail_File
            foreach (string item in tmpInput[8].Split(';'))
            {
                if (System.IO.File.Exists(item))
                { // 文件存在则将其添加进 mailFile
                    mailFile.Add(item);
                }
            }
            return true;
        }


        /// <summary>
        /// 验证字符串是否是正确的邮箱
        /// </summary>
        /// <param name="mail_str">传入邮箱字符串</param>
        private bool DoCheckMailLegal(string mail_string)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(mail_string, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        }
    }
}
