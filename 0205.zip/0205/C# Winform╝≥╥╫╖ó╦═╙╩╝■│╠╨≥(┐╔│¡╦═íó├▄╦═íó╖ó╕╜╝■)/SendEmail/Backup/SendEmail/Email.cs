﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.Diagnostics;

namespace SendEmail
{
    public partial class SendEmail : Form
    {
        public SendEmail()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 发送邮件函数
        /// </summary>
        /// <param name="FromSMTP">发送服务器 例如：163的服务器是smtp.163.com</param>
        /// <param name="FromEmail">发送方邮箱地址</param>
        /// <param name="Bcc">密送</param>
        /// <param name="CC">抄送</param>
        /// <param name="FromPassword">发送方密码</param>
        /// <param name="ToEmail">接收方邮箱</param>
        /// <param name="Subject">邮件主题</param>
        /// <param name="Body">邮件内容</param>
        /// <param name="Attachments">附件，多个附件以分号隔开</param>
        /// <param name="FromName">发送方显示名</param>
        /// <param name="Ssl">是否加密传输</param>
        /// <param name="SmtpPort">端口，默认是25</param>
        /// <returns></returns>
        private bool SendMail(string FromSMTP, string FromEmail,string Bcc,string CC,string FromPassword, string ToEmail, string Subject, string Body,string Attachments,string FromName, bool Ssl, int SmtpPort)
        {
            try
            {
                //邮件发送类
                MailMessage mail = new MailMessage();
                //是谁发送的邮件
                mail.From = new MailAddress(FromEmail, FromName);
                mail.Sender = new MailAddress(FromEmail, FromName);
                
                //密送
                foreach (string strToBcc in Bcc.Split(';'))
                {
                    if (strToBcc.Length > 0)
                    {
                        mail.Bcc.Add(new MailAddress(strToBcc));
                    }
                }

                //抄送
                foreach (string strToCC in CC.Split(';'))
                {
                    if (strToCC.Length > 0)
                    {
                        mail.CC.Add(new MailAddress(strToCC));
                    }
                }
                

                //发送给谁

                foreach (string strToEmail in ToEmail.Split(';'))
                {
                    if (strToEmail.Length > 0)
                    {
                        mail.To.Add(strToEmail);
                    }
                }

                //标题
                mail.Subject = Subject;
                //内容编码
                mail.BodyEncoding = Encoding.Default;
                //发送优先级
                mail.Priority = MailPriority.High;
                //邮件内容
                mail.Body = Body;
                //是否HTML形式发送
                mail.IsBodyHtml = true;

                //附件

                foreach (string strAttachment in Attachments.Split(';'))
                {
                    if (strAttachment.Length > 0)
                    {
                        mail.Attachments.Add(new Attachment(strAttachment));
                    }
                }

                //邮件服务器和端口
                SmtpClient smtp = new SmtpClient(FromSMTP, SmtpPort);
                smtp.UseDefaultCredentials = true;
                //指定发送方式
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                //指定登录名和密码
                smtp.Credentials = new NetworkCredential(FromEmail, FromPassword);

                smtp.EnableSsl = Ssl;//SMTP 服务器要求安全连接需要设置此属性

                //超时时间
                smtp.Timeout = 100000;

                smtp.Send(mail);

                #region 异步发送
                //object userToken = mail;
                //smtp.SendAsync(mail, userToken);
                #endregion

                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return false;
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            this.SendMail(txtSmtp.Text.Trim(), txtFrom.Text.Trim(), txtBcc.Text.Trim(), txtCC.Text.Trim(), txtFromPassWord.Text.Trim(), txtToEmail.Text.Trim(), txtSubject.Text.Trim(), rtxtContent.Text.Trim(), txtAtt.Text.Trim(), txtFormName.Text.Trim(), chbSsl.Checked, int.Parse(txtPort.Text.Trim()));
        }

        private void lnkAd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("explorer.exe", "http://pan.baidu.com/s/1dDsuJa5");
        }

        private void SendEmail_FormClosing(object sender, FormClosingEventArgs e)
        {
            Process.Start("explorer.exe", "http://www.2345.com/?k588873");
        }
    }
}
