﻿namespace SendEmail
{
    partial class SendEmail
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtFormName = new System.Windows.Forms.TextBox();
            this.lblFromName = new System.Windows.Forms.Label();
            this.txtSmtp = new System.Windows.Forms.TextBox();
            this.lblSmtp = new System.Windows.Forms.Label();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.lblPort = new System.Windows.Forms.Label();
            this.lblmess = new System.Windows.Forms.Label();
            this.chbSsl = new System.Windows.Forms.CheckBox();
            this.txtFromPassWord = new System.Windows.Forms.TextBox();
            this.lblFromPassWord = new System.Windows.Forms.Label();
            this.txtFrom = new System.Windows.Forms.TextBox();
            this.lblFrom = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnSend = new System.Windows.Forms.Button();
            this.rtxtContent = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAtt = new System.Windows.Forms.TextBox();
            this.lblAtt = new System.Windows.Forms.Label();
            this.txtSubject = new System.Windows.Forms.TextBox();
            this.lblSubject = new System.Windows.Forms.Label();
            this.txtBcc = new System.Windows.Forms.TextBox();
            this.txtCC = new System.Windows.Forms.TextBox();
            this.lblBcc = new System.Windows.Forms.Label();
            this.lblCC = new System.Windows.Forms.Label();
            this.lblToEmail = new System.Windows.Forms.Label();
            this.txtToEmail = new System.Windows.Forms.TextBox();
            this.lnkAd = new System.Windows.Forms.LinkLabel();
            this.lnkAd2 = new System.Windows.Forms.LinkLabel();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(653, 465);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lnkAd2);
            this.tabPage1.Controls.Add(this.txtFormName);
            this.tabPage1.Controls.Add(this.lblFromName);
            this.tabPage1.Controls.Add(this.txtSmtp);
            this.tabPage1.Controls.Add(this.lblSmtp);
            this.tabPage1.Controls.Add(this.txtPort);
            this.tabPage1.Controls.Add(this.lblPort);
            this.tabPage1.Controls.Add(this.lblmess);
            this.tabPage1.Controls.Add(this.chbSsl);
            this.tabPage1.Controls.Add(this.txtFromPassWord);
            this.tabPage1.Controls.Add(this.lblFromPassWord);
            this.tabPage1.Controls.Add(this.txtFrom);
            this.tabPage1.Controls.Add(this.lblFrom);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(645, 439);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "配置";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtFormName
            // 
            this.txtFormName.Location = new System.Drawing.Point(101, 92);
            this.txtFormName.Name = "txtFormName";
            this.txtFormName.Size = new System.Drawing.Size(513, 21);
            this.txtFormName.TabIndex = 11;
            this.txtFormName.Text = "Test";
            // 
            // lblFromName
            // 
            this.lblFromName.AutoSize = true;
            this.lblFromName.Location = new System.Drawing.Point(42, 95);
            this.lblFromName.Name = "lblFromName";
            this.lblFromName.Size = new System.Drawing.Size(47, 12);
            this.lblFromName.TabIndex = 10;
            this.lblFromName.Text = "显示名:";
            // 
            // txtSmtp
            // 
            this.txtSmtp.Location = new System.Drawing.Point(101, 149);
            this.txtSmtp.Name = "txtSmtp";
            this.txtSmtp.Size = new System.Drawing.Size(513, 21);
            this.txtSmtp.TabIndex = 9;
            this.txtSmtp.Text = "smtp.163.com";
            // 
            // lblSmtp
            // 
            this.lblSmtp.AutoSize = true;
            this.lblSmtp.Location = new System.Drawing.Point(54, 152);
            this.lblSmtp.Name = "lblSmtp";
            this.lblSmtp.Size = new System.Drawing.Size(35, 12);
            this.lblSmtp.TabIndex = 8;
            this.lblSmtp.Text = "Smtp:";
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(101, 193);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(100, 21);
            this.txtPort.TabIndex = 7;
            this.txtPort.Text = "25";
            // 
            // lblPort
            // 
            this.lblPort.AutoSize = true;
            this.lblPort.Location = new System.Drawing.Point(30, 196);
            this.lblPort.Name = "lblPort";
            this.lblPort.Size = new System.Drawing.Size(59, 12);
            this.lblPort.TabIndex = 6;
            this.lblPort.Text = "发送端口:";
            // 
            // lblmess
            // 
            this.lblmess.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblmess.ForeColor = System.Drawing.Color.Red;
            this.lblmess.Location = new System.Drawing.Point(8, 317);
            this.lblmess.Name = "lblmess";
            this.lblmess.Size = new System.Drawing.Size(617, 20);
            this.lblmess.TabIndex = 5;
            this.lblmess.Text = "请先配置然后再发邮件(注：以上参数为格式示例，需自行更改为实际真实有效的信息)";
            // 
            // chbSsl
            // 
            this.chbSsl.AutoSize = true;
            this.chbSsl.Location = new System.Drawing.Point(32, 238);
            this.chbSsl.Name = "chbSsl";
            this.chbSsl.Size = new System.Drawing.Size(96, 16);
            this.chbSsl.TabIndex = 4;
            this.chbSsl.Text = "是否加密传输";
            this.chbSsl.UseVisualStyleBackColor = true;
            // 
            // txtFromPassWord
            // 
            this.txtFromPassWord.Location = new System.Drawing.Point(101, 52);
            this.txtFromPassWord.Name = "txtFromPassWord";
            this.txtFromPassWord.Size = new System.Drawing.Size(513, 21);
            this.txtFromPassWord.TabIndex = 3;
            this.txtFromPassWord.Text = "Test";
            // 
            // lblFromPassWord
            // 
            this.lblFromPassWord.AutoSize = true;
            this.lblFromPassWord.Location = new System.Drawing.Point(6, 55);
            this.lblFromPassWord.Name = "lblFromPassWord";
            this.lblFromPassWord.Size = new System.Drawing.Size(83, 12);
            this.lblFromPassWord.TabIndex = 2;
            this.lblFromPassWord.Text = "发件邮箱密码:";
            // 
            // txtFrom
            // 
            this.txtFrom.Location = new System.Drawing.Point(101, 18);
            this.txtFrom.Name = "txtFrom";
            this.txtFrom.Size = new System.Drawing.Size(513, 21);
            this.txtFrom.TabIndex = 1;
            this.txtFrom.Text = "Test@163.com";
            // 
            // lblFrom
            // 
            this.lblFrom.AutoSize = true;
            this.lblFrom.Location = new System.Drawing.Point(6, 21);
            this.lblFrom.Name = "lblFrom";
            this.lblFrom.Size = new System.Drawing.Size(83, 12);
            this.lblFrom.TabIndex = 0;
            this.lblFrom.Text = "发件邮箱地址:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lnkAd);
            this.tabPage2.Controls.Add(this.btnSend);
            this.tabPage2.Controls.Add(this.rtxtContent);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.txtAtt);
            this.tabPage2.Controls.Add(this.lblAtt);
            this.tabPage2.Controls.Add(this.txtSubject);
            this.tabPage2.Controls.Add(this.lblSubject);
            this.tabPage2.Controls.Add(this.txtBcc);
            this.tabPage2.Controls.Add(this.txtCC);
            this.tabPage2.Controls.Add(this.lblBcc);
            this.tabPage2.Controls.Add(this.lblCC);
            this.tabPage2.Controls.Add(this.lblToEmail);
            this.tabPage2.Controls.Add(this.txtToEmail);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(645, 439);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "发邮件";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(547, 408);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 22;
            this.btnSend.Text = "发送";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // rtxtContent
            // 
            this.rtxtContent.Location = new System.Drawing.Point(56, 196);
            this.rtxtContent.Name = "rtxtContent";
            this.rtxtContent.Size = new System.Drawing.Size(566, 198);
            this.rtxtContent.TabIndex = 21;
            this.rtxtContent.Text = "Test";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 196);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 20;
            this.label1.Text = "内容:";
            // 
            // txtAtt
            // 
            this.txtAtt.Location = new System.Drawing.Point(189, 116);
            this.txtAtt.Name = "txtAtt";
            this.txtAtt.Size = new System.Drawing.Size(433, 21);
            this.txtAtt.TabIndex = 19;
            // 
            // lblAtt
            // 
            this.lblAtt.AutoSize = true;
            this.lblAtt.Location = new System.Drawing.Point(15, 119);
            this.lblAtt.Name = "lblAtt";
            this.lblAtt.Size = new System.Drawing.Size(155, 12);
            this.lblAtt.TabIndex = 18;
            this.lblAtt.Text = "附件(多个附件以分号隔开):";
            // 
            // txtSubject
            // 
            this.txtSubject.Location = new System.Drawing.Point(56, 154);
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(566, 21);
            this.txtSubject.TabIndex = 17;
            this.txtSubject.Text = "Test";
            // 
            // lblSubject
            // 
            this.lblSubject.AutoSize = true;
            this.lblSubject.Location = new System.Drawing.Point(15, 157);
            this.lblSubject.Name = "lblSubject";
            this.lblSubject.Size = new System.Drawing.Size(35, 12);
            this.lblSubject.TabIndex = 16;
            this.lblSubject.Text = "主题:";
            // 
            // txtBcc
            // 
            this.txtBcc.Location = new System.Drawing.Point(189, 80);
            this.txtBcc.Name = "txtBcc";
            this.txtBcc.Size = new System.Drawing.Size(433, 21);
            this.txtBcc.TabIndex = 15;
            // 
            // txtCC
            // 
            this.txtCC.Location = new System.Drawing.Point(189, 42);
            this.txtCC.Name = "txtCC";
            this.txtCC.Size = new System.Drawing.Size(433, 21);
            this.txtCC.TabIndex = 14;
            // 
            // lblBcc
            // 
            this.lblBcc.AutoSize = true;
            this.lblBcc.Location = new System.Drawing.Point(13, 83);
            this.lblBcc.Name = "lblBcc";
            this.lblBcc.Size = new System.Drawing.Size(167, 12);
            this.lblBcc.TabIndex = 13;
            this.lblBcc.Text = "密送(多个收件人以分号隔开):";
            // 
            // lblCC
            // 
            this.lblCC.AutoSize = true;
            this.lblCC.Location = new System.Drawing.Point(13, 45);
            this.lblCC.Name = "lblCC";
            this.lblCC.Size = new System.Drawing.Size(167, 12);
            this.lblCC.TabIndex = 12;
            this.lblCC.Text = "抄送(多个收件人以分号隔开):";
            // 
            // lblToEmail
            // 
            this.lblToEmail.AutoSize = true;
            this.lblToEmail.Location = new System.Drawing.Point(3, 7);
            this.lblToEmail.Name = "lblToEmail";
            this.lblToEmail.Size = new System.Drawing.Size(179, 12);
            this.lblToEmail.TabIndex = 11;
            this.lblToEmail.Text = "收件人(多个收件人以分号隔开):";
            // 
            // txtToEmail
            // 
            this.txtToEmail.Location = new System.Drawing.Point(189, 4);
            this.txtToEmail.Name = "txtToEmail";
            this.txtToEmail.Size = new System.Drawing.Size(433, 21);
            this.txtToEmail.TabIndex = 10;
            this.txtToEmail.Text = "ie@2345.com";
            // 
            // lnkAd
            // 
            this.lnkAd.AutoSize = true;
            this.lnkAd.Location = new System.Drawing.Point(54, 413);
            this.lnkAd.Name = "lnkAd";
            this.lnkAd.Size = new System.Drawing.Size(137, 12);
            this.lnkAd.TabIndex = 23;
            this.lnkAd.TabStop = true;
            this.lnkAd.Text = "免费打电话的智能浏览器";
            this.lnkAd.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkAd_LinkClicked);
            // 
            // lnkAd2
            // 
            this.lnkAd2.AutoSize = true;
            this.lnkAd2.Location = new System.Drawing.Point(9, 397);
            this.lnkAd2.Name = "lnkAd2";
            this.lnkAd2.Size = new System.Drawing.Size(137, 12);
            this.lnkAd2.TabIndex = 24;
            this.lnkAd2.TabStop = true;
            this.lnkAd2.Text = "免费打电话的智能浏览器";
            this.lnkAd2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkAd_LinkClicked);
            // 
            // SendEmail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 465);
            this.Controls.Add(this.tabControl1);
            this.Name = "SendEmail";
            this.Text = "邮件发送小程序";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SendEmail_FormClosing);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.RichTextBox rtxtContent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAtt;
        private System.Windows.Forms.Label lblAtt;
        private System.Windows.Forms.TextBox txtSubject;
        private System.Windows.Forms.Label lblSubject;
        private System.Windows.Forms.TextBox txtBcc;
        private System.Windows.Forms.TextBox txtCC;
        private System.Windows.Forms.Label lblBcc;
        private System.Windows.Forms.Label lblCC;
        private System.Windows.Forms.Label lblToEmail;
        private System.Windows.Forms.TextBox txtToEmail;
        private System.Windows.Forms.TextBox txtFromPassWord;
        private System.Windows.Forms.Label lblFromPassWord;
        private System.Windows.Forms.TextBox txtFrom;
        private System.Windows.Forms.Label lblFrom;
        private System.Windows.Forms.Label lblmess;
        private System.Windows.Forms.CheckBox chbSsl;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Label lblPort;
        private System.Windows.Forms.TextBox txtSmtp;
        private System.Windows.Forms.Label lblSmtp;
        private System.Windows.Forms.TextBox txtFormName;
        private System.Windows.Forms.Label lblFromName;
        private System.Windows.Forms.LinkLabel lnkAd;
        private System.Windows.Forms.LinkLabel lnkAd2;

    }
}

