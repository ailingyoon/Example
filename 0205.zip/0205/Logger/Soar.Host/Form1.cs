﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;

using Soar.Framework;

namespace Soar.Host
{
    public partial class Form1 : Form
    {
        ILogger objLogger = Logger.GetInstance();
        public Form1()
        {
            InitializeComponent();

            objLogger.Run();
        }

       

        private void btnLogger_Click(object sender, EventArgs e)
        {
            //objLogger.Debug("Debug信息！<1>");
            //objLogger.Debug("Debug信息！<2>");
            //objLogger.Debug("Debug信息！<3>");
            //objLogger.Debug("Debug信息！<4>");
            //objLogger.Debug("Debug信息！<5>");
            //objLogger.Debug("Debug信息！<6>");
            objLogger.Info("info ssss");


            //System.Threading.Thread testThread1 = new System.Threading.Thread(new System.Threading.ThreadStart(Test1));
            ////System.Threading.Thread testThread2 = new System.Threading.Thread(new System.Threading.ThreadStart(Test2));
            ////System.Threading.Thread testThread3 = new System.Threading.Thread(new System.Threading.ThreadStart(Test3));
            ////System.Threading.Thread testThread4 = new System.Threading.Thread(new System.Threading.ThreadStart(Test4));
            //testThread1.IsBackground = true;
            ////testThread2.IsBackground = true;
            ////testThread3.IsBackground = true;
            ////testThread4.IsBackground = true;
            //testThread1.Start();
            //testThread2.Start();
            //testThread3.Start();
            //testThread4.Start();

            MessageBox.Show("测试成功！");
        }

        void Test1()
        {
            int i = 0;
            while (i <3000)
            {
                //objLogger.Debug("Debug信息！<Thread Test1 " + i + ">");
                //objLogger.Error("Error信息！<Thread Test1 " + i + ">");
                //objLogger.Fatal("Fatal信息！<Thread Test1 " + i + ">");
                //objLogger.Warn("Warn信息！<Thread Test1 " + i + ">");
                objLogger.Info("Info信息！<Thread Test1 " + i + ">");

                i++;
            }
        }

        void Test2()
        {
            int i = 0;
            while (i < 1000)
            {
                objLogger.Debug("Debug信息！<Thread Test2 " + i + ">");
                objLogger.Error("Error信息！<Thread Test2 " + i + ">");
                objLogger.Fatal("Fatal信息！<Thread Test2 " + i + ">");
                objLogger.Warn("Warn信息！<Thread Test2 " + i + ">");
                objLogger.Info("Info信息！<Thread Test2 " + i + ">");

                i++;
            }
        }

        void Test3()
        {
            int i = 0;
            while (i < 1000)
            {
                objLogger.Debug("Debug信息！<Thread Test3 " + i + ">");
                objLogger.Error("Error信息！<Thread Test3 " + i + ">");
                objLogger.Fatal("Fatal信息！<Thread Test3 " + i + ">");
                objLogger.Warn("Warn信息！<Thread Test3 " + i + ">");
                objLogger.Info("Info信息！<Thread Test3 " + i + ">");

                i++;
            }
        }

        void Test4()
        {
            int i = 0;
            while (i <5000)
            {
                objLogger.Debug("Debug信息！<Thread Test4 " + i + ">");
                objLogger.Error("Error信息！<Thread Test4 " + i + ">");
                objLogger.Fatal("Fatal信息！<Thread Test4 " + i + ">");
                objLogger.Warn("Warn信息！<Thread Test4 " + i + ">");
                objLogger.Info("Info信息！<Thread Test4 " + i + ">");

                i++;
            }
        }
    }
}